<!DOCTYPE html>
<html lang="en-US">

<!-- Mirrored from kanni.wpengine.com/contact/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Feb 2022 07:41:45 GMT -->
<!-- Added by HTTrack --><meta http-equiv="content-type" content="text/html;charset=UTF-8" /><!-- /Added by HTTrack -->
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <title>Contact &#8211; Kanni Security Systems WordPress Theme</title>
<meta name='robots' content='max-image-preview:large' />
<link rel='dns-prefetch' href='http://www.google.com/' />
<link rel='dns-prefetch' href='http://s.w.org/' />
<link href='https://fonts.gstatic.com/' crossorigin rel='preconnect' />
<link rel="alternate" type="application/rss+xml" title="Kanni Security Systems WordPress Theme &raquo; Feed" href="https://kanni.wpengine.com/feed/" />
<link rel="alternate" type="application/rss+xml" title="Kanni Security Systems WordPress Theme &raquo; Comments Feed" href="https://kanni.wpengine.com/comments/feed/" />
		<script type="text/javascript">
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.0.1\/svg\/","svgExt":".svg","source":{"concatemoji":"https:\/\/kanni.wpengine.com\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.7.5"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([55357,56424,8205,55356,57212],[55357,56424,8203,55356,57212])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style type="text/css">
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='sb_instagram_styles-css'  href='https://kanni.wpengine.com/wp-content/plugins/instagram-feed/css/sbi-styles.min.css?ver=2.6.2' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-css'  href='https://kanni.wpengine.com/wp-content/plugins/gutenberg/build/block-library/style.css?ver=1609572822' type='text/css' media='all' />
<link rel='stylesheet' id='wp-block-library-theme-css'  href='https://kanni.wpengine.com/wp-content/plugins/gutenberg/build/block-library/theme.css?ver=1609572822' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-vendors-style-css'  href='https://kanni.wpengine.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/vendors-style.css?ver=3.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='wc-block-style-css'  href='https://kanni.wpengine.com/wp-content/plugins/woocommerce/packages/woocommerce-blocks/build/style.css?ver=3.8.1' type='text/css' media='all' />
<link rel='stylesheet' id='contact-form-7-css'  href='https://kanni.wpengine.com/wp-content/plugins/contact-form-7/includes/css/styles.css?ver=5.3.2' type='text/css' media='all' />
<link rel='stylesheet' id='dt-animation-css-css'  href='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/css/animations.css?ver=5.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='dt-slick-css-css'  href='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/css/slick.css?ver=5.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='dt-sc-css-css'  href='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/css/shortcodes.css?ver=5.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-portfolio-css'  href='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/custom-post-types/css/portfolio.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='rs-plugin-settings-css'  href='https://kanni.wpengine.com/wp-content/plugins/revslider/public/assets/css/rs6.css?ver=6.3.5' type='text/css' media='all' />
<style id='rs-plugin-settings-inline-css' type='text/css'>
#rs-demo-id {}
</style>
<style id='woocommerce-inline-inline-css' type='text/css'>
.woocommerce form .form-row .required { visibility: visible; }
</style>
<link rel='stylesheet' id='js_composer_front-css'  href='https://kanni.wpengine.com/wp-content/plugins/js_composer/assets/css/js_composer.min.css?ver=6.5.0' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/style.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-base-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/base.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-grid-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/grid.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-widget-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/widget.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-layout-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/layout.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-blog-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/blog.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-contact-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/contact.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-custom-class-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/custom-class.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-browsers-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/browsers.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='prettyphoto-css'  href='https://kanni.wpengine.com/wp-content/plugins/js_composer/assets/lib/prettyphoto/css/prettyPhoto.min.css?ver=6.5.0' type='text/css' media='all' />
<link rel='stylesheet' id='mcustomscrollbar-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/jquery.mCustomScrollbar.min.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='custom-font-awesome-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/font-awesome.min.css?ver=4.3.0' type='text/css' media='all' />
<link rel='stylesheet' id='pe-icon-7-stroke-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/pe-icon-7-stroke.css?ver=5.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='stroke-gap-icons-style-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/stroke-gap-icons-style.css?ver=5.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='icon-moon-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/icon-moon.css?ver=5.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='material-design-iconic-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/material-design-iconic-font.min.css?ver=5.7.5' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-default-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/woocommerce-default.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type1-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type1-fashion.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type4-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type4-hosting.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type8-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type8-insurance.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type10-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type10-medical.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type11-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type11-model.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type12-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type12-attorney.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type13-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type13-architecture.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type14-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type14-fitness.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type16-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type16-photography.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type17-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type17-restaurant.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type20-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type20-yoga.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-type21-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce/type21-styleshop.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-woo-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/woocommerce.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-customevent-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/tribe-events/custom.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-cookie-css-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/cookieconsent.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-popup-css-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/magnific/magnific-popup.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='kanni-custom-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/custom.css?ver=2.3' type='text/css' media='all' />
<style id='kanni-custom-inline-css' type='text/css'>
.dt-sc-menu-sorting a { color: rgba(133,194,38, 0.6) }.dt-sc-team.type2 .dt-sc-team-thumb .dt-sc-team-thumb-overlay, .dt-sc-hexagon-image span:before, .dt-sc-keynote-speakers .dt-sc-speakers-thumb .dt-sc-speakers-thumb-overlay {  background: rgba(133,194,38, 0.9) }.dt-sc-primary-trans {  background: rgba(133,194,38, 0.85) }.portfolio .image-overlay, .recent-portfolio-widget ul li a:before, .dt-sc-image-caption.type2:hover .dt-sc-image-content, .dt-sc-fitness-program-short-details-wrapper .dt-sc-fitness-program-short-details { background: rgba(133,194,38, 0.9) }.dt-sc-icon-box.type10 .icon-wrapper:before, .dt-sc-contact-info.type4 span:after, .dt-sc-pr-tb-col.type2 .dt-sc-tb-header:before { box-shadow:5px 0px 0px 0px #85c226}.dt-sc-icon-box.type10:hover .icon-wrapper:before { box-shadow:7px 0px 0px 0px #85c226}.dt-sc-counter.type6 .dt-sc-couter-icon-holder:before { box-shadow:5px 1px 0px 0px #85c226}.dt-sc-button.with-shadow.white, .dt-sc-pr-tb-col.type2 .dt-sc-buy-now a { box-shadow:3px 3px 0px 0px #85c226}.dt-sc-icon-box.type3.circle{ border-color:rgba(133,194,38, 0.5) }.dt-sc-icon-box.type3.circle {
				-webkit-box-shadow: 0px 0px 10px 20px #85c226 inset;
				-moz-box-shadow: 0px 0px 10px 20px #85c226 inset;
				-ms-box-shadow: 0px 0px 10px 20px #85c226 inset;
				-o-box-shadow: 0px 0px 10px 20px #85c226 inset;
				box-shadow: 0px 0px 10px 20px #85c226 inset;					
			}.dt-sc-restaurant-events-list .dt-sc-restaurant-event-details h6:before { border-bottom-color: rgba(133,194,38,0.6) }.portfolio.type4 .image-overlay, .dt-sc-timeline-section.type4 .dt-sc-timeline-thumb-overlay, .dt-sc-yoga-classes .dt-sc-yoga-classes-image-wrapper:before, .dt-sc-yoga-course .dt-sc-yoga-course-thumb-overlay, .dt-sc-yoga-program .dt-sc-yoga-program-thumb-overlay, .dt-sc-yoga-pose .dt-sc-yoga-pose-thumb:before, .dt-sc-yoga-teacher .dt-sc-yoga-teacher-thumb:before, .dt-sc-doctors .dt-sc-doctors-thumb-overlay, .dt-sc-event-addon > .dt-sc-event-addon-date, .dt-sc-course .dt-sc-course-overlay, .dt-sc-process-steps .dt-sc-process-thumb-overlay { background: rgba(133,194,38,0.85) }@media only screen and (max-width: 767px) { .dt-sc-contact-info.type4:after, .dt-sc-icon-box.type10 .icon-content h4:after, .dt-sc-counter.type6.last h4::before, .dt-sc-counter.type6 h4::after { background-color:#85c226} }@media only screen and (max-width: 767px) { .dt-sc-timeline-section.type2, .dt-sc-timeline-section.type2::before { border-color:#85c226} }.woocommerce ul.products li.product .woo-type1 .star-rating:before, .woocommerce ul.products li.product .woo-type1 .star-rating span:before, .woocommerce ul.products li.product .woo-type1 .star-rating:before, .woocommerce ul.products li.product .woo-type1 .star-rating span:before, .woocommerce .woo-type1 .star-rating:before, .woocommerce .woo-type1 .star-rating span:before, .woocommerce .woo-type1 .star-rating:before, .woocommerce .woo-type1 .star-rating span:before { color: rgba(133,194,38, 0.75) }.woocommerce ul.products li.product:hover .woo-type8 .product-content, .woocommerce ul.products li.product-category:hover .woo-type8 .product-thumb .image:after, .woocommerce ul.products li.product:hover .woo-type8 .product-content, .woocommerce ul.products li.product-category:hover .woo-type8 .product-thumb .image:after, .woocommerce ul.products li.product:hover .woo-type13 .product-content, .woocommerce ul.products li.product:hover .woo-type13 .product-content, .woocommerce ul.products li.product.instock:hover .woo-type13 .on-sale-product .product-content, .woocommerce ul.products li.product.instock:hover .woo-type13 .on-sale-product .product-content, .woocommerce ul.products li.product.outofstock:hover .woo-type13 .out-of-stock-product .product-content, .woocommerce ul.products li.product.outofstock:hover .woo-type13 .out-of-stock-product .product-content, .woocommerce ul.products li.product-category:hover .woo-type13 .product-thumb .image:after, .woocommerce ul.products li.product-category:hover .woo-type13 .product-thumb .image:after { background-color: rgba(133,194,38, 0.75) }.woocommerce ul.products li.product:hover .woo-type8 .product-content:after, .woocommerce ul.products li.product:hover .woo-type8 .product-content:after {
				border-color : rgba( 133,194,38, 0.75 ) rgba(133,194,38, 0.75 ) rgba(255, 255, 255, 0.35) rgba(255, 255, 255, 0.35)
			}ul.products li.product:hover .woo-type11 .product-wrapper {
				-webkit-box-shadow: 0 0 0 3px #85c226;
				-moz-box-shadow: 0 0 0 3px #85c226;
				-ms-box-shadow: 0 0 0 3px #85c226;
				-o-box-shadow: 0 0 0 3px #85c226;
				box-shadow: 0 0 0 3px #85c226;
			}.woo-type12 ul.products li.product .product-details {
				-webkit-box-shadow: 0 -3px 0 0 #85c226 inset;
				-moz-box-shadow: 0 -3px 0 0 #85c226 inset;
				-ms-box-shadow: 0 -3px 0 0 #85c226 inset;
				-o-box-shadow: 0 -3px 0 0 #85c226 inset;
				box-shadow: 0 -3px 0 0 #85c226 inset;
			}ul.products li.product .woo-type14 .product-details, ul.products li.product .woo-type14 .product-details h5:after {
				-webkit-box-shadow: 0 0 0 2px #85c226 inset;
				-moz-box-shadow: 0 0 0 2px #85c226 inset;
				-ms-box-shadow: 0 0 0 2px #85c226 inset;
				-o-box-shadow: 0 0 0 2px #85c226 inset;
				box-shadow: 0 0 0 2px #85c226 inset;					
			}ul.products li.product-category:hover .product-wrapper {
				-webkit-box-shadow: 0 0 0 20px #85c226;
				-moz-box-shadow: 0 0 0 20px #85c226;
				-ms-box-shadow: 0 0 0 20px #85c226;
				-o-box-shadow: 0 0 0 20px #85c226;
				box-shadow: 0 0 0 20px #85c226;
			}.dt-sc-event-month-thumb .dt-sc-event-read-more, .dt-sc-training-thumb-overlay{ background: rgba(75,116,11,0.85) }@media only screen and (max-width: 767px) { .dt-sc-highlight .dt-sc-testimonial.type6 .dt-sc-testimonial-author:after,.dt-sc-highlight .dt-sc-testimonial.type6 .dt-sc-testimonial-author:after,.skin-highlight .dt-sc-testimonial.type6 .dt-sc-testimonial-author:after { background-color:#4b740b} }ul.products li.product:hover .woo-type8 .product-details h5:after { border-color: rgba(0, 0, 0, 0) rgba(0, 0, 0, 0) #4b740b rgba(0, 0, 0, 0); }ul.products li.product .woo-type20 .product-thumb a.add_to_cart_button:hover, ul.products li.product .woo-type20 .product-thumb a.button.product_type_simple:hover, ul.products li.product .woo-type20 .product-thumb a.button.product_type_variable:hover, ul.products li.product .woo-type20 .product-thumb a.added_to_cart.wc-forward:hover, ul.products li.product .woo-type20 .product-thumb a.add_to_wishlist:hover, ul.products li.product .woo-type20 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, ul.products li.product .woo-type20 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, ul.products li.product:hover .woo-type20 .product-wrapper, .woocommerce ul.products li.product .woo-type20 .product-buttons-wrapper a.yith-wcqv-button:hover, .woocommerce ul.products li.product .woo-type20 .product-buttons-wrapper a.yith-woocompare-button:hover { background-color: rgba(75,116,11,0.5 )}.woocommerce ul.products li.product:hover .woo-type20 .product-buttons-wrapper { background-color: rgba(75,116,11, 0.3); }.dt-sc-faculty .dt-sc-faculty-thumb-overlay { background: rgba(106,155,33,0.9) }ul.products li.product:hover .woo-type1 .product-thumb:after { 
				-webkit-box-shadow: 0 0 0 10px rgba(106,155,33,0.35) inset;
				-moz-box-shadow: 0 0 0 10px rgba(106,155,33,0.35) inset;
				-ms-box-shadow: 0 0 0 10px rgba(106,155,33,0.35) inset;
				-o-box-shadow: 0 0 0 10px rgba(106,155,33,0.35) inset;
				box-shadow: 0 0 0 10px rgba(106,155,33,0.35) inset;
			}ul.products li.product .woo-type20 .product-wrapper {
				-webkit-box-shadow: 0 0 0 5px rgba(106,155,33,0.75) inset;
				-moz-box-shadow: 0 0 0 5px rgba(106,155,33,0.75) inset;
				-ms-box-shadow: 0 0 0 5px rgba(106,155,33,0.75) inset;
				-o-box-shadow: 0 0 0 5px rgba(106,155,33,0.75) inset;
				box-shadow: 0 0 0 5px rgba(106,155,33,0.75) inset;					
			}@-webkit-keyframes color-change { 0% { color:#85c226; } 50% { color:#4b740b; }  100% { color:#6a9b21; } }@-moz-keyframes color-change { 0% { color:#85c226; } 50% { color:#4b740b; } 100% { color:#6a9b21; } }@-ms-keyframes color-change { 0% { color:#85c226; } 50% { color:#4b740b; } 100% { color:#6a9b21; }	}@-o-keyframes color-change { 0% { color:#85c226; } 50% { color:#4b740b; } 100% { color:#6a9b21; }	}@keyframes color-change { 0% { color:#85c226; } 50% { color:#4b740b; } 100% { color:#6a9b21; }	}
</style>
<link rel='stylesheet' id='kanni-gutenberg-css'  href='https://kanni.wpengine.com/wp-content/themes/kanni/css/gutenberg.css?ver=2.3' type='text/css' media='all' />
<link rel='stylesheet' id='popupStyle-css'  href='https://kanni.wpengine.com/wp-content/plugins/contact-form-7-popup-response//colorbox/colorbox.css?ver=5.7.5' type='text/css' media='all' />
<script type='text/javascript' src='https://kanni.wpengine.com/wp-includes/js/jquery/jquery.min.js?ver=3.5.1' id='jquery-core-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-includes/js/jquery/jquery-migrate.min.js?ver=3.3.2' id='jquery-migrate-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/revslider/public/assets/js/rbtools.min.js?ver=6.3.5' id='tp-tools-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/revslider/public/assets/js/rs6.min.js?ver=6.3.5' id='revmin-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/woocommerce/assets/js/jquery-blockui/jquery.blockUI.min.js?ver=2.70' id='jquery-blockui-js'></script>
<script type='text/javascript' id='wc-add-to-cart-js-extra'>
/* <![CDATA[ */
var wc_add_to_cart_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","i18n_view_cart":"View cart","cart_url":"https:\/\/kanni.wpengine.com\/cart\/","is_cart":"","cart_redirect_after_add":"no"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/woocommerce/assets/js/frontend/add-to-cart.min.js?ver=4.8.1' id='wc-add-to-cart-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/js_composer/assets/js/vendors/woocommerce-add-to-cart.js?ver=6.5.0' id='vc_woocommerce-add-to-cart-js-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/modernizr.custom.js?ver=5.7.5' id='modernizr-custom-js'></script>
<link rel="https://api.w.org/" href="https://kanni.wpengine.com/wp-json/" /><link rel="alternate" type="application/json" href="https://kanni.wpengine.com/wp-json/wp/v2/pages/237" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="https://kanni.wpengine.com/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="https://kanni.wpengine.com/wp-includes/wlwmanifest.xml" /> 
<link rel="canonical" href="index.html" />
<link rel='shortlink' href='https://kanni.wpengine.com/?p=237' />
<link rel="alternate" type="application/json+oembed" href="https://kanni.wpengine.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fkanni.wpengine.com%2Fcontact%2F" />
<link rel="alternate" type="text/xml+oembed" href="https://kanni.wpengine.com/wp-json/oembed/1.0/embed?url=https%3A%2F%2Fkanni.wpengine.com%2Fcontact%2F&amp;format=xml" />
	<noscript><style>.woocommerce-product-gallery{ opacity: 1 !important; }</style></noscript>
	<style type="text/css">.recentcomments a{display:inline !important;padding:0 !important;margin:0 !important;}</style><meta name="generator" content="Powered by WPBakery Page Builder - drag and drop page builder for WordPress."/>
<meta name="generator" content="Powered by Slider Revolution 6.3.5 - responsive, Mobile-Friendly Slider Plugin for WordPress with comfortable drag and drop interface." />
<link rel="icon" href="https://kanni.wpengine.com/wp-content/uploads/2018/07/favicon.png" sizes="32x32" />
<link rel="icon" href="https://kanni.wpengine.com/wp-content/uploads/2018/07/favicon.png" sizes="192x192" />
<link rel="apple-touch-icon" href="https://kanni.wpengine.com/wp-content/uploads/2018/07/favicon.png" />
<meta name="msapplication-TileImage" content="https://kanni.wpengine.com/wp-content/uploads/2018/07/favicon.png" />
<script type="text/javascript">function setREVStartSize(e){
			//window.requestAnimationFrame(function() {				 
				window.RSIW = window.RSIW===undefined ? window.innerWidth : window.RSIW;	
				window.RSIH = window.RSIH===undefined ? window.innerHeight : window.RSIH;	
				try {								
					var pw = document.getElementById(e.c).parentNode.offsetWidth,
						newh;
					pw = pw===0 || isNaN(pw) ? window.RSIW : pw;
					e.tabw = e.tabw===undefined ? 0 : parseInt(e.tabw);
					e.thumbw = e.thumbw===undefined ? 0 : parseInt(e.thumbw);
					e.tabh = e.tabh===undefined ? 0 : parseInt(e.tabh);
					e.thumbh = e.thumbh===undefined ? 0 : parseInt(e.thumbh);
					e.tabhide = e.tabhide===undefined ? 0 : parseInt(e.tabhide);
					e.thumbhide = e.thumbhide===undefined ? 0 : parseInt(e.thumbhide);
					e.mh = e.mh===undefined || e.mh=="" || e.mh==="auto" ? 0 : parseInt(e.mh,0);		
					if(e.layout==="fullscreen" || e.l==="fullscreen") 						
						newh = Math.max(e.mh,window.RSIH);					
					else{					
						e.gw = Array.isArray(e.gw) ? e.gw : [e.gw];
						for (var i in e.rl) if (e.gw[i]===undefined || e.gw[i]===0) e.gw[i] = e.gw[i-1];					
						e.gh = e.el===undefined || e.el==="" || (Array.isArray(e.el) && e.el.length==0)? e.gh : e.el;
						e.gh = Array.isArray(e.gh) ? e.gh : [e.gh];
						for (var i in e.rl) if (e.gh[i]===undefined || e.gh[i]===0) e.gh[i] = e.gh[i-1];
											
						var nl = new Array(e.rl.length),
							ix = 0,						
							sl;					
						e.tabw = e.tabhide>=pw ? 0 : e.tabw;
						e.thumbw = e.thumbhide>=pw ? 0 : e.thumbw;
						e.tabh = e.tabhide>=pw ? 0 : e.tabh;
						e.thumbh = e.thumbhide>=pw ? 0 : e.thumbh;					
						for (var i in e.rl) nl[i] = e.rl[i]<window.RSIW ? 0 : e.rl[i];
						sl = nl[0];									
						for (var i in nl) if (sl>nl[i] && nl[i]>0) { sl = nl[i]; ix=i;}															
						var m = pw>(e.gw[ix]+e.tabw+e.thumbw) ? 1 : (pw-(e.tabw+e.thumbw)) / (e.gw[ix]);					
						newh =  (e.gh[ix] * m) + (e.tabh + e.thumbh);
					}				
					if(window.rs_init_css===undefined) window.rs_init_css = document.head.appendChild(document.createElement("style"));					
					document.getElementById(e.c).height = newh+"px";
					window.rs_init_css.innerHTML += "#"+e.c+"_wrapper { height: "+newh+"px }";				
				} catch(e){
					console.log("Failure at Presize of Slider:" + e)
				}					   
			//});
		  };</script>
		<style type="text/css" id="wp-custom-css">
			@media only screen and (max-width: 991px) and (min-width: 768px){
.vc_column_container.last .dt-sc-image-flip img {
    max-width: 50%;
}
}
		</style>
		<style id="kirki-inline-styles">.has-primary-background-color,dt-inline-modal > h4{background-color:#85c226;}.has-primary-color{color:#85c226;}a, h1 a:hover, h2 a:hover, h3 a:hover, h4 a:hover, h5 a:hover, h6 a:hover, .breadcrumb a:hover{color:#85c226;}.dt-header-menu ul.dt-primary-nav > li:hover > a, .dt-header-menu ul.dt-primary-nav > li.current_page_ancestor > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li:hover > a, .dt-header-menu ul.dt-primary-nav > li.current_page_item > a, .dt-header-menu ul.dt-primary-nav > li.current-menu-item > a, .dt-header-menu ul.dt-primary-nav > li.current-page-ancestor > a, .dt-header-menu ul.dt-primary-nav > li.current-menu-ancestor > a, .no-header-menu ul > li:hover > a, .no-header-menu ul li ul.sub-menu li:hover > a, .no-header-menu ul > li.current_page_item > a, .no-header-menu ul > li.current-menu-item > a, .no-header-menu ul > li.current-page-ancestor > a, .no-header-menu ul > li.current-menu-ancestor > a, .no-header-menu ul li ul.children li:hover > a, .no-header-menu ul li ul.children li > a:hover, .mobile-menu ul.dt-primary-nav > li:hover > a, .mobile-menu ul.dt-primary-nav li ul.sub-menu li:hover > a, .mobile-menu ul.dt-primary-nav > li.current_page_item > a, .mobile-menu ul.dt-primary-nav > li.current-menu-item > a, .mobile-menu ul.dt-primary-nav > li.current-page-ancestor > a, .mobile-menu ul.dt-primary-nav > li.current-menu-ancestor > a, .menu-icons-wrapper .overlay-search #searchform:before, #header .header-25 .dt-sc-sociable:before, #header .header-25 .menu-icons-wrapper .search a, #header .header-25 .cart-info:before, #header .header-25 .dt-header-menu .dt-primary-nav > li:before, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-menu-ancestor > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-page-ancestor > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-menu-item > a, .dt-header-menu ul.dt-primary-nav li ul.sub-menu li.current-page-item > a, .mobile-menu .dt-primary-nav li.menu-item-has-children .current-menu-ancestor .current-menu-item a, .mobile-menu .dt-primary-nav li.menu-item-has-children .current-menu-ancestor > a, /* New */ .no-header-menu ul li ul.sub-menu li:hover > a, .no-header-menu.dt-header-menu ul.sub-menu > li.current_page_item > a, .no-header-menu ul > li.current-menu-item > a, .no-header-menu ul > li.current-page-ancestor > a, .no-header-menu ul > li.current-menu-ancestor > a, .no-header-menu ul li ul.children li:hover > a, .no-header-menu ul li ul.children li > a:hover, .mobile-menu ul.dt-primary-nav > li:hover > a, .no-header-menu.dt-header-menu ul.sub-menu li.current_page_parent > a, .no-header-menu.dt-header-menu ul.dt-primary-nav li.current_page_parent > a{color:#85c226;}.blog-entry .entry-meta a:hover, .blog-entry.entry-date-left .entry-date a:hover, .blog-entry.entry-date-author-left .entry-date-author .comments:hover, .blog-entry.entry-date-author-left .entry-date-author .comments:hover i, .entry-meta-data p a:hover, .blog-entry.entry-date-author-left .entry-date-author .entry-author a:hover, .blog-entry.entry-date-author-left .entry-date-author .comments a:hover, .dt-sc-dark-bg .blog-medium-style.white-highlight .dt-sc-button.fully-rounded-border, .blog-entry.blog-thumb-style .entry-title h4 a:hover, .blog-entry.blog-thumb-style a.read-more:hover, .blog-entry .dt-sc-button.simple:hover, .blog-entry.bordered:hover .date, .blog-entry.post-info-within-image .entry-meta .entry-title h4 a:hover, .blog-entry.post-info-within-image .entry-meta a:hover, .blog-entry.post-info-within-image .entry-meta a:hover i, .blog-entry.post-standard .entry-meta .entry-info a:hover, .blog-entry.post-info-vertical-image .entry-meta .entry-info > *:hover, .blog-entry.post-info-vertical-image .entry-meta a:hover, .blog-entry.post-info-vertical-image .entry-meta .entry-info > *:hover i, .blog-entry.post-info-vertical-image .entry-meta .entry-title h4:hover a, .blog-entry.post-info-bottom-image .entry-meta .entry-info a:hover, .blog-entry.post-info-bottom-image .entry-meta .entry-info a:hover i, /* New */ .blog-entry.post-info-bottom-image .entry-meta-data p a:hover{color:#85c226;}.widget #wp-calendar td a:hover, .dt-sc-dark-bg .widget #wp-calendar td a:hover, .secondary-sidebar .widget ul li > a:hover, .dt-sc-practices-list li:before, .secondary-sidebar .type15 .widget.widget_recent_reviews ul li .reviewer, .secondary-sidebar .type15 .widget.widget_top_rated_products ul li .amount.amount, #main-menu .menu-item-widget-area-container .widget ul li > a:hover, #main-menu .dt-sc-dark-bg .menu-item-widget-area-container .widget ul li > a:hover, #main-menu .dt-sc-dark-bg .menu-item-widget-area-container .widget_recent_posts .entry-title h4 a:hover, #main-menu ul li.menu-item-simple-parent.dt-sc-dark-bg ul li a:hover, #main-menu .menu-item-widget-area-container .widget li:hover:before{color:#85c226;}#footer .footer-copyright .menu-links li a:hover, #footer .footer-copyright .copyright-left a:hover, #footer .dt-sc-dark-bg .recent-posts-widget li .entry-meta a:hover, #footer .dt-sc-dark-bg .entry-title h4 a:hover, #footer .dt-sc-dark-bg a:hover, .left-header-footer .dt-sc-sociable.filled li a, .footer-widgets a:hover, #footer a:hover, .dt-sc-skin-color, .dt-sc-skin-color a, #footer .wpcf7-form.bottom-bordered input[type="submit"], #footer .wpcf7-form.bottom-bordered button, #footer .wpcf7-form.bottom-bordered input[type="button"], #footer .wpcf7-form.bottom-bordered input[type="reset"], #footer h1 strong, #footer h2 strong, #footer h3 strong, #footer h4 strong, #footer h5 strong, #footer h6 strong, #footer .dt-sc-dark-bg.map-with-overlay .map-overlay.wpb_column .dt-sc-tabs-horizontal-container ul.dt-sc-tabs-horizontal > li > a:hover, #footer .dt-sc-dark-bg.map-with-overlay .map-overlay.wpb_column .dt-sc-tabs-horizontal-container ul.dt-sc-tabs-horizontal > li > a.current, #footer .dt-sc-light-bg.map-with-overlay .map-overlay.wpb_column .dt-sc-tabs-horizontal-container ul.dt-sc-tabs-horizontal > li > a:hover, #footer .dt-sc-light-bg.map-with-overlay .map-overlay.wpb_column .dt-sc-tabs-horizontal-container ul.dt-sc-tabs-horizontal > li > a.current, .footer-19 .blog-entry.blog-default-style .entry-meta .date, #footer .footer-19 .blog-entry.blog-default-style a.dt-sc-button.small, .footer-20 .widget .recent-posts-widget li .entry-meta p, #footer .footer-21 .dt-sc-sociable.partially-rounded li > a:hover > i, #footer .footer-22 .dt-sc-newsletter-section.type6 .dt-sc-subscribe-frm input[type="submit"], #footer .footer-22 .dt-sc-newsletter-section.type6 .dt-sc-subscribe-frm input[type="email"], #footer .footer-22 .dt-sc-newsletter-section.type6 .dt-sc-subscribe-frm input[type="text"], #footer .footer-24 .widget.widget_recent_entries ul li .post-date, #footer .footer-25.dt-sc-skin-highlight input[type="submit"], #footer .footer-25.dt-sc-skin-highlight button, #footer .footer-25.dt-sc-skin-highlight input[type="button"], #footer .footer-25.dt-sc-skin-highlight input[type="reset"], #footer .footer-29 .dt-sc-button.fully-rounded-border, .footer-29 .dt-sc-contact-info.type1:hover span, .footer-30 .dt-sc-contact-info.type1 span, #footer .footer-30 .dt-mc-subscribe form .btn-wrap.icon-only i, .footer-34 .wpb_column:hover h3:before, #footer .footer-27 .dt-sc-contact-info.type1 a:hover, #footer .footer-28.footer-copyright.dt-sc-dark-bg a:hover, /* New */ .dt-sc-contact-info.type1 span, .dt-sc-team.hide-social-show-on-hover.inverse-block .dt-sc-team-thumb-overlay h5, #footer .dt-privacy-wrapper a{color:#85c226;}.portfolio .image-overlay .links a:hover, .portfolio.type7 .image-overlay .links a, .project-details li a:hover, .portfolio-categories a:hover, .dt-portfolio-single-slider-wrapper #bx-pager a.active:hover:before, .dt-portfolio-single-slider-wrapper #bx-pager a, .portfolio.type8 .image-overlay .links a{color:#85c226;}.dt-skin-primary-color, .available-domains li span, .dt-sc-popular-procedures .details .duration, .dt-sc-popular-procedures .details .price, .dt-sc-text-with-icon span, blockquote.type4 > cite, .dt-sc-contact-info.type3 span, .dt-sc-pr-tb-col.type2 .dt-sc-buy-now a, .dt-sc-events-list .dt-sc-event-title h5 a, .woocommerce-MyAccount-navigation ul > li.is-active > a, .side-navigation.type5 ul.side-nav li.current_page_item a, .side-navigation.type5 ul.side-nav>li>a:hover, /* New */ .dt-sc-testimonial.special-testimonial-carousel .dt-sc-testimonial-author cite small, .dt-sc-testimonial.special-testimonial-carousel .dt-sc-testimonial-author cite small:before, .dt-sc-contact-info.bordered span, .enquiry_form input[type=submit], ul.dt-sc-fancy-list.listing li:before, .dt-sc-contact-info.type1 a:hover, .dt-sc-dark-bg .dt-skin-primary-color{color:#85c226;}.dt-sc-button.fully-rounded-border, .dt-sc-button.rounded-border, .dt-sc-button.bordered, .dt-sc-button.with-shadow.white, .dt-sc-skin-highlight .dt-sc-button.rounded-border:hover, .dt-sc-skin-highlight .dt-sc-button.bordered:hover, .dt-sc-dark-bg.skin-color .dt-sc-button.fully-rounded-border:hover{color:#85c226;}.dt-sc-icon-box.type1 .icon-wrapper .icon, .dt-sc-icon-box.type2 .icon-wrapper .icon, .dt-sc-icon-box.type4 .icon-wrapper span, .dt-sc-icon-box.type5:hover .icon-content h4 a, .dt-sc-icon-box.type5.no-icon-bg .icon-wrapper span, .dt-sc-icon-box.type5.no-icon-bg:hover .icon-wrapper span, .dt-sc-icon-box.type10 .icon-wrapper span, .dt-sc-icon-box.type10:hover .icon-content h4, .dt-sc-icon-box.type13 .icon-content h4, .dt-sc-icon-box.type14 .icon-content h4, /* New */ .dt-sc-icon-box.type5 .icon-wrapper span, .dt-sc-icon-box.type3.circle:hover .icon-content h5, .dt-sc-icon-box.type3.circle .icon-wrapper span, .dt-sc-icon-box.type7.no-bg:hover .icon-content h4{color:#85c226;}.dt-sc-testimonial.type4 .dt-sc-testimonial-author cite, .dt-sc-testimonial.type5 .dt-sc-testimonial-author cite, .dt-sc-testimonial.type7 .dt-sc-testimonial-quote blockquote cite, .dt-sc-testimonial.type8 .dt-sc-testimonial-quote blockquote q:before, .dt-sc-testimonial.type8 .dt-sc-testimonial-quote blockquote q:after, .dt-sc-testimonial-special-wrapper:after, .dt-sc-special-testimonial-images-holder .dt-sc-testimonial-image.slick-current .dt-sc-testimonial-author cite, .dt-sc-team-carousel-wrapper .dt-sc-team-details .dt-sc-team-social li a:hover{color:#85c226;}ul.dt-sc-tabs-horizontal-frame > li > a.current, ul.dt-sc-tabs-horizontal > li > a.current, ul.dt-sc-tabs-horizontal > li > a:hover, ul.dt-sc-tabs-horizontal-frame > li > a:hover, .type7 ul.dt-sc-tabs-horizontal-frame > li > a.current{color:#85c226;}ul.dt-sc-tabs-vertical-frame > li > a:hover, ul.dt-sc-tabs-vertical-frame > li.current a, ul.dt-sc-tabs-vertical > li > a.current, .dt-sc-tabs-vertical-frame-container.type2 ul.dt-sc-tabs-vertical-frame > li > a.current:before, ul.dt-sc-tabs-vertical > li > a:hover{color:#85c226;}.dt-sc-toggle-frame-set > .dt-sc-toggle-accordion.active > a, .dt-sc-toggle-group-set .dt-sc-toggle.active > a, .dt-sc-toggle-frame h5.dt-sc-toggle-accordion.active a, .dt-sc-toggle-frame h5.dt-sc-toggle.active a, .dt-sc-toggle-panel h2 span, /* New */ .dt-sc-toggle-group-set.simple h5.dt-sc-toggle.active a{color:#85c226;}.dt-sc-title.with-sub-title h3, .dt-sc-title.script-with-sub-title h2, .dt-sc-title.with-two-color-stripe h2, .dt-sc-hexagon-title h2 span, #footer .footer-22 .dt-sc-title.script-with-sub-title h3, .side-navigation-content .dt-sc-title.script-with-sub-title strong{color:#85c226;}.dt-sc-image-with-caption h3 a, .dt-sc-image-caption.type3 .dt-sc-image-content h3, .dt-sc-event-image-caption .dt-sc-image-content h3, .dt-sc-image-caption.type8:hover .dt-sc-image-content h3 a:hover, .dt-sc-image-caption.type3 .dt-sc-image-wrapper .icon-wrapper span, /* New */ .dt-sc-image-caption.type1:hover .dt-sc-image-content h3 a{color:#85c226;}.dt-sc-team.hide-social-role-show-on-hover .dt-sc-team-social.rounded-square li a, .dt-sc-team.rounded .dt-sc-team-details .dt-sc-team-social li a:hover, .dt-sc-team.rounded.team_rounded_border:hover .dt-sc-team-details h4, .dt-sc-team.type2 .dt-sc-team-social.rounded-border li a:hover, .dt-sc-team.type2 .dt-sc-team-social.rounded-square li a:hover, .dt-sc-team.type2 .dt-sc-team-social.square-border li a:hover, .dt-sc-team.type2 .dt-sc-team-social.hexagon-border li a:hover, .dt-sc-team.type2 .dt-sc-team-social.diamond-square-border li a:hover, /* New */ .dt-sc-team.hide-social-show-on-hover.inverse-block .dt-sc-team-thumb-overlay .dt-sc-team-social li a:hover{color:#85c226;}.dt-sc-timeline .dt-sc-timeline-content h2 span, .dt-sc-hr-timeline-section.type2 .dt-sc-hr-timeline-content:hover h3, .dt-sc-timeline-section.type4 .dt-sc-timeline:hover .dt-sc-timeline-content h2{color:#85c226;}.dt-sc-sociable.diamond-square-border li:hover a, .dt-sc-sociable.hexagon-border li:hover a, .dt-sc-sociable.hexagon-with-border li:hover a, .dt-sc-sociable.no-margin li a{color:#85c226;}.dt-sc-counter.type3.diamond-square h4, .dt-sc-counter.type6:hover h4{color:#85c226;}th, input[type="submit"], button, input[type="reset"], .loader{background-color:#85c226;}.overlay .overlay-close, #header .header-25 .dt-sc-sociable li a, #header .header-27 .cart-info:before, #header .header-28 .cart-icon span, /* New */ .mobile-nav-container .menu-trigger{background-color:#85c226;}#footer .wpcf7-form.bottom-bordered input[type="submit"]:hover, #footer .wpcf7-form.bottom-bordered button:hover, #footer .wpcf7-form.bottom-bordered input[type="button"]:hover, #footer .wpcf7-form.bottom-bordered input[type="reset"]:hover, .footer-20 .footer-20-contact .vc_column-inner, #footer .footer-22 .dt-sc-newsletter-section.type6 .dt-sc-subscribe-frm input[type="submit"]:hover, #footer .footer-24 .widget.widget_recent_entries ul li:before, .footer-29 h3:before, .footer-28 .dt-sc-contact-info.type8:hover span{background-color:#85c226;}.entry-format a, .blog-entry.blog-medium-style:hover .entry-format a, .blog-entry.blog-medium-style.dt-blog-medium-highlight.dt-sc-skin-highlight, .blog-entry.blog-medium-style.dt-blog-medium-highlight.dt-sc-skin-highlight .entry-format a, ul.commentlist li .reply a:hover, .dt-sc-dark-bg .blog-medium-style.white-highlight .dt-sc-button.fully-rounded-border:hover, .post-nav-container .post-next-link a:hover, .post-nav-container .post-prev-link a:hover, .page-link > span, .page-link a:hover, .post-edit-link:hover, .vc_inline-link:hover, .pagination ul li a:hover, .pagination ul li span, .blog-entry.post-info-within-image .entry-meta .dt_scroll_down a:hover, .blog-entry.post-info-within-image .entry-meta p.category a:hover, .blog-entry.post-info-within-image .entry-meta-data p a:hover, .blog-entry.post-standard .entry-meta p.category a:hover, .blog-entry.post-standard .entry-meta-data p a:hover, .blog-entry.post-standard .entry-meta .entry-info .author:hover i.zmdi:after, .blog-entry.post-standard .entry-meta .entry-info .date:hover i.zmdi:after, .blog-entry.post-standard .entry-meta .entry-info .comments:hover i.zmdi:after, .blog-entry.post-standard .entry-meta .entry-info .views:hover i.zmdi:after, .blog-entry.post-standard .entry-meta .entry-info .likes:hover i.zmdi:after, .blog-entry.post-info-above-image .entry-meta p.category a:hover, .blog-entry.post-info-above-image .entry-meta-data p a:hover, .blog-entry.post-info-vertical-image .entry-meta p.category a:hover, .blog-entry.post-info-vertical-image .entry-meta-data p a:hover, .blog-entry.post-info-vertical-image .entry-thumb .entry-meta .entry-title h4:hover:after, .blog-entry.post-info-vertical-image .entry-thumb .entry-meta .entry-title h4:hover:before, .blog-entry.post-info-bottom-image .entry-meta-data p a:hover, /* New */ .blog-entry.entry-center-align .entry-format a, .blog-entry.entry-center-align .entry-details .dt-sc-button, .blog-entry.post-info-bottom-image .entry-meta.bottom-left p.category a, .blog-entry.entry-center-align .entry-details .dt-sc-button{background-color:#85c226;}.widget .dt-sc-newsletter-section.boxed .dt-sc-subscribe-frm input[type="submit"]:hover, .tagcloud a:hover, .widgettitle:before, .widget.widget_categories ul li > a:hover span, .widget.widget_archive ul li > a:hover span, .dt-sc-dark-bg .tagcloud a:hover, .dt-sc-dark-bg .widget.widget_categories ul li > a:hover span, #footer .dt-sc-dark-bg .widget.widget_categories ul li > a:hover span, #footer .dt-sc-dark-bg .widget.widget_archive ul li > a:hover span{background-color:#85c226;}.dt-sc-portfolio-sorting a.active-sort, .dt-sc-portfolio-sorting a:hover, .dt-sc-portfolio-sorting a:hover:before, .dt-sc-portfolio-sorting a:hover:after, .dt-sc-portfolio-sorting a.active-sort:before, .dt-sc-portfolio-sorting a.active-sort:after, .portfolio.type2 .image-overlay-details, .portfolio.type2 .image-overlay .links a:hover, .dt-sc-portfolio-sorting.type2, .dt-sc-portfolio-sorting.type2:before, .portfolio.type6 .image-overlay .links a:hover, .portfolio.type7 .image-overlay-details .categories a:before, .portfolio.type7 .image-overlay .links a:hover:before{background-color:#85c226;}.dt-skin-primary-bg, div[class*="dt-skin-primary-bg-opaque"]:not(.ult-vc-hide-row):before, div[class*="dt-skin-primary-bg-opaque"] .upb_row_bg:before, section[class*="dt-skin-primary-bg-opaque"]:before, ul.side-nav li a:hover:before, ul.side-nav > li.current_page_item > a:before, ul.side-nav > li > ul > li.current_page_item > a:before, ul.side-nav > li > ul > li > ul > li.current_page_item > a:before, .dt-sc-small-separator, .dt-sc-diamond-separator, .dt-sc-titled-box h6.dt-sc-titled-box-title, .carousel-arrows a:hover, .dt-sc-images-wrapper .carousel-arrows a:hover, .diamond-narrow-square-border li:hover:before, .dt-sc-sociable.hexagon-with-border li, .dt-sc-skin-highlight, .dt-sc-skin-highlight.extend-bg-fullwidth-left:after, .dt-sc-skin-highlight.extend-bg-fullwidth-right:after, .dt-skin-primary-bg.extend-bg-fullwidth-left:after, .dt-skin-primary-bg.extend-bg-fullwidth-right:after, .two-color-section:before, .dt-sc-readmore-plus-icon:hover:before, .dt-sc-readmore-plus-icon:hover:after, .dt-sc-contact-details-on-map .map-switch-icon, .dt-sc-content-with-hexagon-shape, .dt-sc-hexagons li .dt-sc-hexagon-overlay, .available-domains li .tdl:before, .available-domains li:hover .dt-sc-button, .domain-search-container .domain-search-form, .dt-sc-newsletter-section.type1 h2:before, .dt-sc-newsletter-section.type1 h2:after, .side-navigation.type2 ul.side-nav > li.current_page_item > a, .side-navigation.type3 ul.side-nav > li.current_page_item > a, .side-navigation.type3 ul.side-nav > li:hover > a, .side-navigation.type4 ul.side-nav li a:after, .side-navigation.type5 ul.side-nav li:after, .dt-mc-subscribe.only-border-bottom form:before, /* New */ .dt-sc-special-testimonial-container:before, .dt-sc-special-testimonial-container .alignright > h2:after, .fixed-form .sticky_form, .fixed-form .sticky_button, ul.side-nav li a:hover, .side-navigation.type1 ul.side-nav > li.current_page_item > a, .side-navigation.type1 ul.side-nav > li > ul > li.current_page_item > a, .side-navigation.type1 ul.side-nav > li > ul > li > ul > li.current_page_item > a, .dt-no-footer-builder-content, .dt-no-footer-builder-content:before, .dt-no-footer-builder-content:after{background-color:#85c226;}.dt-sc-button.filled, .dt-sc-button:hover, .dt-sc-button.rounded-border:hover, .dt-sc-button.bordered:hover, .dt-sc-button.fully-rounded-border:hover, .dt-sc-colored-big-buttons:hover, .dt-sc-colored-big-buttons span{background-color:#85c226;}.dt-sc-contact-info.type2:hover span, .dt-sc-contact-info.type3, .dt-sc-contact-info.type4 span:after, .dt-sc-contact-info.type4:before, .dt-sc-contact-info.type5 .dt-sc-contact-icon, .dt-sc-contact-info.type5:hover, .dt-sc-contact-info.type6, .dt-sc-contact-info.type7 span:after, .dt-sc-contact-info.type4:after, .university-contact-form .button-field i{background-color:#85c226;}.dt-sc-counter.type1 .icon-wrapper:before, .dt-sc-counter.type2 .dt-sc-couter-icon-holder, .dt-sc-counter.type3:hover .icon-wrapper, .dt-sc-counter.type3.diamond-square .dt-sc-couter-icon-holder .icon-wrapper:before, .dt-sc-counter.type4:hover .dt-sc-couter-icon-holder, .dt-sc-counter.type5:hover:after, .dt-sc-counter.type6 h4:before, .dt-sc-counter.type6:hover .dt-sc-couter-icon-holder:before, /* New */ .dt-sc-counter.type1.ico-as-bg .dt-sc-counter-number:before, .dt-sc-counter.type1.ico-as-bg:hover, .dt-sc-counter.type1.ico-as-bg .dt-sc-counter-number:before{background-color:#85c226;}.dt-sc-icon-box.type1 .icon-content h4:before, .dt-sc-icon-box.type3 .icon-wrapper span, .dt-sc-icon-box.type3.dt-sc-diamond:hover .icon-wrapper:after, .dt-sc-icon-box.type5.rounded-skin .icon-wrapper, .dt-sc-icon-box.type5.rounded:hover .icon-wrapper, .dt-sc-icon-box.type5:hover .icon-wrapper:before, .dt-sc-icon-box.type5.alter .icon-wrapper:before, .dt-sc-icon-box.type6 .icon-wrapper, .dt-sc-icon-box.type7 .icon-wrapper, .dt-sc-contact-info.type8:hover span, .dt-sc-icon-box.type10:hover .icon-wrapper:before, .dt-sc-icon-box.type10 .icon-content h4:before, .dt-sc-icon-box.type11:before, .dt-sc-icon-box.type12, .dt-sc-icon-box.type13:hover, .dt-sc-icon-box.type14:hover, .dt-sc-icon-box.type15 .icon-content, /* New */ .dt-sc-icon-box.type4:hover, .dt-sc-icon-box.type5:hover .icon-wrapper, .dt-sc-icon-box.type3.circle:before, .dt-sc-icon-box.type3.with-bg:hover, .dt-sc-icon-box.type3.with-bg .icon-content h4:after{background-color:#85c226;}.dt-sc-testimonial-wrapper .dt-sc-testimonial-bullets a:hover, .dt-sc-testimonial-wrapper .dt-sc-testimonial-bullets a.active{background-color:#85c226;}.dt-sc-title.with-two-color-bg:after, .dt-sc-triangle-title:after, .dt-sc-title.with-right-border-decor:after, .dt-sc-title.with-right-border-decor:before, .dt-sc-title.with-boxed, .mz-title .mz-title-content h2, .mz-title-content h3.widgettitle, .mz-title .mz-title-content:before, .mz-blog .comments a, .mz-blog div.vc_gitem-post-category-name, .mz-blog .ico-format, .side-navigation-content .dt-sc-wings-heading:after, /* New */ .dt-sc-title.with-two-border h2:before, .dt-sc-title.with-two-border h2:after, .dt-sc-title.with-two-border:after{background-color:#85c226;}.dt-sc-team-social.hexagon-border li:hover, .dt-sc-team .dt-sc-team-social.diamond-square-border li:hover, .dt-sc-team.hide-social-role-show-on-hover .dt-sc-team-social.rounded-square li:hover a, .dt-sc-infinite-portfolio-load-more, .dt-sc-single-hexagon .dt-sc-single-hexagon-overlay, .dt-sc-team-social.rounded-border li a:hover, .dt-sc-team-social.rounded-square li a, .dt-sc-team.hide-social-show-on-hover:hover .dt-sc-team-details, .dt-sc-team-social.square-border li a:hover, .dt-sc-team.rounded:hover .dt-sc-team-thumb:after, .dt-sc-team.hide-social-role-show-on-hover:hover .dt-sc-team-details, .dt-sc-team.hide-social-role-show-on-hover .dt-sc-team-social li:hover, .dt-sc-team.style2 .dt-sc-sociable li a, .dt-sc-team.style2 .dt-sc-team-details .view-details:hover, /* New */ .dt-sc-team.hide-social-show-on-hover.inverse-block .dt-sc-team-thumb-overlay h5:before{background-color:#85c226;}.dt-sc-pr-tb-col.minimal:hover .dt-sc-price, .dt-sc-pr-tb-col.minimal.selected .dt-sc-price, .dt-sc-pr-tb-col:hover .dt-sc-buy-now a, .dt-sc-pr-tb-col.selected .dt-sc-buy-now a, .dt-sc-pr-tb-col.minimal:hover .icon-wrapper:before, .dt-sc-pr-tb-col.minimal.selected .icon-wrapper:before, .dt-sc-pr-tb-col.type1:hover .dt-sc-tb-header, .dt-sc-pr-tb-col.type1.selected .dt-sc-tb-header, .dt-sc-pr-tb-col.type2 .dt-sc-tb-header .dt-sc-tb-title:before, .dt-sc-pr-tb-col.type2 .dt-sc-tb-content:before, .dt-sc-pr-tb-col.type2 .dt-sc-tb-content li .highlight, .dt-sc-pr-tb-col.type2:hover .dt-sc-price:before, .dt-sc-pr-tb-col.type2.selected .dt-sc-price:before, .dt-sc-pr-tb-col.type2:hover .dt-sc-buy-now a, /* New */ .trendy .dt-sc-pr-tb-col.type1.selected, .trendy .dt-sc-pr-tb-col.type1:hover, .smash .dt-sc-pr-tb-col.type1 .dt-sc-price:before, .smash .dt-sc-pr-tb-col.type1:hover, .smash .dt-sc-pr-tb-col.type1.selected{background-color:#85c226;}.dt-sc-hr-timeline-section.type1:before, .dt-sc-hr-timeline-section.type1 .dt-sc-hr-timeline .dt-sc-hr-timeline-content:after, .dt-sc-hr-timeline-section.type1 .dt-sc-hr-timeline-wrapper:before, .dt-sc-hr-timeline-section.type1 .dt-sc-hr-timeline-wrapper:after, .dt-sc-hr-timeline-section.type2 .dt-sc-hr-timeline-content h3:before, .dt-sc-hr-timeline-section.type2 .dt-sc-hr-timeline:hover .dt-sc-hr-timeline-thumb:before, /* New */ .dt-sc-timeline-section.type4:before, .dt-sc-timeline-section.type4 .dt-sc-timeline .dt-sc-timeline-content h2 span, .dt-sc-timeline-section.type4:after{background-color:#85c226;}.dt-sc-timeline-section.type2:before, .dt-sc-timeline-section.type3 .dt-sc-timeline .dt-sc-timeline-content h2:before, .dt-sc-timeline-section.type4 .dt-sc-timeline .dt-sc-timeline-content h2:before, .dt-sc-timeline-section.type4 .dt-sc-timeline:hover .dt-sc-timeline-thumb:before{background-color:#85c226;}.dt-sc-image-caption.type4:hover .dt-sc-button, .dt-sc-image-caption.type8 .dt-sc-image-content:before, .dt-sc-event-image-caption:hover, .dt-sc-image-caption.type5:hover h3{background-color:#85c226;}.dt-sc-tabs-horizontal-frame-container.type4 ul.dt-sc-tabs-horizontal-frame > li > a.current > span:after, .dt-sc-tabs-horizontal-frame-container.type5 ul.dt-sc-tabs-horizontal-frame > li > a.current, .dt-sc-tabs-horizontal-frame-container.type6 ul.dt-sc-tabs-horizontal-frame > li > a, .type8 ul.dt-sc-tabs-horizontal-frame > li > a.current, .type8 ul.dt-sc-tabs-horizontal-frame > li > a:hover, /* New */.filled ul.dt-sc-tabs-horizontal-frame > li > a.current, .filled ul.dt-sc-tabs-horizontal-frame > li > a:hover, .dt-sc-tabs-horizontal-frame-container.filled .dt-sc-tabs-horizontal-frame-content, .dt-inline-modal>h4{background-color:#85c226;}.dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a:hover, .dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a.current, .dt-sc-tabs-vertical-frame-container.type4 ul.dt-sc-tabs-vertical-frame > li > a:before, .dt-sc-tabs-vertical-frame-container.type4 ul.dt-sc-tabs-vertical-frame > li > a:after{background-color:#85c226;}.dt-sc-toggle-frame h5.dt-sc-toggle-accordion.active a:before, h5.dt-sc-toggle-accordion.active a:before, .dt-sc-toggle-frame h5.dt-sc-toggle.active a:before, h5.dt-sc-toggle.active a:before, .type2 .dt-sc-toggle-frame h5.dt-sc-toggle-accordion.active, .type2 .dt-sc-toggle-frame h5.dt-sc-toggle.active, .dt-sc-toggle-frame-set.type2 > h5.dt-sc-toggle-accordion.active:after, .dt-sc-toggle-icon, /* New */ .dt-sc-toggle-group-set.simple h5.dt-sc-toggle.active:after{background-color:#85c226;}.dt-sc-video-wrapper .video-overlay-inner a, .dt-sc-video-item:hover .dt-sc-vitem-detail, .dt-sc-video-item.active .dt-sc-vitem-detail, .type2 .dt-sc-video-item:hover, .type2 .dt-sc-video-item.active, .nicescroll-rails.dt-sc-skin{background-color:#85c226;}.dt-carousel-pagination a{background-color:#85c226;border-color:#85c226;}.live-chat a, .dt-bmi-inner-content tbody th, .dt-bmi-inner-content tbody tr:nth-child(2n+1) th, .dt-sc-menu .menu-categories a:before, .hotel-search-container form input[type="submit"]:hover, .hotel-search-container .selection-box:after, .dt-sc-training-details-overlay, .custom-navigation .vc_images_carousel .vc_carousel-indicators li, .dt-sc-doctors.style1 .dt-sc-doctors-thumb-wrapper .dt-sc-button, .dt-sc-doctors-single .dt-sc-doctors.style1 .dt-sc-doctors-details ul.dt-sc-sociable li a, .dt-sc-procedure-item:hover, .dt-sc-fitness-procedure-sorting a, ul.dt-sc-vertical-nav > li.active > a, ul.time-table > li, ul.time-slots > li a:hover, .dt-sc-available-times ul.time-slots, #wpsl-search-btn, #wpsl-stores li > p span, #wpsl-stores li > p, #wpsl-stores li > p ~ .wpsl-directions, .dt-sc-toggle-advanced-options span, /* New */ .mCSB_scrollTools .mCSB_draggerRail{background-color:#85c226;}#footer .wpcf7-form.bottom-bordered input[type="submit"]:hover, #footer .wpcf7-form.bottom-bordered button:hover, #footer .wpcf7-form.bottom-bordered input[type="button"]:hover, #footer .wpcf7-form.bottom-bordered input[type="reset"]:hover, #footer .footer-22 .dt-sc-newsletter-section.type6 .dt-sc-subscribe-frm input[type="submit"]:hover, .footer-26 .tagcloud a:hover{border-color:#85c226;}.blog-entry.entry-date-left .entry-date span, .blog-entry.blog-medium-style:hover .entry-format a, ul.commentlist li .reply a:hover, .dt-sc-dark-bg .blog-medium-style.white-highlight .dt-sc-button.fully-rounded-border, .pagination ul li a:hover, .pagination ul li span, .post-nav-container .post-next-link a:hover, .post-nav-container .post-prev-link a:hover, .page-link > span, .page-link a:hover, .blog-entry.bordered:hover .date, .blog-entry.bordered .entry-details:after, .blog-entry.bordered, .blog-entry.post-standard .entry-meta .entry-info > *:hover{border-color:#85c226;}.widget .dt-sc-newsletter-section.boxed, .widget .dt-sc-newsletter-section.boxed .dt-sc-subscribe-frm input[type="submit"], .tagcloud a:hover, .dt-sc-dark-bg .tagcloud a:hover, .secondary-sidebar .type3 .widgettitle, .secondary-sidebar .type6 .widgettitle, .secondary-sidebar .type13 .widgettitle:before, .secondary-sidebar .type14 .widgettitle, .secondary-sidebar .type16 .widgettitle{border-color:#85c226;}.dt-sc-portfolio-sorting a.active-sort, .dt-sc-portfolio-sorting a:hover, .portfolio.type7 .image-overlay .links a:before{border-color:#85c226;}.dt-sc-colored-big-buttons, .dt-sc-button.fully-rounded-border, .dt-sc-button.fully-rounded-border:hover, .dt-sc-button.rounded-border.black:hover, .dt-sc-button.bordered.black:hover, .dt-sc-button.bordered:hover, .dt-sc-button.rounded-border:hover, /* New */ .dt-sc-button.timeline-btn{border-color:#85c226;}.dt-sc-sociable.rounded-border li a:hover, .dt-sc-dark-bg .dt-sc-sociable.rounded-border li a:hover, .dt-sc-dark-bg .dt-sc-sociable.square-border li a:hover, .dt-sc-sociable.diamond-square-border li:hover, .diamond-narrow-square-border li:before{border-color:#85c226;}.dt-sc-team .dt-sc-team-social.diamond-square-border li:hover, .dt-sc-team-social.hexagon-border li:hover, .dt-sc-team-social.hexagon-border li:hover:before, .dt-sc-team-social.hexagon-border li:hover:after, .dt-sc-team-social.rounded-border li a:hover, .dt-sc-team-social.square-border li a:hover, .dt-sc-team.team_rounded_border.rounded:hover .dt-sc-team-thumb:before{border-color:#85c226;}.dt-sc-testimonial.type5 .dt-sc-testimonial-quote, .dt-sc-testimonial-images li.selected div, .dt-sc-testimonial-wrapper .dt-sc-testimonial-bullets a:hover, .dt-sc-testimonial-wrapper .dt-sc-testimonial-bullets a.active, .dt-sc-testimonial-wrapper .dt-sc-testimonial-bullets a.active:before, .dt-sc-testimonial-wrapper .dt-sc-testimonial-bullets a.active:hover:before, .dt-sc-testimonial.type5 .dt-sc-testimonial-author img{border-color:#85c226;}ul.dt-sc-tabs-horizontal > li > a.current, ul.dt-sc-tabs-vertical > li > a.current, .dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a:hover, .dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a.current{border-color:#85c226;}.type2 .dt-sc-toggle-frame h5.dt-sc-toggle-accordion.active, .type2 .dt-sc-toggle-frame h5.dt-sc-toggle.active{border-color:#85c226;}.dt-sc-hr-timeline-section.type1 .dt-sc-hr-timeline .dt-sc-hr-timeline-content:before, .dt-sc-timeline-section.type2 .dt-sc-timeline-image-wrapper, .dt-sc-timeline-section.type2 .dt-sc-timeline .dt-sc-timeline-content:after, .dt-sc-timeline-section.type2:after{border-color:#85c226;}.dt-sc-counter.type3 .icon-wrapper:before, .dt-sc-counter.type3.diamond-square, .dt-sc-counter.type5:hover:before, .dt-sc-counter.type5:hover:after, .dt-sc-counter.type6, .dt-sc-counter.type6 .dt-sc-couter-icon-holder:before{border-color:#85c226;}.dt-sc-contact-info.type2:hover, .dt-sc-contact-info.type4, .last .dt-sc-contact-info.type4{border-color:#85c226;}.dt-sc-icon-box.type5.no-icon .icon-content h4, .dt-sc-icon-box.type5.no-icon, .dt-sc-icon-box.type10, .dt-sc-icon-box.type10 .icon-wrapper:before, .dt-sc-icon-box.type3.dt-sc-diamond:hover .icon-wrapper:after, .dt-sc-icon-box.type11:before, /* New */ .dt-sc-icon-box.type4:hover, .dt-sc-icon-box.type5:hover .icon-wrapper span, .dt-sc-icon-box.type5 .icon-wrapper, .dt-sc-icon-box.type3.with-bg .icon-content h4:after, .dt-sc-icon-box.type3.with-bg:hover{border-color:#85c226;}.dt-sc-image-caption.type2 .dt-sc-image-content, .dt-sc-image-caption.type4, .dt-sc-image-caption.type4:hover .dt-sc-button, .dt-sc-icon-box.type10:hover .icon-wrapper:before, .dt-sc-image-caption.type5:hover h3, .dt-sc-image-caption.type5:hover img{border-color:#85c226;}.dt-skin-primary-border, .dt-sc-title.with-right-border-decor h2:before, .dt-sc-pr-tb-col.type2 .dt-sc-tb-header:before, .dt-sc-newsletter-section.type2 .dt-sc-subscribe-frm input[type="text"], .dt-sc-newsletter-section.type2 .dt-sc-subscribe-frm input[type="email"], .dt-sc-text-with-icon.border-bottom, .dt-sc-text-with-icon.border-right, .dt-sc-hexagons li:hover, .dt-sc-hexagons li:hover:before, .dt-sc-hexagons li:hover:after, .dt-sc-hexagons li, .dt-sc-hexagons li:before, .dt-sc-hexagons li .dt-sc-hexagon-overlay:before, .dt-sc-hexagons li:after, .dt-sc-hexagons li .dt-sc-hexagon-overlay:after, .dt-sc-single-hexagon, .dt-sc-single-hexagon:before, .dt-sc-single-hexagon .dt-sc-single-hexagon-overlay:before, .dt-sc-single-hexagon:after, .dt-sc-single-hexagon .dt-sc-single-hexagon-overlay:after, .dt-sc-single-hexagon:hover, .dt-sc-single-hexagon:hover:before, .dt-sc-single-hexagon:hover:after, .carousel-arrows a:hover, .vc_custom_carousel .slick-slider .slick-dots, .vc_custom_carousel .slick-slider:before, .dt-sc-team-navigation .dt-sc-team-pager-prev:before, .dt-sc-team-navigation .dt-sc-team-pager-next:before, ul.dt-sc-vertical-nav, ul.dt-sc-vertical-nav > li:first-child > a, .dt-sc-loading:before, .side-navigation.type2 ul.side-nav, .side-navigation.type2 ul.side-nav li, .side-navigation.type2 ul.side-nav li ul, .blog-entry.entry-overlay-style:hover .entry-details:before{border-color:#85c226;}.dt-sc-triangle-wrapper:hover .dt-sc-triangle-content:before, .dt-sc-pr-tb-col.type2 .dt-sc-tb-content:after, .dt-sc-content-with-hexagon-shape:after, .type7 ul.dt-sc-tabs-horizontal-frame > li > a.current:before, .type7 ul.dt-sc-tabs-horizontal-frame > li > a.current:after, .skin-highlight .dt-sc-tabs-horizontal-frame-container.type6 ul.dt-sc-tabs-horizontal-frame > li > a:before, .dt-sc-doctors-filter .selection-box:before{border-top-color:#85c226;}.dt-sc-up-arrow:before, .dt-sc-image-caption .dt-sc-image-wrapper .icon-wrapper:before, .dt-sc-triangle-wrapper.alter:hover .dt-sc-triangle-content:before, .dt-sc-content-with-hexagon-shape:before, .dt-sc-tabs-horizontal-frame-container.type3 ul.dt-sc-tabs-horizontal-frame > li > a.current, .dt-sc-tabs-horizontal-frame-container.type4 ul.dt-sc-tabs-horizontal-frame > li > a.current, #footer .footer-22 .dt-sc-newsletter-section.type6, /* New */ .dt-sc-contact-info.bordered h6{border-bottom-color:#85c226;}.type3 .dt-sc-toggle-frame .dt-sc-toggle-content, .dt-sc-tabs-vertical-frame-container.type3 ul.dt-sc-tabs-vertical-frame > li > a.current:before, .dt-sc-event-image-caption:hover .dt-sc-image-content:before, .side-navigation.type2 ul.side-nav > li.current_page_item > a:after, .side-navigation.type2 ul.side-nav > li > ul > li.current_page_item > a:after{border-left-color:#85c226;}#footer .footer-22.slope-bg.dt-sc-skin-highlight:before, #footer .footer-22 .dt-sc-newsletter-section.type6{border-right-color:#85c226;}.dt-sc-attorney-sorting, .dt-sc-menu-sorting a.active-sort, .dt-sc-menu .image-overlay .price, .hotel-search-container form input[type="submit"]{border-color:#85c226;}.error404 .type2 a.dt-sc-back, .error404 .type4 .error-box, .error404 .type4 .dt-sc-newsletter-section input[type="submit"], .error404 .type8 .dt-go-back{background-color:#85c226;}.error404 .type2 h2, .error404 .type8 h2, .error404 .type8 .dt-go-back:hover i{color:#85c226;}.under-construction.type4 .dt-sc-counter-wrapper, .under-construction.type1 .dt-sc-newsletter-section form input[type="submit"], .under-construction.type1 .dt-sc-counter-wrapper .counter-icon-wrapper:before, .under-construction.type2 .dt-sc-sociable > li:hover a, .under-construction.type7 .dt-sc-sociable > li:hover a, .under-construction.type3 .dt-sc-newsletter-section form input[type="submit"], .under-construction.type3 .dt-sc-sociable > li:hover a, .under-construction.type7 .dt-sc-counter-wrapper, .under-construction.type7 .dt-sc-newsletter-section form input[type="submit"]{background-color:#85c226;}.under-construction.type3 .dt-sc-sociable > li:hover a{border-color:#85c226;}.under-construction.type4 .wpb_wrapper > h2 span, .under-construction.type4 .read-more i, .under-construction.type4 .wpb_wrapper > h4:after, .under-construction.type4 .wpb_wrapper > h4:before, .under-construction.type1 .read-more span.fa, .under-construction.type1 .read-more a:hover, .under-construction.type2 .counter-icon-wrapper .dt-sc-counter-number, .under-construction.type2 h2, .under-construction.type2 .dt-sc-counter-wrapper h3, .under-construction.type2 .mailchimp-newsletter h3, .under-construction.type7 h2, .under-construction.type7 .mailchimp-newsletter h3, .under-construction.type3 p, .under-construction.type5 h2 span, .under-construction.type5 .dt-sc-counter-number, .under-construction.type5 footer .dt-sc-team-social li:hover a, .under-construction.type5 input[type="email"], .under-construction.type7 .aligncenter .wpb_text_column h2{color:#85c226;}#buddypress div.pagination .pagination-links span, #buddypress div.pagination .pagination-links a:hover, #buddypress #group-create-body #group-creation-previous, #item-header-content #item-meta > #item-buttons .group-button, #buddypress div#subnav.item-list-tabs ul li.feed a:hover, #buddypress div.activity-meta a:hover, #buddypress div.item-list-tabs ul li.selected a span, #buddypress .activity-list li.load-more a, #buddypress .activity-list li.load-newest a{background-color:#85c226;}#buddypress div.pagination .pagination-links span, #buddypress div.pagination .pagination-links a:hover, #buddypress #members-dir-list ul li:hover{border-color:#85c226;}#members-list.item-list.single-line li h5 span.small a.button, #buddypress div.item-list-tabs ul li.current a, #buddypress #group-create-tabs ul li.current a, #buddypress a.bp-primary-action:hover span, #buddypress div.item-list-tabs ul li.selected a, .widget.buddypress div.item-options a:hover, .widget.buddypress div.item-options a.selected, #footer .footer-widgets.dt-sc-dark-bg .widget.buddypress div.item-options a.selected, .widget.widget_bp_core_members_widget div.item .item-title a:hover, .widget.buddypress .bp-login-widget-user-links > div.bp-login-widget-user-link a:hover{color:#85c226;}#bbpress-forums li.bbp-header, .bbp-submit-wrapper #bbp_topic_submit, .bbp-reply-form #bbp_reply_submit, .bbp-pagination-links a:hover, .bbp-pagination-links span.current, #bbpress-forums #subscription-toggle a.subscription-toggle{background-color:#85c226;}.bbp-pagination-links a:hover, .bbp-pagination-links span.current{border-color:#85c226;}.bbp-forums .bbp-body .bbp-forum-info::before{color:#85c226;}#tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option a:hover, #tribe-bar-views .tribe-bar-views-list .tribe-bar-views-option.tribe-bar-active a:hover, #tribe-bar-form .tribe-bar-submit input[type="submit"], #tribe-bar-views .tribe-bar-views-list li.tribe-bar-active a, .tribe-events-calendar thead th, #tribe-events-content .tribe-events-tooltip h4, .tribe-events-calendar td.tribe-events-present div[id*="tribe-events-daynum-"], .tribe-events-read-more, #tribe-events .tribe-events-button, .tribe-events-button, .tribe-events-calendar td.tribe-events-present div[id*="tribe-events-daynum-"] > a, .tribe-events-back > a, #tribe_events_filters_toggle{background-color:#85c226;}.tribe-events-list .tribe-events-event-cost span{border-color:#85c226;}.tribe-grid-header, .tribe-grid-allday .tribe-events-week-allday-single, .tribe-grid-body .tribe-events-week-hourly-single{background-color:#85c226;}.type1.tribe_events .event-image-wrapper .event-datetime > span, .type3.tribe_events .event-date, .event-meta-tab ul.dt-sc-tabs-horizontal-frame > li > a{background-color:#85c226;}.type1 .event-schedule, .type1.tribe_events .nav-top-links a:hover, .type1.tribe_events .event-image-wrapper .event-datetime > i, .type1.tribe_events .event-image-wrapper .event-venue > i, .type1.tribe_events h4 a, .type2.tribe_events .date-wrapper p span, .type2.tribe_events h4 a, .type3.tribe_events .right-calc a:hover, .type3.tribe_events .tribe-events-sub-nav li a:hover, .type3.tribe_events .tribe-events-sub-nav li a span, .type4.tribe_events .data-wrapper p span, .type4.tribe_events .data-wrapper p i, .type4.tribe_events .event-organize h4 a, .type4.tribe_events .event-venue h4 a, .type5.tribe_events .event-details h3, .type5.tribe_events .event-organize h3, .type5.tribe_events .event-venue h3, .type5.tribe_events .data-wrapper p span, .data-wrapper p i, .type5.tribe_events .event-organize h4 a, .type5.tribe_events .event-venue h4 a{color:#85c226;}.dt-sc-event.type1 .dt-sc-event-thumb p, .dt-sc-event.type1 .dt-sc-event-meta:before, .dt-sc-event.type2:hover .dt-sc-event-meta, .dt-sc-event.type3 .dt-sc-event-date, .dt-sc-event.type3:hover .dt-sc-event-meta{background-color:#85c226;}.dt-sc-event.type4 .dt-sc-event-date:after{border-bottom-color:#85c226;}.dt-sc-event.type1 .dt-sc-event-meta p span, .dt-sc-event.type1:hover h2.entry-title a, .dt-sc-event.type3:hover h2.entry-title a, .dt-sc-event.type4 .dt-sc-event-date span{color:#85c226;}.widget.tribe_mini_calendar_widget .tribe-mini-calendar thead.tribe-mini-calendar-nav td, .widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-present, .widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-has-events.tribe-mini-calendar-today, .tribe-mini-calendar .tribe-events-has-events.tribe-events-present a:hover, .widget.tribe_mini_calendar_widget .tribe-mini-calendar td.tribe-events-has-events.tribe-mini-calendar-today a:hover, .dt-sc-dark-bg .widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-present, .dt-sc-dark-bg .widget.tribe_mini_calendar_widget .tribe-mini-calendar .tribe-events-has-events.tribe-mini-calendar-today, .dt-sc-dark-bg .tribe-mini-calendar .tribe-events-has-events.tribe-events-present a:hover, .dt-sc-dark-bg .widget.tribe_mini_calendar_widget .tribe-mini-calendar td.tribe-events-has-events.tribe-mini-calendar-today a:hover{background-color:#85c226;}.widget.tribe_mini_calendar_widget .tribe-mini-calendar thead.tribe-mini-calendar-nav td{border-color:#85c226;}.widget.tribe-events-countdown-widget .tribe-countdown-text a:hover{color:#85c226;}.woocommerce a.button, .woocommerce button.button, .woocommerce button, .woocommerce input.button, .woocommerce input[type=button], .woocommerce input[type=submit], .woocommerce #respond input#submit, .woocommerce a.button.alt, .woocommerce button.button.alt, .woocommerce input.button.alt, .woocommerce #respond input#submit.alt, .woocommerce .product .summary .add_to_wishlist, .woocommerce .wishlist_table .add_to_cart.button, .woocommerce .yith-wcwl-add-button a.add_to_wishlist, .woocommerce .yith-wcwl-popup-button a.add_to_wishlist, .woocommerce .wishlist_table a.ask-an-estimate-button, .woocommerce .wishlist-title a.show-title-form, .woocommerce .hidden-title-form a.hide-title-form, .woocommerce .yith-wcwl-wishlist-new button, .woocommerce .wishlist_manage_table a.create-new-wishlist, .woocommerce .wishlist_manage_table button.submit-wishlist-changes, .woocommerce .yith-wcwl-wishlist-search-form button.wishlist-search-button, .woocommerce .cart input.button, .woocommerce .shop_table th, .woocommerce div.product .woocommerce-tabs ul.tabs li.active a:after, .woocommerce-page a.button, .woocommerce-page button.button, .woocommerce-page button, .woocommerce-page input.button, .woocommerce-page input[type=button], .woocommerce-page input[type=submit], .woocommerce-page #respond input#submit, .woocommerce-page a.button.alt, .woocommerce-page button.button.alt, .woocommerce-page input.button.alt, .woocommerce-page #respond input#submit.alt, .woocommerce-page .product .summary .add_to_wishlist, .woocommerce-page .wishlist_table .add_to_cart.button, .woocommerce-page .yith-wcwl-add-button a.add_to_wishlist, .woocommerce-page .yith-wcwl-popup-button a.add_to_wishlist, .woocommerce-page .wishlist_table a.ask-an-estimate-button, .woocommerce-page .wishlist-title a.show-title-form, .woocommerce-page .hidden-title-form a.hide-title-form, .woocommerce-page .yith-wcwl-wishlist-new button, .woocommerce-page .wishlist_manage_table a.create-new-wishlist, .woocommerce-page .wishlist_manage_table button.submit-wishlist-changes, .woocommerce-page .yith-wcwl-wishlist-search-form button.wishlist-search-button, .woocommerce-page .cart input.button, .woocommerce-page .shop_table th, .woocommerce-page div.product .woocommerce-tabs ul.tabs li.active a:after, .woocommerce ul.products li.product .featured-tag, .woocommerce ul.products li.product:hover .featured-tag, .woocommerce.single-product .featured-tag, .woocommerce .widget_price_filter .price_slider_wrapper .ui-widget-content, .woocommerce ul.products li.product .default .product-buttons-wrapper .wc_inline_buttons > .wc_btn_inline a:hover, .woocommerce .view-mode a:hover, .woocommerce .view-mode a.active, .swiper-button-prev, .swiper-button-next, .woocommerce ul.products li.product .default .product-buttons-wrapper a.added_to_cart.wc-forward, .dt-carousel-navigation a, .woocommerce ul.products li.product .style-2 .product-buttons-wrapper a.added_to_cart, .woocommerce ul.products li.product .style-2 .product-thumb .yith-wcwl-wishlistexistsbrowse a, .woocommerce ul.products li.product .style-3 .product-buttons-wrapper a.added_to_cart, .woocommerce ul.products li.product .style-3 .product-thumb .yith-wcwl-wishlistexistsbrowse a{background-color:#85c226;}.woocommerce ul.products li.product .featured-tag:after, .woocommerce ul.products li.product:hover .featured-tag:after, .woocommerce.single-product .featured-tag:after{border-color:#85c226;}.swiper-pagination-bullets .swiper-pagination-bullet-active, .swiper-pagination.swiper-pagination-progress .swiper-pagination-progressbar{background:#85c226;}.woocommerce-checkout #payment ul.payment_methods li a:hover, .woocommerce ul.products li.product .default .product-details .product-price .price, .woocommerce .default span.price del .amount, .woocommerce .default .product-price del .amount, .woocommerce ul.products li.product .woo-type8 .product-buttons-wrapper a.yith-wcqv-button:hover, .woocommerce ul.products li.product .woo-type8 .product-buttons-wrapper a.yith-woocompare-button:hover, /* New */ ul.products li.product-category:hover .product-details a{color:#85c226;}ul.products li.product .woo-type1 .product-thumb a.add_to_cart_button:hover, ul.products li.product .woo-type1 .product-thumb a.button.product_type_simple:hover, ul.products li.product .woo-type1 .product-thumb a.button.product_type_variable:hover, ul.products li.product .woo-type1 .product-thumb a.added_to_cart.wc-forward:hover, ul.products li.product .woo-type1 .product-thumb a.add_to_wishlist:hover, ul.products li.product .woo-type1 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, ul.products li.product .woo-type1 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, .woocommerce ul.products li.product .woo-type1 .product-buttons-wrapper a.yith-wcqv-button:hover, .woocommerce ul.products li.product .woo-type1 .product-buttons-wrapper a.yith-woocompare-button:hover{background-color:#85c226;}.woo-type1 ul.products li.product-category:hover .product-details h5, .woo-type1 ul.products li.product-category:hover .product-details h5 .count, ul.products li.product .woo-type1 .product-details .product-price .amount, ul.products li.product .woo-type1 .product-details span.price, ul.products li.product .woo-type1 .product-details span.price del, ul.products li.product .woo-type1 .product-details span.price del .amount, ul.products li.product .woo-type1 .product-details span.price ins, ul.products li.product .woo-type1 .product-details span.price ins .amount, .woo-type1.woocommerce.single-product .product .summary .product_meta a:hover, .woo-type1.woocommerce div.product .woocommerce-tabs ul.tabs li.active a{color:#85c226;}ul.products li.product .woo-type4 .product-thumb a.add_to_cart_button:after, ul.products li.product .woo-type4 .product-thumb a.button.product_type_simple:after, ul.products li.product .woo-type4 .product-thumb a.button.product_type_variable:after, ul.products li.product .woo-type4 .product-thumb a.added_to_cart.wc-forward:after, ul.products li.product .woo-type4 .product-thumb a.add_to_wishlist:after, ul.products li.product .woo-type4 .product-thumb .yith-wcwl-wishlistaddedbrowse a:after, ul.products li.product .woo-type4 .product-thumb .yith-wcwl-wishlistexistsbrowse a:after, ul.products li.product .woo-type4 .product-details h5:after, .woocommerce ul.products li.product .woo-type4 .product-buttons-wrapper a.yith-wcqv-button:after, .woocommerce ul.products li.product .woo-type4 .product-buttons-wrapper a.yith-woocompare-button:after{background-color:#85c226;}ul.products li.product-category:hover .woo-type4 .product-details h5, ul.products li.product-category:hover .woo-type4 .product-details h5 .count{color:#85c226;}ul.products li.product .woo-type8 .product-details, ul.products li.product:hover .woo-type8 .product-details h5:before{background-color:#85c226;}ul.products li.product .woo-type8 .product-thumb a.add_to_cart_button:hover:before, ul.products li.product .woo-type8 .product-thumb a.button.product_type_simple:hover:before, ul.products li.product .woo-type8 .product-thumb a.button.product_type_variable:hover:before, ul.products li.product .woo-type8 .product-thumb a.added_to_cart.wc-forward:hover:before, ul.products li.product .woo-type8 .product-thumb a.add_to_wishlist:hover:before, ul.products li.product .woo-type8 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover:before, ul.products li.product .woo-type8 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover:before, ul.products li.product:hover .woo-type8 .product-details h5 a:hover{color:#85c226;}ul.products li.product .woo-type10 .product-thumb a.add_to_cart_button, ul.products li.product .woo-type10 .product-thumb a.button.product_type_simple, ul.products li.product .woo-type10 .product-thumb a.button.product_type_variable, ul.products li.product .woo-type10 .product-thumb a.added_to_cart.wc-forward, ul.products li.product .woo-type10 .product-thumb a.add_to_wishlist, ul.products li.product .woo-type10 .product-thumb .yith-wcwl-wishlistaddedbrowse a, ul.products li.product .woo-type10 .product-thumb .yith-wcwl-wishlistexistsbrowse a, ul.products li.product:hover .woo-type10 .product-details{background-color:#85c226;}ul.products li.product:hover .woo-type10 .product-wrapper{border-color:#85c226;}ul.products li.product:hover .woo-type10 .product-details:before, ul.products li.product:hover .woo-type10 .product-details:after{border-bottom-color:#85c226;}ul.products li.product .woo-type11 .product-thumb a.add_to_cart_button:hover, ul.products li.product .woo-type11 .product-thumb a.button.product_type_simple:hover, ul.products li.product .woo-type11 .product-thumb a.button.product_type_variable:hover, ul.products li.product .woo-type11 .product-thumb a.added_to_cart.wc-forward:hover, ul.products li.product .woo-type11 .product-thumb a.add_to_wishlist:hover, ul.products li.product .woo-type11 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, ul.products li.product .woo-type11 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, .woocommerce .woo-type11 div.product .woocommerce-tabs ul.tabs li.active a:after, ul.products li.product .woo-type11 .product-details, .woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-wcqv-button:hover, .woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-woocompare-button:hover{background-color:#85c226;}ul.products li.product .woo-type11 .product-thumb a.add_to_cart_button:before, ul.products li.product .woo-type11 .product-thumb a.button.product_type_simple:before, ul.products li.product .woo-type11 .product-thumb a.button.product_type_variable:before, ul.products li.product .woo-type11 .product-thumb a.added_to_cart.wc-forward:before, ul.products li.product .woo-type11 .product-thumb a.add_to_wishlist:before, ul.products li.product .woo-type11 .product-thumb .yith-wcwl-wishlistaddedbrowse a:before, ul.products li.product .woo-type11 .product-thumb .yith-wcwl-wishlistexistsbrowse a:before, .woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-wcqv-button, .woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-woocompare-button{color:#85c226;}.woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-wcqv-button:hover, .woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-woocompare-button:hover{border-color:#85c226;}.woo-type12 ul.products li.product .product-thumb a.add_to_cart_button, .woo-type12 ul.products li.product .product-thumb a.button.product_type_simple, .woo-type12 ul.products li.product .product-thumb a.button.product_type_variable, .woo-type12 ul.products li.product .product-thumb a.added_to_cart.wc-forward, .woo-type12 ul.products li.product .product-thumb a.add_to_wishlist, .woo-type12 ul.products li.product .product-thumb .yith-wcwl-wishlistaddedbrowse a, .woo-type12 ul.products li.product .product-thumb .yith-wcwl-wishlistexistsbrowse a, .woo-type12 ul.products li.product:hover .product-details, .woo-type12 ul.products li.product .product-details h5:after{background-color:#85c226;}ul.products li.product .woo-type13 .product-details h5:before{background-color:#85c226;}ul.products li.product .woo-type13 .product-thumb a.add_to_cart_button:hover:before, ul.products li.product .woo-type13 .product-thumb a.button.product_type_simple:hover:before, ul.products li.product .woo-type13 .product-thumb a.button.product_type_variable:hover:before, ul.products li.product .woo-type13 .product-thumb a.added_to_cart.wc-forward:hover:before, ul.products li.product .woo-type13 .product-thumb a.add_to_wishlist:hover:before, ul.products li.product .woo-type13 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover:before, ul.products li.product .woo-type13 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover:before, ul.products li.product:hover .woo-type13 .product-details h5 a, .woocommerce ul.products li.product .woo-type13 .product-buttons-wrapper a.yith-wcqv-button:hover:after, .woocommerce ul.products li.product .woo-type13 .product-buttons-wrapper a.yith-woocompare-button:hover:after{color:#85c226;}ul.products li.product:hover .woo-type14 .product-details, ul.products li.product .woo-type14 .product-details h5:before, ul.products li.product:hover .woo-type14 .product-details h5:after{background-color:#85c226;}ul.products li.product:hover .woo-type14 .product-details h5:after{border-color:#85c226;}ul.products li.product .woo-type16 .product-wrapper:before, ul.products li.product .woo-type16 .product-thumb a.add_to_cart_button:hover, ul.products li.product .woo-type16 .product-thumb a.button.product_type_simple:hover, ul.products li.product .woo-type16 .product-thumb a.button.product_type_variable:hover, ul.products li.product .woo-type16 .product-thumb a.added_to_cart.wc-forward:hover, ul.products li.product .woo-type16 .product-thumb a.add_to_wishlist:hover, ul.products li.product .woo-type16 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, ul.products li.product .woo-type16 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, .woo-type16.woocommerce .shop_table th, .woo-type16 .woocommerce .shop_table th, .woo-type16.woocommerce div.product .woocommerce-tabs ul.tabs li.active a:after{background-color:#85c226;}ul.products li.product .woo-type17 .product-thumb a.add_to_cart_button:hover:after, ul.products li.product .woo-type17 .product-thumb a.button.product_type_simple:hover:after, ul.products li.product .woo-type17 .product-thumb a.button.product_type_variable:hover:after, ul.products li.product .woo-type17 .product-thumb a.added_to_cart.wc-forward:hover:after, ul.products li.product .woo-type17 .product-thumb a.add_to_wishlist:hover:after, ul.products li.product .woo-type17 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover:after, ul.products li.product .woo-type17 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover:after, ul.products li.product:hover .woo-type17 .product-details, .woocommerce ul.products li.product .woo-type17 .product-buttons-wrapper a.yith-wcqv-button:hover:after, .woocommerce ul.products li.product .woo-type17 .product-buttons-wrapper a.yith-woocompare-button:hover:after{background-color:#85c226;}ul.products li.product:hover .woo-type17 .product-wrapper, ul.products li.product:hover .woo-type17 .product-thumb a.add_to_cart_button:after, ul.products li.product:hover .woo-type17 .product-thumb a.button.product_type_simple:after, ul.products li.product:hover .woo-type17 .product-thumb a.button.product_type_variable:after, ul.products li.product:hover .woo-type17 .product-thumb a.added_to_cart.wc-forward:after, ul.products li.product:hover .woo-type17 .product-thumb a.add_to_wishlist:after, ul.products li.product:hover .woo-type17 .product-thumb .yith-wcwl-wishlistaddedbrowse a:after, ul.products li.product:hover .woo-type17 .product-thumb .yith-wcwl-wishlistexistsbrowse a:after, ul.products li.product .woo-type17 .product-details h5 a:after, ul.products li.product-category .woo-type17 .product-details h5:after, ul.products li.product .woo-type17 .price, .woocommerce ul.products li.product:hover .woo-type17 .product-buttons-wrapper a.yith-wcqv-button:after, .woocommerce ul.products li.product:hover .woo-type17 .product-buttons-wrapper a.yith-woocompare-button:after{border-color:#85c226;}ul.products li.product .woo-type17 .product-thumb a.add_to_cart_button, ul.products li.product .woo-type17 .product-thumb a.button.product_type_simple, ul.products li.product .woo-type17 .product-thumb a.button.product_type_variable, ul.products li.product .woo-type17 .product-thumb a.added_to_cart.wc-forward, ul.products li.product .woo-type17 .product-thumb a.add_to_wishlist, ul.products li.product .woo-type17 .product-thumb .yith-wcwl-wishlistaddedbrowse a, ul.products li.product .woo-type17 .product-thumb .yith-wcwl-wishlistexistsbrowse a, ul.products li.product .woo-type17 .product-thumb a.add_to_cart_button:before, ul.products li.product .woo-type17 .product-thumb a.button.product_type_simple:before, ul.products li.product .woo-type17 .product-thumb a.button.product_type_variable:before, ul.products li.product .woo-type17 .product-thumb a.added_to_cart.wc-forward:before, ul.products li.product .woo-type17 .product-thumb a.add_to_wishlist:before, ul.products li.product .woo-type17 .product-thumb .yith-wcwl-wishlistaddedbrowse a:before, ul.products li.product .woo-type17 .product-thumb .yith-wcwl-wishlistexistsbrowse a:before, ul.products li.product .woo-type17 .product-details h5 a, ul.products li.product-category .woo-type17 .product-details h5, ul.products li.product-category .woo-type17 .product-details h5 .count, ul.products li.product .woo-type17 .product-details .product-price .amount, ul.products li.product .woo-type17 .product-details span.price, ul.products li.product .woo-type17 .product-details span.price del, ul.products li.product .woo-type17 .product-details span.price del .amount, ul.products li.product .woo-type17 .product-details span.price ins, ul.products li.product .woo-type17 .product-details span.price ins .amount, .woo-type17 .widget.woocommerce ul li:hover:before, .woocommerce ul.products li.product .woo-type17 .product-buttons-wrapper a.yith-wcqv-button:before, .woocommerce ul.products li.product .woo-type17 .product-buttons-wrapper a.yith-woocompare-button:before{color:#85c226;}ul.products li.product .woo-type20 .product-thumb a.add_to_cart_button, ul.products li.product .woo-type20 .product-thumb a.button.product_type_simple, ul.products li.product .woo-type20 .product-thumb a.button.product_type_variable, ul.products li.product .woo-type20 .product-thumb a.added_to_cart.wc-forward, ul.products li.product .woo-type20 .product-thumb a.add_to_wishlist, ul.products li.product .woo-type20 .product-thumb .yith-wcwl-wishlistaddedbrowse a, ul.products li.product .woo-type20 .product-thumb .yith-wcwl-wishlistexistsbrowse a, ul.products li.product .woo-type20 .product-wrapper:after, .woo-type20.woocommerce ul.products li.product .product-details h5, .woocommerce ul.products li.product .woo-type20 .product-details h5, ul.products li.product-category .woo-type20 .product-wrapper h3, .woocommerce ul.products li.product .woo-type20 .product-buttons-wrapper a.yith-wcqv-button, .woocommerce ul.products li.product .woo-type20 .product-buttons-wrapper a.yith-woocompare-button{border-color:#85c226;}ul.products li.product .woo-type20 .product-thumb a.add_to_cart_button:before, ul.products li.product .woo-type20 .product-thumb a.button.product_type_simple:before, ul.products li.product .woo-type20 .product-thumb a.button.product_type_variable:before, ul.products li.product .woo-type20 .product-thumb a.added_to_cart.wc-forward:before, ul.products li.product .woo-type20 .product-thumb a.add_to_wishlist:before, ul.products li.product .woo-type20 .product-thumb .yith-wcwl-wishlistaddedbrowse a:before, ul.products li.product .woo-type20 .product-thumb .yith-wcwl-wishlistexistsbrowse a:before, ul.products li.product .woo-type20 .product-details h5 a, ul.products li.product-category .woo-type20 .product-details h5, ul.products li.product-category .woo-type20 .product-details h5 .count, ul.products li.product .woo-type20 .product-details .product-price .amount, ul.products li.product .woo-type20 .product-details span.price, ul.products li.product .woo-type20 .product-details span.price del, ul.products li.product .woo-type20 .product-details span.price del .amount, ul.products li.product .woo-type20 .product-details span.price ins, ul.products li.product .woo-type20 .product-details span.price ins .amount, ul.products li.product .woo-type20 .product-details .product-rating-wrapper .star-rating:before, ul.products li.product .woo-type20 .product-details .product-rating-wrapper .star-rating span:before, .woocommerce ul.products li.product .woo-type20 .product-buttons-wrapper a.yith-wcqv-button:before, .woocommerce ul.products li.product .woo-type20 .product-buttons-wrapper a.yith-woocompare-button:before{color:#85c226;}.woocommerce ul.products li.product .woo-type21 .product-thumb a.add_to_cart_button:hover, .woocommerce ul.products li.product .woo-type21 .product-thumb a.button.product_type_simple:hover, .woocommerce ul.products li.product .woo-type21 .product-thumb a.button.product_type_variable:hover, .woocommerce ul.products li.product .woo-type21 .product-thumb a.added_to_cart.wc-forward:hover, .woocommerce ul.products li.product .woo-type21 .product-thumb a.add_to_wishlist:hover, .woocommerce ul.products li.product .woo-type21 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, .woocommerce ul.products li.product .woo-type21 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, .woo-type21.woocommerce ul.products li.product .product-thumb a.add_to_cart_button:hover, .woo-type21.woocommerce ul.products li.product .product-thumb a.button.product_type_simple:hover, .woo-type21.woocommerce ul.products li.product .product-thumb a.button.product_type_variable:hover, .woo-type21.woocommerce ul.products li.product .product-thumb a.added_to_cart.wc-forward:hover, .woo-type21.woocommerce ul.products li.product .product-thumb a.add_to_wishlist:hover, .woo-type21.woocommerce ul.products li.product .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, .woo-type21.woocommerce ul.products li.product .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, .woo-type21 .woocommerce a.button:hover, .woo-type21 .woocommerce button.button:hover, .woo-type21 .woocommerce button:hover, .woo-type21 .woocommerce input.button:hover, .woo-type21 .woocommerce input[type=button]:hover, .woo-type21 .woocommerce input[type=submit]:hover, .woo-type21 .woocommerce #respond input#submit:hover, .woo-type21 .woocommerce a.button.alt:hover, .woo-type21 .woocommerce button.button.alt:hover, .woo-type21 .woocommerce input.button.alt:hover, .woo-type21 .woocommerce #respond input#submit.alt:hover, .woo-type21 .woocommerce .product .summary .add_to_wishlist:hover, .woo-type21 .woocommerce .wishlist_table .add_to_cart.button:hover, .woo-type21 .woocommerce .yith-wcwl-add-button a.add_to_wishlist:hover, .woo-type21 .woocommerce .yith-wcwl-popup-button a.add_to_wishlist:hover, .woo-type21 .woocommerce .wishlist_table a.ask-an-estimate-button:hover, .woo-type21 .woocommerce .wishlist-title a.show-title-form:hover, .woo-type21 .woocommerce .hidden-title-form a.hide-title-form:hover, .woo-type21 .woocommerce .yith-wcwl-wishlist-new button:hover, .woo-type21 .woocommerce .wishlist_manage_table a.create-new-wishlist:hover, .woo-type21 .woocommerce .wishlist_manage_table button.submit-wishlist-changes:hover, .woo-type21 .woocommerce .yith-wcwl-wishlist-search-form button.wishlist-search-button:hover, .woo-type21 .woocommerce .cart input.button:hover, .woo-type21.woocommerce a.button:hover, .woo-type21.woocommerce button.button:hover, .woo-type21.woocommerce button:hover, .woo-type21.woocommerce input.button:hover, .woo-type21.woocommerce input[type=button]:hover, .woo-type21.woocommerce input[type=submit]:hover, .woo-type21.woocommerce #respond input#submit:hover, .woo-type21.woocommerce a.button.alt:hover, .woo-type21.woocommerce button.button.alt:hover, .woo-type21.woocommerce input.button.alt:hover, .woo-type21.woocommerce #respond input#submit.alt:hover, .woo-type21.woocommerce .product .summary .add_to_wishlist:hover, .woo-type21.woocommerce .wishlist_table .add_to_cart.button:hover, .woo-type21.woocommerce .yith-wcwl-add-button a.add_to_wishlist:hover, .woo-type21.woocommerce .yith-wcwl-popup-button a.add_to_wishlist:hover, .woo-type21.woocommerce .wishlist_table a.ask-an-estimate-button:hover, .woo-type21.woocommerce .wishlist-title a.show-title-form:hover, .woo-type21.woocommerce .hidden-title-form a.hide-title-form:hover, .woo-type21.woocommerce .yith-wcwl-wishlist-new button:hover, .woo-type21.woocommerce .wishlist_manage_table a.create-new-wishlist:hover, .woo-type21.woocommerce .wishlist_manage_table button.submit-wishlist-changes:hover, .woo-type21.woocommerce .yith-wcwl-wishlist-search-form button.wishlist-search-button:hover, .woo-type21.woocommerce .cart input.button:hover, .woo-type21 .woocommerce .product .summary .add_to_wishlist:hover:before, .woo-type21.woocommerce .product .summary .add_to_wishlist:hover:before{background-color:#85c226;}.woo-type21 .woocommerce .product .summary .add_to_wishlist:hover, .woo-type21.woocommerce .product .summary .add_to_wishlist:hover{color:#85c226;}.has-secondary-background-color{background-color:#4b740b;}.has-secondary-color{color:#4b740b;}.dt-skin-secondary-color, .blog-entry.entry-overlay-style .entry-title h4 a:hover, .blog-entry.entry-overlay-style .read-more-link:hover{color:#4b740b;}.dt-skin-secondary-bg, div[class*="dt-skin-secondary-bg-opaque"]:not(.ult-vc-hide-row):before, div[class*="dt-skin-secondary-bg-opaque"] .upb_row_bg:before, section[class*="dt-skin-secondary-bg-opaque"]:before, .dt-skin-secondary-bg.extend-bg-fullwidth-left:after, .dt-skin-secondary-bg.extend-bg-fullwidth-right:after, input[type="submit"]:hover, button:hover, input[type="reset"]:hover, .mz-blog .comments a:hover, .mz-blog div.vc_gitem-post-category-name:hover, .dt-sc-infinite-portfolio-load-more:hover, .dt-sc-button.filled:hover, .dt-sc-button.with-icon.icon-right.type1:hover, .dt-sc-counter.type2:hover .dt-sc-couter-icon-holder, .dt-sc-icon-box.type3:hover .icon-wrapper span, .dt-sc-newsletter-section.type2 .dt-sc-subscribe-frm input[type="submit"]:hover, .skin-highlight .dt-sc-testimonial.type6 .dt-sc-testimonial-author:before, .skin-highlight .dt-sc-testimonial.type6:after, .dt-sc-team-social.rounded-square li a:hover, .dt-sc-video-wrapper .video-overlay-inner a:hover, .side-navigation.type2 ul.side-nav li a:before, .side-navigation.type2 ul.side-nav > li.current_page_item > a:before, .side-navigation.type2 ul.side-nav > li > ul > li.current_page_item > a:before, .side-navigation.type2 ul.side-nav > li > ul > li > ul > li.current_page_item > a:before, /* New */ .blog-entry.entry-center-align .entry-format a:hover{background-color:#4b740b;}.dt-skin-secondary-border, .dt-sc-contact-info.type5 .dt-sc-contact-icon, .dt-sc-contact-info.type5 .dt-sc-contact-icon:before, .dt-sc-contact-info.type5 .dt-sc-contact-icon:after, .dt-sc-image-caption.type2:hover .dt-sc-image-content, /* .dt-sc-newsletter-section.type2 .dt-sc-subscribe-frm input[type="email"], */ .dt-sc-sociable.hexagon-with-border li, .dt-sc-sociable.hexagon-with-border li:before, .dt-sc-sociable.hexagon-with-border li:after, .side-navigation.type5 ul.side-nav, .side-navigation.type5 ul.side-nav li a, .side-navigation.type5 ul.side-nav li ul{border-color:#4b740b;}.error404 .type2 a.dt-sc-back:hover, .error404 .type4 .dt-sc-newsletter-section input[type="submit"]:hover{background-color:#4b740b;}#item-header-content #item-meta > #item-buttons .group-button:hover, #buddypress .activity-list li.load-more a:hover, #buddypress .activity-list li.load-newest a:hover{background-color:#4b740b;}#bbpress-forums #subscription-toggle a.subscription-toggle:hover, .bbp-submit-wrapper #bbp_topic_submit:hover{background-color:#4b740b;}#tribe-bar-form .tribe-bar-submit input[type="submit"]:hover, .tribe-events-read-more:hover, #tribe-events .tribe-events-button:hover, .tribe-events-button:hover, .tribe-events-back > a:hover, .datepicker thead tr:first-child th:hover, .datepicker tfoot tr th:hover, #tribe_events_filters_toggle:hover{background-color:#4b740b;}.tribe-grid-header .tribe-week-today{background-color:#4b740b;}.woocommerce a.button:hover, .woocommerce button.button:hover, .woocommerce button:hover, .woocommerce input.button:hover, .woocommerce input[type=button]:hover, .woocommerce input[type=submit]:hover, .woocommerce #respond input#submit:hover, .woocommerce a.button.alt:hover, .woocommerce button.button.alt:hover, .woocommerce input.button.alt:hover, .woocommerce #respond input#submit.alt:hover, .woocommerce .product .summary .add_to_wishlist:hover, .woocommerce .wishlist_table .add_to_cart.button:hover, .woocommerce .yith-wcwl-add-button a.add_to_wishlist:hover, .woocommerce .yith-wcwl-popup-button a.add_to_wishlist:hover, .woocommerce .wishlist_table a.ask-an-estimate-button:hover, .woocommerce .wishlist-title a.show-title-form:hover, .woocommerce .hidden-title-form a.hide-title-form:hover, .woocommerce .yith-wcwl-wishlist-new button:hover, .woocommerce .wishlist_manage_table a.create-new-wishlist:hover, .woocommerce .wishlist_manage_table button.submit-wishlist-changes:hover, .woocommerce .yith-wcwl-wishlist-search-form button.wishlist-search-button:hover, .woocommerce .cart input.button:hover, .woocommerce-page a.button:hover, .woocommerce-page button.button:hover, .woocommerce-page button:hover, .woocommerce-page input.button:hover, .woocommerce-page input[type=button]:hover, .woocommerce-page input[type=submit]:hover, .woocommerce-page #respond input#submit:hover, .woocommerce-page a.button.alt:hover, .woocommerce-page button.button.alt:hover, .woocommerce-page input.button.alt:hover, .woocommerce-page #respond input#submit.alt:hover, .woocommerce-page .product .summary .add_to_wishlist:hover, .woocommerce-page .wishlist_table .add_to_cart.button:hover, .woocommerce-page .yith-wcwl-add-button a.add_to_wishlist:hover, .woocommerce-page .yith-wcwl-popup-button a.add_to_wishlist:hover, .woocommerce-page .wishlist_table a.ask-an-estimate-button:hover, .woocommerce-page .wishlist-title a.show-title-form:hover, .woocommerce-page .hidden-title-form a.hide-title-form:hover, .woocommerce-page .yith-wcwl-wishlist-new button:hover, .woocommerce-page .wishlist_manage_table a.create-new-wishlist:hover, .woocommerce-page .wishlist_manage_table button.submit-wishlist-changes:hover, .woocommerce-page .yith-wcwl-wishlist-search-form button.wishlist-search-button:hover, .woocommerce-page .cart input.button:hover, .woocommerce a.button.alt.disabled, .woocommerce a.button.alt:disabled, .woocommerce a.button.alt[disabled]:disabled, .woocommerce button.button.alt.disabled, .woocommerce button.button.alt:disabled, .woocommerce button.button.alt[disabled]:disabled, .woocommerce input.button.alt.disabled, .woocommerce input.button.alt:disabled, .woocommerce input.button.alt[disabled]:disabled, .woocommerce #respond input#submit.alt.disabled, .woocommerce #respond input#submit.alt:disabled, .woocommerce #respond input#submit.alt[disabled]:disabled, .woocommerce a.button.alt.disabled:hover, .woocommerce a.button.alt:disabled:hover, .woocommerce a.button.alt[disabled]:disabled:hover, .woocommerce button.button.alt.disabled:hover, .woocommerce button.button.alt:disabled:hover, .woocommerce button.button.alt[disabled]:disabled:hover, .woocommerce input.button.alt.disabled:hover, .woocommerce input.button.alt:disabled:hover, .woocommerce input.button.alt[disabled]:disabled:hover, .woocommerce #respond input#submit.alt.disabled:hover, .woocommerce #respond input#submit.alt:disabled:hover, .woocommerce #respond input#submit.alt[disabled]:disabled:hover, .woocommerce a.button.disabled:hover, .woocommerce a.button:disabled:hover, .woocommerce a.button:disabled[disabled]:hover, .woocommerce button.button.disabled:hover, .woocommerce button.button:disabled:hover, .woocommerce button.button:disabled[disabled]:hover, .woocommerce input.button.disabled:hover, .woocommerce input.button:disabled:hover, .woocommerce input.button:disabled[disabled]:hover, .woocommerce #respond input#submit.disabled:hover, .woocommerce #respond input#submit:disabled:hover, .woocommerce #respond input#submit:disabled[disabled]:hover{background-color:#4b740b;}ul.products li.product .woo-type4 .product-thumb a.add_to_cart_button:hover:after, ul.products li.product .woo-type4 .product-thumb a.button.product_type_simple:hover:after, ul.products li.product .woo-type4 .product-thumb a.button.product_type_variable:hover:after, ul.products li.product .woo-type4 .product-thumb a.added_to_cart.wc-forward:hover:after, ul.products li.product .woo-type4 .product-thumb a.add_to_wishlist:hover:after, ul.products li.product .woo-type4 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover:after, ul.products li.product .woo-type4 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover:after{background-color:#4b740b;}ul.products li.product:hover .woo-type8 .product-wrapper{border-color:#4b740b;}ul.products li.product .woo-type10 .product-thumb a.add_to_cart_button:hover, ul.products li.product .woo-type10 .product-thumb a.button.product_type_simple:hover, ul.products li.product .woo-type10 .product-thumb a.button.product_type_variable:hover, ul.products li.product .woo-type10 .product-thumb a.added_to_cart.wc-forward:hover, ul.products li.product .woo-type10 .product-thumb a.add_to_wishlist:hover, ul.products li.product .woo-type10 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, ul.products li.product .woo-type10 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, .woo-type10.woocommerce ul.products li.product .featured-tag, .woo-type10 .woocommerce ul.products li.product .featured-tag, .woo-type10.woocommerce.single-product .featured-tag, .woocommerce ul.products li.product .woo-type10 .product-buttons-wrapper a.yith-wcqv-button:hover, .woocommerce ul.products li.product .woo-type10 .product-buttons-wrapper a.yith-woocompare-button:hover{background-color:#4b740b;}ul.products li.product .woo-type10 .featured-tag:after, ul.products li.product:hover .woo-type10 .featured-tag:after, .woo-type10.woocommerce.single-product .featured-tag:after{border-color:#4b740b;}ul.products li.product .woo-type11 .product-thumb a.add_to_cart_button, ul.products li.product .woo-type11 .product-thumb a.button.product_type_simple, ul.products li.product .woo-type11 .product-thumb a.button.product_type_variable, ul.products li.product .woo-type11 .product-thumb a.added_to_cart.wc-forward, ul.products li.product .woo-type11 .product-thumb a.add_to_wishlist, ul.products li.product .woo-type11 .product-thumb .yith-wcwl-wishlistaddedbrowse a, ul.products li.product .woo-type11 .product-thumb .yith-wcwl-wishlistexistsbrowse a, ul.products li.product:hover .woo-type11 .product-wrapper:before, ul.products li.product:hover .woo-type11 .product-wrapper:after, .woocommerce ul.products li.product .woo-type11 .product-thumb, .woocommerce ul.products li.product .woo-type11 .product-thumb, ul.products li.product-category .woo-type11 a img, .woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-wcqv-button, .woocommerce ul.products li.product .woo-type11 .product-buttons-wrapper a.yith-woocompare-button{border-color:#4b740b;}.woo-type12 ul.products li.product .product-thumb a.add_to_cart_button:hover, .woo-type12 ul.products li.product .product-thumb a.button.product_type_simple:hover, .woo-type12 ul.products li.product .product-thumb a.button.product_type_variable:hover, .woo-type12 ul.products li.product .product-thumb a.added_to_cart.wc-forward:hover, .woo-type12 ul.products li.product .product-thumb a.add_to_wishlist:hover, .woo-type12 ul.products li.product .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, .woo-type12 ul.products li.product .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover, .woo-type12 ul.products li.product:hover .product-details h5:after, .woocommerce ul.products li.product .woo-type12 .product-buttons-wrapper a.yith-wcqv-button:hover, .woocommerce ul.products li.product .woo-type12 .product-buttons-wrapper a.yith-woocompare-button:hover{background-color:#4b740b;}.woo-type12 ul.products li.product:hover .product-wrapper{border-color:#4b740b;}ul.products li.product .woo-type14 .product-thumb a.add_to_cart_button:hover, ul.products li.product .woo-type14 .product-thumb a.button.product_type_simple:hover, ul.products li.product .woo-type14 .product-thumb a.button.product_type_variable:hover, ul.products li.product .woo-type14 .product-thumb a.added_to_cart.wc-forward:hover, ul.products li.product .woo-type14 .product-thumb a.add_to_wishlist:hover, ul.products li.product .woo-type14 .product-thumb .yith-wcwl-wishlistaddedbrowse a:hover, ul.products li.product .woo-type14 .product-thumb .yith-wcwl-wishlistexistsbrowse a:hover{background-color:#4b740b;}.woo-type17.woocommerce ul.products li.product .featured-tag, .woo-type17 .woocommerce ul.products li.product .featured-tag, .woo-type17.woocommerce.single-product .featured-tag{background-color:#4b740b;}ul.products li.product .woo-type17 .featured-tag:after, ul.products li.product:hover .woo-type17 .featured-tag:after, .woo-type17.woocommerce.single-product .featured-tag:after{border-color:#4b740b;}.woo-type20.woocommerce .shop_table th, .woo-type20 .woocommerce .shop_table th, .woo-type20.woocommerce div.product .woocommerce-tabs ul.tabs li.active a:after{background-color:#4b740b;}.woo-type20 ul.products li.product:hover .product-wrapper:after, .woo-type20 div.product div.images img{border-color:#4b740b;}.woo-type20.woocommerce-checkout #payment ul.payment_methods li a:hover{color:#4b740b;}.has-tertiary-background-color{background-color:#6a9b21;}.has-tertiary-color{color:#6a9b21;}.dt-skin-tertiary-color{color:#6a9b21;}.dt-skin-tertiary-bg, div[class*="dt-skin-tertiary-bg-opaque"]:not(.ult-vc-hide-row):before, div[class*="dt-skin-tertiary-bg-opaque"] .upb_row_bg:before, section[class*="dt-skin-tertiary-bg-opaque"]:before, .dt-skin-tertiary-bg.extend-bg-fullwidth-left:after, .dt-skin-tertiary-bg.extend-bg-fullwidth-right:after, .dt-sc-triangle-title:before, .dt-sc-icon-box.type10 .icon-wrapper:after{background-color:#6a9b21;}.dt-skin-tertiary-border{border-color:#6a9b21;}.footer-22 .footer-copyright.vc_row{border-top-color:#6a9b21;}body, .layout-boxed .inner-wrapper, .secondary-sidebar .type8 .widgettitle, .secondary-sidebar .type10 .widgettitle:after, .dt-sc-contact-info.type3::after, .dt-sc-image-caption .dt-sc-image-wrapper .icon-wrapper::after, ul.products li .product-wrapper, .woocommerce-tabs .panel, .select2-results, .woocommerce .woocommerce-message, .woocommerce .woocommerce-info, .woocommerce .woocommerce-error, .woocommerce div.product .woocommerce-tabs ul.tabs li.active, .woo-type13 ul.products li.product:hover .product-details h5 a, .tribe-events-list-separator-month span{background-color:#ffffff;}.dt-sc-image-caption.type8 .dt-sc-image-content::before{border-color:#ffffff;}.secondary-sidebar .type14 .widgettitle:before, .widget.buddypress div.item-options a.selected{border-bottom-color:#ffffff;}.dt-sc-testimonial.type2 blockquote::before{border-top-color:#ffffff;}body, .wp-block-pullquote{color:#222222;}a{color:#85c226;}a:hover{color:#222222;}.main-title-section h1, h1.simple-title{font-family:Rajdhani;font-size:54px;font-weight:700;text-transform:none;color:#ffffff;}div.breadcrumb a{font-family:Lato;font-size:14px;font-weight:400;text-transform:none;color:#ffffff;}body{font-family:Lato;font-size:16px;font-weight:400;line-height:26px;text-transform:none;color:#222222;}h1{font-family:Rajdhani;font-size:44px;font-weight:700;text-transform:none;color:#222222;}h2{font-family:Rajdhani;font-size:42px;font-weight:700;letter-spacing:0px;text-transform:none;color:#222222;}h3{font-family:Rajdhani;font-size:40px;font-weight:700;text-transform:none;color:#222222;}h4{font-family:Rajdhani;font-size:34px;font-weight:700;text-transform:none;color:#222222;}h5{font-family:Rajdhani;font-size:28px;font-weight:700;text-transform:none;color:#222222;}h6{font-family:Rajdhani;font-size:20px;font-weight:700;text-transform:none;color:#222222;}div.footer-widgets h3.widgettitle{font-family:Rajdhani;font-size:24px;font-weight:400;letter-spacing:0px;line-height:36px;text-align:left;text-transform:none;color:#2b2b2b;}#footer, .footer-copyright, div.footer-widgets .widget{font-family:Lato;font-size:16px;font-weight:400;letter-spacing:0px;line-height:26px;text-align:left;text-transform:none;color:#333333;}/* devanagari */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pasEfOqeeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pasEfOleeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pasEfOreeHkkbIx.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDIxapCSOBg7S-QT7p4GM-CGW-rOq7s.woff) format('woff');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDIxapCSOBg7S-QT7p4JM-CGW-rOq7s.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDIxapCSOBg7S-QT7p4HM-CGW-rO.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pb0EPOqeeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pb0EPOleeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 500;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pb0EPOreeHkkbIx.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pbYF_OqeeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pbYF_OleeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 600;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pbYF_OreeHkkbIx.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* devanagari */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pa8FvOqeeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0900-097F, U+1CD0-1CF6, U+1CF8-1CF9, U+200C-200D, U+20A8, U+20B9, U+25CC, U+A830-A839, U+A8E0-A8FB;
}
/* latin-ext */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pa8FvOleeHkkbIxyyg.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Rajdhani';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/rajdhani/LDI2apCSOBg7S-QT7pa8FvOreeHkkbIx.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 100;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u-w4BMUTPHjxsIPx-mPCTC79U11vU.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 100;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u-w4BMUTPHjxsIPx-oPCTC79U1.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u_w4BMUTPHjxsI9w2_FQfrx9897sxZ.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 300;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u_w4BMUTPHjxsI9w2_Gwfrx9897g.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u8w4BMUTPHjxsAUi-sNiXg7eU0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 400;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u8w4BMUTPHjxsAXC-sNiXg7Q.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u_w4BMUTPHjxsI5wq_FQfrx9897sxZ.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 700;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u_w4BMUTPHjxsI5wq_Gwfrx9897g.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u_w4BMUTPHjxsI3wi_FQfrx9897sxZ.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: italic;
  font-weight: 900;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u_w4BMUTPHjxsI3wi_Gwfrx9897g.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u8w4BMUTPHh30AUi-sNiXg7eU0.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 100;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u8w4BMUTPHh30AXC-sNiXg7Q.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u9w4BMUTPHh7USSwaPHw3q5d0N7w.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 300;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u9w4BMUTPHh7USSwiPHw3q5d0.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6uyw4BMUTPHjxAwWCWtFCfQ7A.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 400;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6uyw4BMUTPHjx4wWCWtFCc.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u9w4BMUTPHh6UVSwaPHw3q5d0N7w.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 700;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u9w4BMUTPHh6UVSwiPHw3q5d0.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}
/* latin-ext */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u9w4BMUTPHh50XSwaPHw3q5d0N7w.woff) format('woff');
  unicode-range: U+0100-024F, U+0259, U+1E00-1EFF, U+2020, U+20A0-20AB, U+20AD-20CF, U+2113, U+2C60-2C7F, U+A720-A7FF;
}
/* latin */
@font-face {
  font-family: 'Lato';
  font-style: normal;
  font-weight: 900;
  font-display: swap;
  src: url(https://kanni.wpengine.com/wp-content/fonts/lato/S6u9w4BMUTPHh50XSwiPHw3q5d0.woff) format('woff');
  unicode-range: U+0000-00FF, U+0131, U+0152-0153, U+02BB-02BC, U+02C6, U+02DA, U+02DC, U+2000-206F, U+2074, U+20AC, U+2122, U+2191, U+2193, U+2212, U+2215, U+FEFF, U+FFFD;
}</style><style type="text/css" data-type="vc_shortcodes-custom-css">.vc_custom_1531473009182{padding-top: 20px !important;}.vc_custom_1531472997997{padding-top: 80px !important;padding-bottom: 80px !important;}.vc_custom_1534507596917{background-image: url(https://kanni.wpengine.com/wp-content/uploads/2018/08/web-pattern.png?id=10615) !important;}.vc_custom_1533360360040{margin-top: 80px !important;margin-right: 0px !important;margin-left: 0px !important;border-top-width: 1px !important;border-right-width: 1px !important;border-bottom-width: 1px !important;border-left-width: 1px !important;padding-top: 31px !important;padding-bottom: 31px !important;padding-left: 55px !important;background-color: #f8f8f8 !important;border-left-color: #eeeeee !important;border-left-style: solid !important;border-right-color: #eeeeee !important;border-right-style: solid !important;border-top-color: #eeeeee !important;border-top-style: solid !important;border-bottom-color: #eeeeee !important;border-bottom-style: solid !important;}.vc_custom_1531473042610{margin-bottom: 80px !important;}.vc_custom_1531382088901{margin-top: -10px !important;}.vc_custom_1531382110039{margin-bottom: 0px !important;}</style><noscript><style> .wpb_animate_when_almost_visible { opacity: 1; }</style></noscript><style id='kanni-custom-inline-inline-css' type='text/css'>
.vc_custom_1534753653700{padding-top: 15px !important;padding-bottom: 8px !important;}.vc_custom_1530682401432{background-color: #222222 !important;}.vc_custom_1517989922419{padding-top: 20px !important;padding-bottom: 20px !important;}.vc_custom_1533628387528{padding-top: 30px !important;}.vc_custom_1539150841469{padding-right: 0px !important;padding-left: 0px !important;}.vc_custom_1539150851503{padding-right: 0px !important;}

div#dt-1517831922735-f950d3e0-4c81 img { width:178px;}
@media only screen and (max-width: 767px) {
div#dt-1517831922735-f950d3e0-4c81 img { width:120px; }
}

div#dt-1517895345652-1665f512-1e96 ul.dt-primary-nav > li > a {font-size:14px;text-transform:uppercase;color:#ffffff;}


                            div#dt-1517895345652-1665f512-1e96 ul.dt-primary-nav > li:hover > a, 
                            div#dt-1517895345652-1665f512-1e96 ul.dt-primary-nav > li.current_page_item > a, 
                            div#dt-1517895345652-1665f512-1e96 ul.dt-primary-nav > li.current-menu-item > a,
                            div#dt-1517895345652-1665f512-1e96 ul.dt-primary-nav > li.current-page-ancestor > a,
                            div#dt-1517895345652-1665f512-1e96 ul.dt-primary-nav > li.current-menu-ancestor > a {color:#85c226;}

div#dt-1517895345652-1665f512-1e96 ul > li:not(.has-mega-menu) ul.sub-menu li > a{font-size:15px;text-transform:capitalize;text-align:left;}


                                div#dt-1517895345652-1665f512-1e96 ul.sub-menu li:hover > a,
                                div#dt-1517895345652-1665f512-1e96 ul.sub-menu li.current-menu-item > a,
                                div#dt-1517895345652-1665f512-1e96 ul.sub-menu li.current-page-item > a {color:#85c226;}

div#dt-1517895345652-1665f512-1e96 ul.dt-primary-nav > li { padding:10px 15px}
@media only screen and (max-width: 1199px) {
    div#dt-1517895345652-1665f512-1e96{ display: none; }
    div#dt-1517895345652-1665f512-1e96-mobile { display: block; }
div#dt-1517895345652-1665f512-1e96-mobile .menu-trigger > span {color:#ffffff}
div#dt-1517895345652-1665f512-1e96-mobile .menu-trigger > i {color:#ffffff}
}
@media only screen and (min-width: 1200px) {
    div#dt-1517895345652-1665f512-1e96{ display: inline-block; }
    div#dt-1517895345652-1665f512-1e96.center { display: table; }
    div#dt-1517895345652-1665f512-1e96-mobile, div#dt-1517895345652-1665f512-1e96 li.go-back, div#dt-1517895345652-1665f512-1e96 li.see-all { display: none; }
}

div[id="1531201315565-cbb906c0-45bd"] { height:120px }

div[id="1531201331746-9509448b-8fc6"] { height:120px }

div[id="1531382249480-1937a4fb-80d1"] { height:80px }

.vc_custom_1530767153912{padding-top: 80px !important;padding-bottom: 30px !important;background-color: #222222 !important;}.vc_custom_1534934915717{padding-top: 15px !important;padding-bottom: 15px !important;}.vc_custom_1530767376986{margin-bottom: 20px !important;}.vc_custom_1530767404157{margin-bottom: 20px !important;}.vc_custom_1534934491382{margin-bottom: 0px !important;}

div#dt-1530763382066-760a98bc-498f ul.dt-custom-nav li a {font-size:16px;text-transform:capitalize;}

div#dt-1530763382066-760a98bc-498f ul.dt-custom-nav li a {color:#878787;}


                div#dt-1530763382066-760a98bc-498f ul.dt-custom-nav li a:hover,
                div#dt-1530763382066-760a98bc-498f ul.dt-custom-nav li.current_page_item > a,
                div#dt-1530763382066-760a98bc-498f ul.dt-custom-nav li.current-menu-item > a,
                div#dt-1530763382066-760a98bc-498f ul.dt-custom-nav li.current-page-ancestor > a,
                div#dt-1530763382066-760a98bc-498f ul.dt-custom-nav li.current-menu-ancestor > a {color:#85c226;}

div[id="dt-1530763382066-760a98bc-498f"] > div > ul i.menu-item-icon,
                div[id="dt-1530763382066-760a98bc-498f"].dt-custom-nav-wrapper[data-link-icon-position="inside"] .dt-custom-nav li a > i.menu-item-icon, 
                div[id="dt-1530763382066-760a98bc-498f"].dt-custom-nav-wrapper[data-link-icon-position="outside"] .dt-custom-nav li a > i.menu-item-icon {font-size:16px;color:#878787;margin:0px;}
div[id="dt-1530763382066-760a98bc-498f"] > div > ul i.menu-item-icon img { width:12px }

div#dt-1533531534475-29f144a8-86b7 ul.dt-custom-nav li a {font-size:16px;text-transform:capitalize;}

div#dt-1533531534475-29f144a8-86b7 ul.dt-custom-nav li a {color:#878787;}


                div#dt-1533531534475-29f144a8-86b7 ul.dt-custom-nav li a:hover,
                div#dt-1533531534475-29f144a8-86b7 ul.dt-custom-nav li.current_page_item > a,
                div#dt-1533531534475-29f144a8-86b7 ul.dt-custom-nav li.current-menu-item > a,
                div#dt-1533531534475-29f144a8-86b7 ul.dt-custom-nav li.current-page-ancestor > a,
                div#dt-1533531534475-29f144a8-86b7 ul.dt-custom-nav li.current-menu-ancestor > a {color:#85c226;}

div[id="dt-1533531534475-29f144a8-86b7"] > div > ul i.menu-item-icon,
                div[id="dt-1533531534475-29f144a8-86b7"].dt-custom-nav-wrapper[data-link-icon-position="inside"] .dt-custom-nav li a > i.menu-item-icon, 
                div[id="dt-1533531534475-29f144a8-86b7"].dt-custom-nav-wrapper[data-link-icon-position="outside"] .dt-custom-nav li a > i.menu-item-icon {font-size:16px;color:#878787;margin:0px;}
div[id="dt-1533531534475-29f144a8-86b7"] > div > ul i.menu-item-icon img { width:12px }

div#dt-1530765236123-6c87c624-439a form .email-field-wrap, div#dt-1530765236123-6c87c624-439a form .btn-wrap { height:55px;}

div#dt-1530765236123-6c87c624-439a > form > div {color:#878787;background-color:#ffffff;border-style:solid; border-width:1px;border-color:#ffffff;}

div#dt-1530765236123-6c87c624-439a .btn-wrap i {color:#ffffff;}

div#dt-1530765236123-6c87c624-439a .btn-wrap > div {color:#ffffff;background-color:#85c226;border-style:solid; border-width:1px;border-color:#85c226;}

div#dt-1530765236123-6c87c624-439a > form > div:hover {color:#878787;background-color:#ffffff;border-style:solid; border-width:1px;border-color:#ffffff;}

div#dt-1530765236123-6c87c624-439a .btn-wrap:hover i {color:#ffffff;}

div#dt-1530765236123-6c87c624-439a .btn-wrap:hover > div {color:#ffffff;background-color:#4b740b;border-style:solid; border-width:1px;border-color:#4b740b;}

div[id="1517825064875-94c7a6c9-2846"] { height:90px }

ul#dt-1517827460735-355df74f-b776 > li > a > i {color:#ffffff;}ul#dt-1517827460735-355df74f-b776 > li > a > .dt-icon-default:before,
                        ul#dt-1517827460735-355df74f-b776[data-default-style="filled"][data-default-shape="hexagon"] li a > .dt-icon-default > span:before,
                        ul#dt-1517827460735-355df74f-b776[data-default-style="filled"][data-default-shape="hexagon"] li a > .dt-icon-default > span:after,
                        ul#dt-1517827460735-355df74f-b776[data-default-style="filled"][data-default-shape="hexagon-alt"] li a > .dt-icon-default > span:before,
                        ul#dt-1517827460735-355df74f-b776[data-default-style="filled"][data-default-shape="hexagon-alt"] li a > .dt-icon-default > span:after {background-color:#85c226;}ul#dt-1517827460735-355df74f-b776 > li > a:hover > i {color:#85c226;}ul#dt-1517827460735-355df74f-b776 > li > a > .dt-icon-hover:before,
                        ul#dt-1517827460735-355df74f-b776[data-hover-style="filled"][data-hover-shape="hexagon"] li a > .dt-icon-hover > span:before,
                        ul#dt-1517827460735-355df74f-b776[data-hover-style="filled"][data-hover-shape="hexagon"] li a > .dt-icon-hover > span:after,
                        ul#dt-1517827460735-355df74f-b776[data-hover-style="filled"][data-hover-shape="hexagon-alt"] li a > .dt-icon-hover > span:before,
                        ul#dt-1517827460735-355df74f-b776[data-hover-style="filled"][data-hover-shape="hexagon-alt"] li a > .dt-icon-hover > span:after {background-color:#ffffff}

div#dt-1517823213081-29060582-f200 ul.dt-custom-nav li a {font-size:16px;text-transform:capitalize;}

div#dt-1517823213081-29060582-f200 ul.dt-custom-nav li a {color:#ffffff;}


                div#dt-1517823213081-29060582-f200 ul.dt-custom-nav li a:hover,
                div#dt-1517823213081-29060582-f200 ul.dt-custom-nav li.current_page_item > a,
                div#dt-1517823213081-29060582-f200 ul.dt-custom-nav li.current-menu-item > a,
                div#dt-1517823213081-29060582-f200 ul.dt-custom-nav li.current-page-ancestor > a,
                div#dt-1517823213081-29060582-f200 ul.dt-custom-nav li.current-menu-ancestor > a {color:#222222;}

div#dt-1517823213081-29060582-f200 i.menu-item-icon { display:none; }
</style></head>

<body class="page-template-default page page-id-237 wp-embed-responsive theme-kanni woocommerce-no-js layout-wide wpb-js-composer js-comp-ver-6.5.0 vc_responsive">
        
    <!-- **Wrapper** -->
    <div class="wrapper">
    
        <!-- ** Inner Wrapper ** -->
        <div class="inner-wrapper">    
<!-- ** Header Wrapper ** -->
<div id="header-wrapper" class="header-top-relative">              
    
    <!-- **Header** -->
    <header id="header">

        <div class="container"><div id="header-8" class="dt-header-tpl header-8"><p><div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1534753653700"><div class="rs_col-sm-12 wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner " style=" text-align:left; "><div class="wpb_wrapper"><div id="dt-1517831922735-f950d3e0-4c81" class="dt-logo-container logo-align-left vc_custom_1533628387528">  <a href="https://kanni.wpengine.com/" rel="home"><img src="https://kanni.wpengine.com/wp-content/uploads/2018/08/logo.png" alt="Kanni Security Systems WordPress Theme"/></a></div></div></div></div><div class="rs_col-sm-12 wpb_column vc_column_container vc_col-sm-8"><div class="vc_column-inner vc_custom_1517989922419" style=" text-align:left; "><div class="wpb_wrapper"><div class="vc_row wpb_row vc_inner vc_row-fluid header-right-content"><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-contact-info  type1'><span class='fa fa-map-signs'> </span><h6>Address</h6>27, PWC Tower,<br>
188 Quay Street, Auckland</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-contact-info  type1'><span class='fa fa-envelope'> </span><h6>Mail Contact</h6><a href="#">admin@domain.com</a>
<a href="#">support@domain.com</a></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-4"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-contact-info  type1'><span class='fa fa-phone'> </span><h3 class="dt-skin-primary-color">1234 5678 90</h3></div><a href='#' target='_self' title='' class='dt-sc-button   xlarge   filled  ' > Get a Quote </a></div></div></div></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid vc_custom_1530682401432 vc_row-has-fill vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-11 vc_col-lg-11 vc_col-md-6"><div class="vc_column-inner vc_custom_1539150841469"><div class="wpb_wrapper"><div data-menu="main-menu" id="dt-1517895345652-1665f512-1e96" class="dt-header-menu mega-menu-page-equal left light-hover-effect" data-nav-item-divider="none" data-nav-item-highlight="underline" data-nav-item-display="simple"><div class="menu-container"><ul id="menu-main-menu" class="dt-primary-nav "  data-menu="main-menu"> <li class="close-nav"></li> <li id="menu-item-18" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-18 dt-menu-item-18 "><a href="https://kanni.wpengine.com/" class="item-has-icon icon-position-left"><span>Home</span></a></li>
<li id="menu-item-396" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-396 dt-menu-item-396 "><a href="https://kanni.wpengine.com/about/" class="item-has-icon icon-position-left"><span>About</span></a>
<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-397" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-397 dt-menu-item-397 "><a href="https://kanni.wpengine.com/about/careers/" class="item-has-icon icon-position-left"><span>Careers</span></a></li>
</ul>
</li>
<li id="menu-item-398" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-398 dt-menu-item-398 "><a href="https://kanni.wpengine.com/faq/" class="item-has-icon icon-position-left"><span>Faq</span></a></li>
<li id="menu-item-399" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-399 dt-menu-item-399 "><a href="https://kanni.wpengine.com/history/" class="item-has-icon icon-position-left"><span>History</span></a></li>
<li id="menu-item-400" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-400 dt-menu-item-400 "><a href="https://kanni.wpengine.com/packages/" class="item-has-icon icon-position-left"><span>Packages</span></a></li>
<li id="menu-item-401" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-401 dt-menu-item-401 "><a href="https://kanni.wpengine.com/security-system/" class="item-has-icon icon-position-left"><span>Security System</span></a></li>
<li id="menu-item-402" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-402 dt-menu-item-402 "><a href="https://kanni.wpengine.com/side-navigation/" class="item-has-icon icon-position-left"><span>Services</span></a>
<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-10459" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10459 dt-menu-item-10459 "><a href="https://kanni.wpengine.com/side-navigation/network-video-recorder/" class="item-has-icon icon-position-left"><span>Network Video Recorder</span></a></li>
	<li id="menu-item-10460" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10460 dt-menu-item-10460 "><a href="https://kanni.wpengine.com/side-navigation/fire-alarm-system/" class="item-has-icon icon-position-left"><span>Fire Alarm System</span></a></li>
	<li id="menu-item-10461" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10461 dt-menu-item-10461 "><a href="https://kanni.wpengine.com/side-navigation/gate-automation/" class="item-has-icon icon-position-left"><span>Gate Automation</span></a></li>
	<li id="menu-item-10462" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10462 dt-menu-item-10462 "><a href="https://kanni.wpengine.com/side-navigation/home-automation/" class="item-has-icon icon-position-left"><span>Home Automation</span></a></li>
	<li id="menu-item-10463" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10463 dt-menu-item-10463 "><a href="https://kanni.wpengine.com/side-navigation/burgular-intruder-alarm/" class="item-has-icon icon-position-left"><span>Burgular / Intruder Alarm</span></a></li>
	<li id="menu-item-10464" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10464 dt-menu-item-10464 "><a href="https://kanni.wpengine.com/side-navigation/video-door-phone/" class="item-has-icon icon-position-left"><span>Video Door Phone</span></a></li>
	<li id="menu-item-10465" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10465 dt-menu-item-10465 "><a href="https://kanni.wpengine.com/side-navigation/cctv-equipments/" class="item-has-icon icon-position-left"><span>Cctv Equipments</span></a></li>
	<li id="menu-item-10466" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10466 dt-menu-item-10466 "><a href="https://kanni.wpengine.com/side-navigation/access-control-system/" class="item-has-icon icon-position-left"><span>Access Control System</span></a></li>
	<li id="menu-item-10467" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10467 dt-menu-item-10467 "><a href="https://kanni.wpengine.com/side-navigation/public-address-system/" class="item-has-icon icon-position-left"><span>Public Address System</span></a></li>
</ul>
</li>
<li id="menu-item-9624" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9624 dt-menu-item-9624 "><a href="#" class="item-has-icon icon-position-left"><span>Pages</span></a>
<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-9625" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9625 dt-menu-item-9625 "><a href="https://kanni.wpengine.com/blog/" class="item-has-icon icon-position-left"><span>Blog</span></a>
	<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li id="menu-item-9633" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9633 dt-menu-item-9633 "><a href="https://kanni.wpengine.com/blog/blog-medium/" class="item-has-icon icon-position-left"><span>Medium</span></a></li>
		<li id="menu-item-9632" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9632 dt-menu-item-9632 "><a href="https://kanni.wpengine.com/blog/blog-medium-highlight/" class="item-has-icon icon-position-left"><span>Medium Highlight</span></a></li>
		<li id="menu-item-9634" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9634 dt-menu-item-9634 "><a href="https://kanni.wpengine.com/blog/blog-date-left/" class="item-has-icon icon-position-left"><span>Date Left</span></a></li>
		<li id="menu-item-9635" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9635 dt-menu-item-9635 "><a href="https://kanni.wpengine.com/blog/blog-date-and-author-left/" class="item-has-icon icon-position-left"><span>Date &#038; Author Left</span></a></li>
		<li id="menu-item-9666" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9666 dt-menu-item-9666 "><a href="https://kanni.wpengine.com/blog/bordered/" class="item-has-icon icon-position-left"><span>Bordered</span></a></li>
		<li id="menu-item-9665" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9665 dt-menu-item-9665 "><a href="https://kanni.wpengine.com/blog/classic/" class="item-has-icon icon-position-left"><span>Classic</span></a></li>
		<li id="menu-item-9667" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9667 dt-menu-item-9667 "><a href="https://kanni.wpengine.com/blog/modern/" class="item-has-icon icon-position-left"><span>Modern</span></a></li>
		<li id="menu-item-9664" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9664 dt-menu-item-9664 "><a href="https://kanni.wpengine.com/blog/trendy/" class="item-has-icon icon-position-left"><span>Trendy</span></a></li>
		<li id="menu-item-9663" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9663 dt-menu-item-9663 "><a href="https://kanni.wpengine.com/blog/overlap/" class="item-has-icon icon-position-left"><span>Overlap</span></a></li>
		<li id="menu-item-9662" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9662 dt-menu-item-9662 "><a href="https://kanni.wpengine.com/blog/stripe/" class="item-has-icon icon-position-left"><span>Stripe</span></a></li>
		<li id="menu-item-9661" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9661 dt-menu-item-9661 "><a href="https://kanni.wpengine.com/blog/fashion/" class="item-has-icon icon-position-left"><span>Fashion</span></a></li>
		<li id="menu-item-9660" class="hidden menu-item menu-item-type-post_type menu-item-object-page menu-item-9660 dt-menu-item-9660 "><a href="https://kanni.wpengine.com/blog/minimal-bordered/" class="item-has-icon icon-position-left"><span>Minimal Bordered</span></a></li>
	</ul>
</li>
	<li id="menu-item-9668" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9668 dt-menu-item-9668 "><a href="https://kanni.wpengine.com/portfolio/" class="item-has-icon icon-position-left"><span>Portfolio</span></a>
	<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li id="menu-item-9669" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9669 dt-menu-item-9669 "><a href="https://kanni.wpengine.com/portfolio/portfolio-art/" class="item-has-icon icon-position-left"><span>Portfolio – Art</span></a></li>
		<li id="menu-item-9670" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9670 dt-menu-item-9670 "><a href="https://kanni.wpengine.com/portfolio/portfolio-classic/" class="item-has-icon icon-position-left"><span>Portfolio – Classic</span></a></li>
		<li id="menu-item-9671" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9671 dt-menu-item-9671 "><a href="https://kanni.wpengine.com/portfolio/portfolio-girly/" class="item-has-icon icon-position-left"><span>Portfolio – Girly</span></a></li>
		<li id="menu-item-9672" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9672 dt-menu-item-9672 "><a href="https://kanni.wpengine.com/portfolio/portfolio-icons-only/" class="item-has-icon icon-position-left"><span>Portfolio – Icons Only</span></a></li>
		<li id="menu-item-9673" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9673 dt-menu-item-9673 "><a href="https://kanni.wpengine.com/portfolio/portfolio-minimal-icons/" class="item-has-icon icon-position-left"><span>Portfolio – Minimal Icons</span></a></li>
		<li id="menu-item-9674" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9674 dt-menu-item-9674 "><a href="https://kanni.wpengine.com/portfolio/portfolio-modern-title/" class="item-has-icon icon-position-left"><span>Portfolio – Modern Title</span></a></li>
		<li id="menu-item-9675" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9675 dt-menu-item-9675 "><a href="https://kanni.wpengine.com/portfolio/portfolio-presentation/" class="item-has-icon icon-position-left"><span>Portfolio – Presentation</span></a></li>
		<li id="menu-item-9676" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9676 dt-menu-item-9676 "><a href="https://kanni.wpengine.com/portfolio/portfolio-title-icons-overlay/" class="item-has-icon icon-position-left"><span>Portfolio – Title &#038; Icons Overlay</span></a></li>
		<li id="menu-item-9677" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9677 dt-menu-item-9677 "><a href="https://kanni.wpengine.com/portfolio/portfolio-title-overlay/" class="item-has-icon icon-position-left"><span>Portfolio – Title Overlay</span></a></li>
	</ul>
</li>
	<li id="menu-item-9628" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9628 dt-menu-item-9628 "><a href="https://kanni.wpengine.com/shop/" class="item-has-icon icon-position-left"><span>Shop</span></a></li>
</ul>
</li>
<li id="menu-item-10276" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10276 dt-menu-item-10276 "><a href="#" class="item-has-icon icon-position-left"><span>Elements</span></a>
<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>	<li id="menu-item-10278" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10278 dt-menu-item-10278 "><a href="#" class="item-has-icon icon-position-left"><span>Elements 1</span></a>
	<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li id="menu-item-10279" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10279 dt-menu-item-10279 "><a href="https://kanni.wpengine.com/shortcodes/blockquotes/" class="item-has-icon icon-position-left"><span>Blockquotes</span></a></li>
		<li id="menu-item-10280" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10280 dt-menu-item-10280 "><a href="https://kanni.wpengine.com/shortcodes/buttons-lists/" class="item-has-icon icon-position-left"><span>Buttons &#038; Lists</span></a></li>
		<li id="menu-item-10281" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10281 dt-menu-item-10281 "><a href="https://kanni.wpengine.com/shortcodes/columns/" class="item-has-icon icon-position-left"><span>Columns</span></a></li>
		<li id="menu-item-10282" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10282 dt-menu-item-10282 "><a href="https://kanni.wpengine.com/shortcodes/miscellaneous/" class="item-has-icon icon-position-left"><span>Miscellaneous</span></a></li>
		<li id="menu-item-10301" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10301 dt-menu-item-10301 "><a href="https://kanni.wpengine.com/shortcodes/typography/" class="item-has-icon icon-position-left"><span>Typography</span></a></li>
	</ul>
</li>
	<li id="menu-item-10283" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10283 dt-menu-item-10283 "><a href="#" class="item-has-icon icon-position-left"><span>Elements 2</span></a>
	<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li id="menu-item-10284" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10284 dt-menu-item-10284 "><a href="https://kanni.wpengine.com/shortcodes/carousel/" class="item-has-icon icon-position-left"><span>Carousel</span></a></li>
		<li id="menu-item-10285" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10285 dt-menu-item-10285 "><a href="https://kanni.wpengine.com/shortcodes/content-shortcodes/" class="item-has-icon icon-position-left"><span>Content Shortcodes</span></a></li>
		<li id="menu-item-10286" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10286 dt-menu-item-10286 "><a href="https://kanni.wpengine.com/shortcodes/fancy-boxes/" class="item-has-icon icon-position-left"><span>Fancy Boxes</span></a></li>
		<li id="menu-item-10287" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10287 dt-menu-item-10287 "><a href="https://kanni.wpengine.com/shortcodes/icon-boxes/" class="item-has-icon icon-position-left"><span>Icon Boxes</span></a></li>
		<li id="menu-item-10288" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10288 dt-menu-item-10288 "><a href="https://kanni.wpengine.com/shortcodes/tabs-toggles/" class="item-has-icon icon-position-left"><span>Tabs &#038; Toggles</span></a></li>
	</ul>
</li>
	<li id="menu-item-10289" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10289 dt-menu-item-10289 "><a href="#" class="item-has-icon icon-position-left"><span>Elements 3</span></a>
	<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li id="menu-item-10293" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10293 dt-menu-item-10293 "><a href="https://kanni.wpengine.com/shortcodes/custom-posts/" class="item-has-icon icon-position-left"><span>Custom Posts</span></a></li>
		<li id="menu-item-10294" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10294 dt-menu-item-10294 "><a href="https://kanni.wpengine.com/shortcodes/image-with-caption/" class="item-has-icon icon-position-left"><span>Image With Caption</span></a></li>
		<li id="menu-item-10290" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10290 dt-menu-item-10290 "><a href="https://kanni.wpengine.com/shortcodes/team/"><span>Team</span></a></li>
		<li id="menu-item-10291" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10291 dt-menu-item-10291 "><a href="https://kanni.wpengine.com/shortcodes/testimonial-carousel/"><span>Testimonial Carousel</span></a></li>
		<li id="menu-item-10292" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10292 dt-menu-item-10292 "><a href="https://kanni.wpengine.com/shortcodes/testimonials/"><span>Testimonials</span></a></li>
	</ul>
</li>
	<li id="menu-item-10295" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10295 dt-menu-item-10295 "><a href="#"><span>Elements 4</span></a>
	<ul  class="sub-menu is-hidden ">
<li class="go-back"><a href="javascript:void(0);"></a></li><li class="see-all"></li>		<li id="menu-item-10296" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10296 dt-menu-item-10296 "><a href="https://kanni.wpengine.com/shortcodes/contact-info/"><span>Contact Info</span></a></li>
		<li id="menu-item-10297" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10297 dt-menu-item-10297 "><a href="https://kanni.wpengine.com/shortcodes/number-counter/"><span>Number Counter</span></a></li>
		<li id="menu-item-10298" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10298 dt-menu-item-10298 "><a href="https://kanni.wpengine.com/shortcodes/pricing-table/"><span>Pricing Table</span></a></li>
		<li id="menu-item-10299" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10299 dt-menu-item-10299 "><a href="https://kanni.wpengine.com/shortcodes/progress-bar/"><span>Progress Bar</span></a></li>
		<li id="menu-item-10300" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-10300 dt-menu-item-10300 "><a href="https://kanni.wpengine.com/shortcodes/timeline/"><span>Timeline</span></a></li>
	</ul>
</li>
</ul>
</li>
<li id="menu-item-427" class="menu-item menu-item-type-post_type menu-item-object-page current-menu-item page_item page-item-237 current_page_item menu-item-427 dt-menu-item-427 "><a href="index.html"><span>Contact</span></a></li>
</ul> <div class="sub-menu-overlay"></div></div></div><div id="dt-1517895345652-1665f512-1e96-mobile" class="mobile-nav-container mobile-nav-offcanvas-right" data-menu="main-menu">  <div class="menu-trigger menu-trigger-icon" data-menu="main-menu"><i class="fa fa-bars"></i><span>Menu</span>  </div>  <div class="mobile-menu" data-menu="main-menu"></div>  <div class="overlay"></div></div></div></div></div><div class="header-search-icon rs_col-sm-6 wpb_column vc_column_container vc_col-sm-1 vc_col-lg-1 vc_col-md-6"><div class="vc_column-inner vc_custom_1539150851503" style=" text-align:right; "><div class="wpb_wrapper"><div id="dt-1517833845542-f830b07d-9a3e" class=" search-module overlay-header-search"><div class="menu-icons-wrapper">	<div class="search">		<a href="javascript:void(0)" class="overlay-search-type2 dt-search-icon type2"> <span class="fa fa-search"> </span> </a>		<div class="overlay overlay-search">			<div class="overlay-close"></div><!-- **Searchform** -->
<form method="get" id="searchform" action="https://kanni.wpengine.com/">
    <input id="s" name="s" type="text" 
         	value="Enter Keyword" class="text_input"
		    onblur="if(this.value==''){this.value='Enter Keyword';}"
            onfocus="if(this.value =='Enter Keyword') {this.value=''; }" />
    <a href="javascript:void(0)" class="dt-search-icon"> <span class="fa fa-close"> </span> </a>
	<input name="submit" type="submit"  value="Go" />
</form><!-- **Searchform - End** -->		</div>	</div></div></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div></p>
</div>        </div>
    </header><!-- **Header - End ** -->

    <!-- ** Slider ** -->
    <!-- ** Slider End ** -->

    <!-- ** Breadcrumb ** -->
    <section class="main-title-section-wrapper breadcrumb-right">  <div class="main-title-section-bg" style='background-image: url(https://kanni.wpengine.com/wp-content/uploads/2018/07/breadcrumb-4.jpg); background-position: left top; background-size: auto; background-repeat: repeat; background-attachment: fixed; '></div>  <div class="container">  	<div class="main-title-section"><h1>Contact</h1></div><div class="breadcrumb"><a href="https://kanni.wpengine.com/">Home</a><span class="fa default"></span><span class="current">Contact</span></div>  </div></section><!-- ** Breadcrumb End ** -->
</div><!-- ** Header Wrapper - End ** -->

<!-- **Main** -->
<div id="main">

    <!-- ** Container ** -->
    <div class="container">
        <!-- Primary -->
        <section id="primary" class="content-full-width">	<!-- #post-237 -->
<div id="post-237" class="post-237 page type-page status-publish hentry">
<div class="vc_row wpb_row vc_row-fluid vc_custom_1531473009182"><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-1/5"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Los Angeles</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/2015, Aslan Flats, Los Angeles</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Portland</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/5, Elizabeth Street , Portland</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Phoenix</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/2015, South Street, Phoenix</div></div></div></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-1/5"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">San Francisco</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">2/205, Hills Flats, San Francisco</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Dallas</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">245/15, Woodside Street, Dallas</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Pittsburgh</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/25, South Street, Pittsburgh</div></div></div></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-1/5"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Chicago</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/2015, Grand Court, Chicago</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">San Jose</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">190/15, Beech Road, San Jose</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Oakland</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/5, Western Road, Oakland</div></div></div></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-1/5"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Seattle</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/2015, Washington Road, Seattle</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Atlanta</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/2015, Lake Road, Atlanta</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Las Vegas</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">43/415, Cherry Flat, Las Vegas</div></div></div></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-1/5"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Detroit</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/15, Rockford Avenue, Detroit</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Miami</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">23/25, Tom Road, Miami</div></div></div><div class="dt-sc-tooltip-info  top"><h4><a href="#" title="" target="_self">Tampa</a></h4><div class="dt-sc-tooltip-details"><div class="tooltip-thumb"><img width="190" height="190" src="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg" class="attachment-full" alt="img" loading="lazy" srcset="https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1.jpg 190w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-100x100.jpg 100w, https://kanni.wpengine.com/wp-content/uploads/2018/07/testim1-150x150.jpg 150w" sizes="(max-width: 190px) 100vw, 190px" /></div><div class="tooltip-content">53/515, Austin Flats, Tampa</div></div></div></div></div></div></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1531472997997"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-title with-two-border aligncenter'><h2>Contact Details</h2></div><div class="vc_row wpb_row vc_inner vc_row-fluid vc_custom_1531473042610"><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-contact-info  bordered'><span class='fa fa-map-signs'> </span><h6>Location</h6>3775 Vermont Ave, Los Angeles, <br>CA 90007</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-contact-info  bordered'><span class='fa fa-phone'> </span><h6>Telephone</h6>+1 800 559 6580 <br> +1 959 603 6035</div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-contact-info  bordered'><span class='fa fa-envelope'> </span><h6>E-mail</h6><a href="#">info@domainname.com</a> <br><a href="#">sales@domainname.com</a></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><div class='dt-sc-contact-info  bordered'><span class='fa fa-clock-o'> </span><h6>Business Hours</h6>Mon – Fri :9 am to 9 pm<br>Sat :9 am to 5 pm</div></div></div></div></div><div id="responsive_map-1743603058" class="responsive-map" style="height:370px;width:100%;"></div>		<script type="text/javascript">
			jQuery(document).ready(function($){

				var mapdiv = jQuery("#responsive_map-1743603058");
				mapdiv.gMap({
					maptype: google.maps.MapTypeId.ROADMAP,
					zoom: 17,
					latitude: null,
					longitude: null,
					streetViewControl:true,
					mapTypeControl:true,
					zoomControl:true,
					scaleControl:true,
					scrollwheel:true,
					draggable:true,
					styles:[{"stylers":[{"featureType":"all"}]}],
					markers: [{flat: true,key:"1",latitude:"11.046692",longitude:"77.004765",icon: { image:"https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/images/markers/green.png" },}],
					panControl: true,
					overviewMapControl:true,
				});
			});
		</script></div></div></div></div><div  style='background-attachment:fixed !important;' data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid dt-skin-primary-bg dt-sc-dark-bg vc_custom_1534507596917 vc_row-has-fill"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div id="1531201315565-cbb906c0-45bd" class="dt-sc-empty-space"></div><div class='dt-sc-title with-two-border aligncenter'><h2>Tell Your Security Needs</h2></div><h5>Interested In:</h5><div role="form" class="wpcf7" id="wpcf7-f82-p237-o1" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="https://kanni.wpengine.com/contact/#wpcf7-f82-p237-o1" method="post" class="wpcf7-form init security-form" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="82" />
<input type="hidden" name="_wpcf7_version" value="5.3.2" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f82-p237-o1" />
<input type="hidden" name="_wpcf7_container_post" value="237" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<div class="vc_row wpb_row vc_row-fluid"> <div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap checkbox-160"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-160&#091;&#093;" value="Video Verification" /><span class="wpcf7-list-item-label">Video Verification</span></span></span></span><span class="wpcf7-form-control-wrap checkbox-281"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-281&#091;&#093;" value="Retail Video Analytics" /><span class="wpcf7-list-item-label">Retail Video Analytics</span></span></span></span><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="24 Hour Monitoring" /><span class="wpcf7-list-item-label">24 Hour Monitoring</span></span></span></span></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="Access Control Systems" /><span class="wpcf7-list-item-label">Access Control Systems</span></span></span></span><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="Smart Phone Security" /><span class="wpcf7-list-item-label">Smart Phone Security</span></span></span></span><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="Cloud Monitoring" /><span class="wpcf7-list-item-label">Cloud Monitoring</span></span></span></span></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="Alarm Systems" /><span class="wpcf7-list-item-label">Alarm Systems</span></span></span></span><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="IP Video" /><span class="wpcf7-list-item-label">IP Video</span></span></span></span></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="Door Controls" /><span class="wpcf7-list-item-label">Door Controls</span></span></span></span><span class="wpcf7-form-control-wrap checkbox-82"><span class="wpcf7-form-control wpcf7-checkbox"><span class="wpcf7-list-item first last"><input type="checkbox" name="checkbox-82&#091;&#093;" value="Record Movements" /><span class="wpcf7-list-item-label">Record Movements</span></span></span></span></div></div></div><div class='dt-sc-clear '> </div><div class='dt-sc-hr-invisible-small '> </div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap text-424"><input type="text" name="text-424" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Your Name *" /></span></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap email-654"><input type="email" name="email-654" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email Address *" /></span></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap tel-60"><input type="tel" name="tel-60" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-required wpcf7-validates-as-tel" aria-required="true" aria-invalid="false" placeholder="Phone Number *" /></span></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap text-531"><input type="text" name="text-531" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Company Name" /></span></div></div></div><div class='dt-sc-clear '> </div><div class='dt-sc-clear '> </div><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><span class="wpcf7-form-control-wrap textarea-220"><textarea name="textarea-220" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Your Text Here..."></textarea></span></div></div></div><div class='dt-sc-hr-invisible-xsmall '> </div><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><input type="submit" value="Send Now" class="wpcf7-form-control wpcf7-submit" /></div></div></div></div>
<div class="wpcf7-response-output" aria-hidden="true"></div></form></div><div id="1531201331746-9509448b-8fc6" class="dt-sc-empty-space"></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div class="vc_row wpb_row vc_row-fluid vc_custom_1533360360040 vc_row-has-fill vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-9"><div class="vc_column-inner "><div class="wpb_wrapper"><h2 style="font-size: 30px;line-height: 44px;text-align: left" class="vc_custom_heading vcr_float_right vc_custom_1531382110039">2000+ people have put their trust in our CCTV installation,<br />
How about you?</h2></div></div></div><div class="wpb_column vc_column_container vc_col-sm-3"><div class="vc_column-inner vc_custom_1531382088901"><div class="wpb_wrapper"><a href='#' target='_self' title='' class='dt-sc-button   large   rounded-border  default filled' > Get Started Now </a></div></div></div></div><div class="vc_row wpb_row vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div id="1531382249480-1937a4fb-80d1" class="dt-sc-empty-space"></div></div></div></div></div>
</div><!-- #post-237 -->
        </section><!-- Primary End -->    </div>
    <!-- ** Container End ** -->
    
</div><!-- **Main - End ** -->    
    
        <!-- **Footer** -->
        <footer id="footer">
            <div class="container">
            <p><div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid dt-sc-dark-bg footer-section vc_custom_1530767153912 vc_row-has-fill"><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><h3>About Us</h3>
	<div class="wpb_text_column wpb_content_element  vc_custom_1530767376986" >
		<div class="wpb_wrapper">
			<p>In enim justo, rhoncus ut, imperdiet a, venenatis vitae, justo. Nullam dictum felis eu pede mollis pretium.</p>

		</div>
	</div>
<div class='dt-sc-contact-info  simple'><span class='fa fa-map-marker'> </span>Anthony Benoit 490 E Main Street
Norwich CT 06360</div><div class='dt-sc-contact-info  simple'><span class='fa fa-envelope'> </span><a href="#">admin@iamd.com</a></div><div class='dt-sc-contact-info  simple'><span class='fa fa-phone'> </span>+9100 (2) 345 6789</div></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><h3>Quick Links</h3><div class="vc_row wpb_row vc_inner vc_row-fluid"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div id="dt-1530763382066-760a98bc-498f" class="dt-custom-nav-wrapper left" data-default-style = "none" data-hover-style = "none" data-link-icon-position = "inside" data-default-decoration = "none" data-hover-decoration = "none" data-divider = "yes"><div class="menu-quick-links-i-container"><ul id="menu-quick-links-i" class="custom-sub-nav dt-custom-nav"><li id="menu-item-28" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-28"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Survillance</span></a><span class="divider"></span></li>
<li id="menu-item-29" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-29"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Alarms</span></a><span class="divider"></span></li>
<li id="menu-item-30" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-30"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>CCTV</span></a><span class="divider"></span></li>
<li id="menu-item-31" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-31"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Door System</span></a><span class="divider"></span></li>
<li id="menu-item-32" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-32"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Recorders</span></a><span class="divider"></span></li>
<li id="menu-item-33" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-33"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Maintenance</span></a><span class="divider"></span></li>
</ul></div></div></div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div id="dt-1533531534475-29f144a8-86b7" class="dt-custom-nav-wrapper left" data-default-style = "none" data-hover-style = "none" data-link-icon-position = "inside" data-default-decoration = "none" data-hover-decoration = "none" data-divider = "yes"><div class="menu-quick-links-ii-container"><ul id="menu-quick-links-ii" class="custom-sub-nav dt-custom-nav"><li id="menu-item-10490" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10490"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Services</span></a><span class="divider"></span></li>
<li id="menu-item-10491" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10491"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Integration</span></a><span class="divider"></span></li>
<li id="menu-item-10492" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10492"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Control</span></a><span class="divider"></span></li>
<li id="menu-item-10493" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10493"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Signaling</span></a><span class="divider"></span></li>
<li id="menu-item-10494" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10494"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Device Access</span></a><span class="divider"></span></li>
<li id="menu-item-10495" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10495"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon fa fa-angle-right"></i><span>Trading</span></a><span class="divider"></span></li>
</ul></div></div></div></div></div></div></div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><h3>Our Socials</h3>
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			
<div id="sb_instagram" class="sbi sbi_col_3  sbi_width_resp" style="padding-bottom: 10px;width: 100%;" data-feedid="sbi_17841406085826537#6" data-res="auto" data-cols="3" data-num="6" data-shortcode-atts="{&quot;num&quot;:&quot;6&quot;,&quot;cols&quot;:&quot;3&quot;}" >
	
    <div id="sbi_images" style="padding: 5px;">
		<div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17881359805908837" data-date="1606996122">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/CIVaGFUgbpB/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent.cdninstagram.com/v/t51.29350-15/129734250_299043961382220_4873546273688392437_n.jpg?_nc_cat=103&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=Sb5Ntp6wUIAAX_G7lRq&#038;_nc_ht=scontent.cdninstagram.com&#038;oh=ba388135b4156eec9d3ec40aab7b1290&#038;oe=60B48F6F" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.29350-15\/129734250_299043961382220_4873546273688392437_n.jpg?_nc_cat=103&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Sb5Ntp6wUIAAX_G7lRq&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=ba388135b4156eec9d3ec40aab7b1290&amp;oe=60B48F6F&quot;,&quot;150&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.29350-15\/129734250_299043961382220_4873546273688392437_n.jpg?_nc_cat=103&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Sb5Ntp6wUIAAX_G7lRq&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=ba388135b4156eec9d3ec40aab7b1290&amp;oe=60B48F6F&quot;,&quot;320&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.29350-15\/129734250_299043961382220_4873546273688392437_n.jpg?_nc_cat=103&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Sb5Ntp6wUIAAX_G7lRq&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=ba388135b4156eec9d3ec40aab7b1290&amp;oe=60B48F6F&quot;,&quot;640&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.29350-15\/129734250_299043961382220_4873546273688392437_n.jpg?_nc_cat=103&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=Sb5Ntp6wUIAAX_G7lRq&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=ba388135b4156eec9d3ec40aab7b1290&amp;oe=60B48F6F&quot;}">
            <span class="sbi-screenreader">https://mimoarts.com/</span>
            	                    <img src="https://kanni.wpengine.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="https://mimoarts.com/">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17891752141115172" data-date="1508764340">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/Bal31z1Hh02/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent.cdninstagram.com/v/t51.2885-15/22794110_445898755803873_8913170695370833920_n.jpg?_nc_cat=104&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=WBChjIZ0LCEAX95xnFA&#038;_nc_ht=scontent.cdninstagram.com&#038;oh=47196fb1c7f13444059ad68b1d3824ca&#038;oe=60B5BFDE" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22794110_445898755803873_8913170695370833920_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=WBChjIZ0LCEAX95xnFA&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=47196fb1c7f13444059ad68b1d3824ca&amp;oe=60B5BFDE&quot;,&quot;150&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22794110_445898755803873_8913170695370833920_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=WBChjIZ0LCEAX95xnFA&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=47196fb1c7f13444059ad68b1d3824ca&amp;oe=60B5BFDE&quot;,&quot;320&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22794110_445898755803873_8913170695370833920_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=WBChjIZ0LCEAX95xnFA&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=47196fb1c7f13444059ad68b1d3824ca&amp;oe=60B5BFDE&quot;,&quot;640&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22794110_445898755803873_8913170695370833920_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=WBChjIZ0LCEAX95xnFA&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=47196fb1c7f13444059ad68b1d3824ca&amp;oe=60B5BFDE&quot;}">
            <span class="sbi-screenreader">Instagram post 17891752141115172</span>
            	                    <img src="https://kanni.wpengine.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Instagram post 17891752141115172">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17903768113012703" data-date="1508764318">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/Bal3zD9HqRE/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent.cdninstagram.com/v/t51.2885-15/22709299_2152828954944675_6033853057110900736_n.jpg?_nc_cat=104&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=MnuvK7pWqvYAX9C6b8_&#038;_nc_ht=scontent.cdninstagram.com&#038;oh=0b7e17d9f8ce022dc72fe613f9b428df&#038;oe=60B60C47" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22709299_2152828954944675_6033853057110900736_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=MnuvK7pWqvYAX9C6b8_&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=0b7e17d9f8ce022dc72fe613f9b428df&amp;oe=60B60C47&quot;,&quot;150&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22709299_2152828954944675_6033853057110900736_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=MnuvK7pWqvYAX9C6b8_&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=0b7e17d9f8ce022dc72fe613f9b428df&amp;oe=60B60C47&quot;,&quot;320&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22709299_2152828954944675_6033853057110900736_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=MnuvK7pWqvYAX9C6b8_&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=0b7e17d9f8ce022dc72fe613f9b428df&amp;oe=60B60C47&quot;,&quot;640&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22709299_2152828954944675_6033853057110900736_n.jpg?_nc_cat=104&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=MnuvK7pWqvYAX9C6b8_&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=0b7e17d9f8ce022dc72fe613f9b428df&amp;oe=60B60C47&quot;}">
            <span class="sbi-screenreader">Instagram post 17903768113012703</span>
            	                    <img src="https://kanni.wpengine.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Instagram post 17903768113012703">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17880588742136093" data-date="1508764241">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/Bal3ptgH7Dg/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent.cdninstagram.com/v/t51.2885-15/22710422_221064848430906_5389012139077795840_n.jpg?_nc_cat=109&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=JLjCt3jBY84AX_8kIWW&#038;_nc_oc=AQmzF1aZRHRV7_S5DrACrc-WI9-HqpajS8xU6c9iXxEbXN3q89ED--nX49oMWEbfFYs&#038;_nc_ht=scontent.cdninstagram.com&#038;oh=c96a4ecf1fdce9385bdfb41446b3115b&#038;oe=60B637BB" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710422_221064848430906_5389012139077795840_n.jpg?_nc_cat=109&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=JLjCt3jBY84AX_8kIWW&amp;_nc_oc=AQmzF1aZRHRV7_S5DrACrc-WI9-HqpajS8xU6c9iXxEbXN3q89ED--nX49oMWEbfFYs&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=c96a4ecf1fdce9385bdfb41446b3115b&amp;oe=60B637BB&quot;,&quot;150&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710422_221064848430906_5389012139077795840_n.jpg?_nc_cat=109&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=JLjCt3jBY84AX_8kIWW&amp;_nc_oc=AQmzF1aZRHRV7_S5DrACrc-WI9-HqpajS8xU6c9iXxEbXN3q89ED--nX49oMWEbfFYs&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=c96a4ecf1fdce9385bdfb41446b3115b&amp;oe=60B637BB&quot;,&quot;320&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710422_221064848430906_5389012139077795840_n.jpg?_nc_cat=109&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=JLjCt3jBY84AX_8kIWW&amp;_nc_oc=AQmzF1aZRHRV7_S5DrACrc-WI9-HqpajS8xU6c9iXxEbXN3q89ED--nX49oMWEbfFYs&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=c96a4ecf1fdce9385bdfb41446b3115b&amp;oe=60B637BB&quot;,&quot;640&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710422_221064848430906_5389012139077795840_n.jpg?_nc_cat=109&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=JLjCt3jBY84AX_8kIWW&amp;_nc_oc=AQmzF1aZRHRV7_S5DrACrc-WI9-HqpajS8xU6c9iXxEbXN3q89ED--nX49oMWEbfFYs&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=c96a4ecf1fdce9385bdfb41446b3115b&amp;oe=60B637BB&quot;}">
            <span class="sbi-screenreader">Instagram post 17880588742136093</span>
            	                    <img src="https://kanni.wpengine.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Instagram post 17880588742136093">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17845414189218813" data-date="1508764183">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/Bal3ip4n7lO/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent.cdninstagram.com/v/t51.2885-15/22710515_441558126241416_6328376406459809792_n.jpg?_nc_cat=108&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=wR-7YYU3QHEAX9jjKo4&#038;_nc_ht=scontent.cdninstagram.com&#038;oh=864870552f809680ad74fce01466b4b3&#038;oe=60B633EA" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710515_441558126241416_6328376406459809792_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=wR-7YYU3QHEAX9jjKo4&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=864870552f809680ad74fce01466b4b3&amp;oe=60B633EA&quot;,&quot;150&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710515_441558126241416_6328376406459809792_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=wR-7YYU3QHEAX9jjKo4&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=864870552f809680ad74fce01466b4b3&amp;oe=60B633EA&quot;,&quot;320&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710515_441558126241416_6328376406459809792_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=wR-7YYU3QHEAX9jjKo4&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=864870552f809680ad74fce01466b4b3&amp;oe=60B633EA&quot;,&quot;640&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22710515_441558126241416_6328376406459809792_n.jpg?_nc_cat=108&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=wR-7YYU3QHEAX9jjKo4&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=864870552f809680ad74fce01466b4b3&amp;oe=60B633EA&quot;}">
            <span class="sbi-screenreader">Instagram post 17845414189218813</span>
            	                    <img src="https://kanni.wpengine.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Instagram post 17845414189218813">
        </a>
    </div>
</div><div class="sbi_item sbi_type_image sbi_new sbi_transition" id="sbi_17905522504012082" data-date="1508764133">
    <div class="sbi_photo_wrap">
        <a class="sbi_photo" href="https://www.instagram.com/p/Bal3ckrHh-J/" target="_blank" rel="noopener nofollow" data-full-res="https://scontent.cdninstagram.com/v/t51.2885-15/22802064_1422246701224409_8705570247073071104_n.jpg?_nc_cat=101&#038;ccb=1-3&#038;_nc_sid=8ae9d6&#038;_nc_ohc=b0BEZKL7MrEAX8Uf8WA&#038;_nc_oc=AQn_Upsr1mpXFt5vZO8-_L5OpZ81hBMOr0EyfVgrMP0mGINtzdAKSlkemR0mwuF82ec&#038;_nc_ht=scontent.cdninstagram.com&#038;oh=10ae11ea4e54e98851776ace98a451e2&#038;oe=60B61018" data-img-src-set="{&quot;d&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22802064_1422246701224409_8705570247073071104_n.jpg?_nc_cat=101&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=b0BEZKL7MrEAX8Uf8WA&amp;_nc_oc=AQn_Upsr1mpXFt5vZO8-_L5OpZ81hBMOr0EyfVgrMP0mGINtzdAKSlkemR0mwuF82ec&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=10ae11ea4e54e98851776ace98a451e2&amp;oe=60B61018&quot;,&quot;150&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22802064_1422246701224409_8705570247073071104_n.jpg?_nc_cat=101&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=b0BEZKL7MrEAX8Uf8WA&amp;_nc_oc=AQn_Upsr1mpXFt5vZO8-_L5OpZ81hBMOr0EyfVgrMP0mGINtzdAKSlkemR0mwuF82ec&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=10ae11ea4e54e98851776ace98a451e2&amp;oe=60B61018&quot;,&quot;320&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22802064_1422246701224409_8705570247073071104_n.jpg?_nc_cat=101&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=b0BEZKL7MrEAX8Uf8WA&amp;_nc_oc=AQn_Upsr1mpXFt5vZO8-_L5OpZ81hBMOr0EyfVgrMP0mGINtzdAKSlkemR0mwuF82ec&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=10ae11ea4e54e98851776ace98a451e2&amp;oe=60B61018&quot;,&quot;640&quot;:&quot;https:\/\/scontent.cdninstagram.com\/v\/t51.2885-15\/22802064_1422246701224409_8705570247073071104_n.jpg?_nc_cat=101&amp;ccb=1-3&amp;_nc_sid=8ae9d6&amp;_nc_ohc=b0BEZKL7MrEAX8Uf8WA&amp;_nc_oc=AQn_Upsr1mpXFt5vZO8-_L5OpZ81hBMOr0EyfVgrMP0mGINtzdAKSlkemR0mwuF82ec&amp;_nc_ht=scontent.cdninstagram.com&amp;oh=10ae11ea4e54e98851776ace98a451e2&amp;oe=60B61018&quot;}">
            <span class="sbi-screenreader">Instagram post 17905522504012082</span>
            	                    <img src="https://kanni.wpengine.com/wp-content/plugins/instagram-feed/img/placeholder.png" alt="Instagram post 17905522504012082">
        </a>
    </div>
</div>    </div>

	<div id="sbi_load">

	
	
</div>
	    <span class="sbi_resized_image_data" data-feed-id="sbi_17841406085826537#6" data-resized="{&quot;17891752141115172&quot;:{&quot;id&quot;:&quot;22794110_445898755803873_8913170695370833920_n&quot;,&quot;ratio&quot;:&quot;1.50&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17903768113012703&quot;:{&quot;id&quot;:&quot;22709299_2152828954944675_6033853057110900736_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17880588742136093&quot;:{&quot;id&quot;:&quot;22710422_221064848430906_5389012139077795840_n&quot;,&quot;ratio&quot;:&quot;1.50&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17845414189218813&quot;:{&quot;id&quot;:&quot;22710515_441558126241416_6328376406459809792_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17905522504012082&quot;:{&quot;id&quot;:&quot;22802064_1422246701224409_8705570247073071104_n&quot;,&quot;ratio&quot;:&quot;0.80&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}},&quot;17881359805908837&quot;:{&quot;id&quot;:&quot;129734250_299043961382220_4873546273688392437_n&quot;,&quot;ratio&quot;:&quot;1.00&quot;,&quot;sizes&quot;:{&quot;full&quot;:640,&quot;low&quot;:320}}}">
	</span>
	        <div id="sbi_mod_error">
            <span>This error message is only visible to WordPress admins</span><br />
                </div>
        </div>



		</div>
	</div>
</div></div></div><div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-3 vc_col-lg-3 vc_col-md-6"><div class="vc_column-inner "><div class="wpb_wrapper"><h3>Newsletter</h3>
	<div class="wpb_text_column wpb_content_element  vc_custom_1530767404157" >
		<div class="wpb_wrapper">
			<p>Signup for Our mailing list to get latest Updates and Offers</p>

		</div>
	</div>
<div id="dt-1530765236123-6c87c624-439a" class="square inline dt-mc-subscribe align-none footer-subscribe">   <div class="dt-subscribe-msg"> </div>   <form name="dt-subscribe" method="post">       <input type='hidden' name='dt_mc_listid' value='314bbca712' />       <input type='hidden' name='dt_mc_apikey' value='c94a1d38b6683d601a324aeeb4d4ffe3-us1'/><div class="dt-privacy-wrapper"><input name="dt_mc_privacy" id="dt_mc_privacy" value="true" type="checkbox" required="required"><label for="dt_mc_privacy">I agree to the terms and conditions laid out in the <a href='https://kanni.wpengine.com/privacy-policy/'>Privacy Policy</a></label></div><div class="email-field-wrap"> <div><input type="email" name="dt_mc_emailid" required="required" placeholder="Enter Email Address" /> </div></div><div class="btn-wrap  icon-only"> <div><i class="fa fa-paper-plane-o"> </i><input type='submit' name='mc_submit' value=''> </div></div>   </form></div><div id="1517825064875-94c7a6c9-2846" class="dt-sc-empty-space"></div>
	<div class="wpb_text_column wpb_content_element " >
		<div class="wpb_wrapper">
			<p>We respect your privacy.</p>

		</div>
	</div>
<ul id='dt-1517827460735-355df74f-b776' class='dt-sc-sociable small left'
                data-default-style = 'filled'
                data-default-border-radius = 'yes'
                data-default-shape = 'square'
                data-hover-style = 'filled'
                data-hover-border-radius = 'yes'
                data-hover-shape = 'square'
                ><li class="twitter">  <a href="#" title="" target="_self">      <span class="dt-icon-default"> <span></span> </span>      <i></i>      <span class="dt-icon-hover"> <span></span> </span>  </a></li><li class="facebook">  <a href="#" title="" target="_self">      <span class="dt-icon-default"> <span></span> </span>      <i></i>      <span class="dt-icon-hover"> <span></span> </span>  </a></li><li class="instagram">  <a href="#" title="" target="_self">      <span class="dt-icon-default"> <span></span> </span>      <i></i>      <span class="dt-icon-hover"> <span></span> </span>  </a></li></ul></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div data-vc-full-width="true" data-vc-full-width-init="false" class="vc_row wpb_row vc_row-fluid dt-sc-dark-bg dt-skin-primary-bg vc_custom_1534934915717 vc_row-o-equal-height vc_row-o-content-middle vc_row-flex"><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper">
	<div class="wpb_text_column wpb_content_element  vc_custom_1534934491382 dt-sc-copyright" >
		<div class="wpb_wrapper">
			<p>Copyright © 2018. All rights reserved by, <a title="DesignThemes" href="http://themeforest.net/user/designthemes">DesignThemes</a></p>

		</div>
	</div>
</div></div></div><div class="wpb_column vc_column_container vc_col-sm-6"><div class="vc_column-inner "><div class="wpb_wrapper"><div id="dt-1517823213081-29060582-f200" class="dt-custom-nav-wrapper right inline-horizontal" data-default-style = "none" data-hover-style = "none" data-default-decoration = "none" data-hover-decoration = "none"><div class="menu-copyright-menu-container"><ul id="menu-copyright-menu" class="custom-sub-nav dt-custom-nav"><li id="menu-item-369" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home menu-item-369"><a href="https://kanni.wpengine.com/" class="item-has-icon icon-position-left"><i class="menu-item-icon"></i><span>Home</span></a></li>
<li id="menu-item-368" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-368"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon"></i><span>Pricing</span></a></li>
<li id="menu-item-370" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-370"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon"></i><span>Why Choose Us</span></a></li>
<li id="menu-item-371" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-371"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon"></i><span>Quick Quote</span></a></li>
<li id="menu-item-372" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-372"><a href="#" class="item-has-icon icon-position-left"><i class="menu-item-icon"></i><span>Terms &#038; Conditions</span></a></li>
</ul></div></div></div></div></div></div><div class="vc_row-full-width vc_clearfix"></div><div class="vc_row wpb_row vc_row-fluid enquiry-form-section"><div class="wpb_column vc_column_container vc_col-sm-12"><div class="vc_column-inner "><div class="wpb_wrapper"><div class="enquiry_form fixed-form service_call"><span class="sticky_button">Book a Service Call</span><div class="sticky_form"><span class="close fa fa-times-circle"></span><div role="form" class="wpcf7" id="wpcf7-f300-o2" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="https://kanni.wpengine.com/contact/#wpcf7-f300-o2" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="300" />
<input type="hidden" name="_wpcf7_version" value="5.3.2" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f300-o2" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<p><span class="wpcf7-form-control-wrap text-605"><input type="text" name="text-605" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Business Name*" /></span><span class="wpcf7-form-control-wrap textarea-668"><textarea name="textarea-668" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" aria-invalid="false" placeholder="Address"></textarea></span><span class="wpcf7-form-control-wrap text-605"><input type="text" name="text-605" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Person Requesting Service" /></span><span class="wpcf7-form-control-wrap text-605"><input type="text" name="text-605" value="" size="40" class="wpcf7-form-control wpcf7-text" aria-invalid="false" placeholder="Fault" /></span><div class='dt-sc-hr-invisible-xsmall '> </div><span class="require">(<span class="req">*</span>) Required Field</span>
<div class="aligncenter"><input type="submit" value="Book a Service Call" class="wpcf7-form-control wpcf7-submit" /></div>
<div class="wpcf7-response-output" aria-hidden="true"></div></form></div></div></div><div class="enquiry_form fixed-form enquiry_now"><span class="sticky_button">Enquire Now</span><div class="sticky_form"><span class="close fa fa-times-circle"></span><div role="form" class="wpcf7" id="wpcf7-f301-o3" lang="en-US" dir="ltr">
<div class="screen-reader-response"><p role="status" aria-live="polite" aria-atomic="true"></p> <ul></ul></div>
<form action="https://kanni.wpengine.com/contact/#wpcf7-f301-o3" method="post" class="wpcf7-form init" novalidate="novalidate" data-status="init">
<div style="display: none;">
<input type="hidden" name="_wpcf7" value="301" />
<input type="hidden" name="_wpcf7_version" value="5.3.2" />
<input type="hidden" name="_wpcf7_locale" value="en_US" />
<input type="hidden" name="_wpcf7_unit_tag" value="wpcf7-f301-o3" />
<input type="hidden" name="_wpcf7_container_post" value="0" />
<input type="hidden" name="_wpcf7_posted_data_hash" value="" />
<input type="hidden" name="_wpcf7_recaptcha_response" value="" />
</div>
<div class="dt-sc-one-column"><span class="wpcf7-form-control-wrap text-605"><input type="text" name="text-605" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-validates-as-required" aria-required="true" aria-invalid="false" placeholder="Full Name*" /></span></div>
<div class="dt-sc-one-column"><span class="wpcf7-form-control-wrap email-606"><input type="email" name="email-606" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-email wpcf7-validates-as-required wpcf7-validates-as-email" aria-required="true" aria-invalid="false" placeholder="Email Address*" /></span></div>
<div class="dt-sc-one-column"><span class="wpcf7-form-control-wrap tel-52"><input type="tel" name="tel-52" value="" size="40" class="wpcf7-form-control wpcf7-text wpcf7-tel wpcf7-validates-as-tel" aria-invalid="false" placeholder="Phone Number" /></span></div>
<div class="dt-sc-one-column"><span class="wpcf7-form-control-wrap textarea-759"><textarea name="textarea-759" cols="40" rows="10" class="wpcf7-form-control wpcf7-textarea" id="enquire2" aria-invalid="false" placeholder="Message"></textarea></span></div>
<div class="dt-sc-one-column"><span class="require">(<span class="req">*</span>) Required Field</span></div>
<div class="dt-sc-one-column"><input type="submit" value="Send Now" class="wpcf7-form-control wpcf7-submit" /></div>
<div class="wpcf7-response-output" aria-hidden="true"></div></form></div></div></div></div></div></div></div></p>
            </div>
        </footer><!-- **Footer - End** -->

    </div><!-- **Inner Wrapper - End** -->
        
</div><!-- **Wrapper - End** -->

            <div class="dt-cookie-consent cookiebar-hidden dt-cookiemessage-bottom">
	            <div class="container">
    		        <p class="dt_cookie_text">This site uses cookies. By continuing to browse the site, you are agreeing to our use of cookies.</p><a href='#' class='dt-sc-button filled small dt-cookie-consent-button dt-cookie-consent-button-1  dt-cookie-close-bar ' data-contents='a6fe7a635a3ae90b600d28d9abace894'>Close</a><a href='http://kanni.wpengine.com/privacy-policy' class='dt-sc-button filled small dt-cookie-consent-button dt-cookie-consent-button-2 dt-extra-cookie-btn' >Click Here</a><a href='#dt-consent-extra-info' class='dt-sc-button filled small dt-cookie-consent-button dt-cookie-consent-button-3 dt-extra-cookie-btn dt-cookie-info-btn ' >Modal Box</a>                </div>
            </div><div id='dt-consent-extra-info' class='dt-inline-modal main_color zoom-anim-dialog mfp-hide'>

								<h4>Cookie and Privacy Settings</h4>

								<div class='dt-sc-tabs-vertical-container ' data-effect='fade'><ul class='dt-sc-tabs-vertical'><li><a href="javascript:void(0);">How we use cookies</a></li><li><a href="javascript:void(0);">Essential Website Cookies</a></li><li><a href="javascript:void(0);">Google Analytics Cookies</a></li><li><a href="javascript:void(0);">Other external services</a></li><li><a href="javascript:void(0);">Privacy Policy</a></li></ul>
									<div class='dt-sc-tabs-vertical-content'>We may request cookies to be set on your device. We use cookies to let us know when you visit our websites, how you interact with us, to enrich your user experience, and to customize your relationship with our website. <br><br>Click on the different category headings to find out more. You can also change some of your preferences. Note that blocking some types of cookies may impact your experience on our websites and the services we are able to offer.</div><div class='dt-sc-tabs-vertical-content'>These cookies are strictly necessary to provide you with services available through our website and to use some of its features. <br><br>Because these cookies are strictly necessary to deliver the website, you cannot refuse them without impacting how our site functions. You can block or delete them by changing your browser settings and force blocking all cookies on this website.</div><div class='dt-sc-tabs-vertical-content'>These cookies collect information that is used either in aggregate form to help us understand how our website is being used or how effective our marketing campaigns are, or to help us customize our website and application for you in order to enhance your experience. <br><br>If you do not want that we track your visist to our site you can disable tracking in your browser here: <div class="dt-toggle-switch"><label><input type="checkbox"  checked="checked" id="dtPrivacyGoogleTrackingDisabled" name="dtPrivacyGoogleTrackingDisabled" class="dtPrivacyGoogleTrackingDisabled"><span>Click to enable/disable google analytics tracking.</span></label></div></div><div class='dt-sc-tabs-vertical-content'>We also use different external services like Google Webfonts, Google Maps and external Video providers. Since these providers may collect personal data like your IP address we allow you to block them here. Please be aware that this might heavily reduce the functionality and appearance of our site. Changes will take effect once you reload the page.<br><br>

			Google Webfont Settings:
			<div class="dt-toggle-switch"><label><input type="checkbox"  checked="checked" id="dtPrivacyGoogleWebfontsDisabled" name="dtPrivacyGoogleWebfontsDisabled" class="dtPrivacyGoogleWebfontsDisabled"><span>Click to enable/disable google webfonts.</span></label></div>

			Google Map Settings:
			<div class="dt-toggle-switch"><label><input type="checkbox"  checked="checked" id="dtPrivacyGoogleMapsDisabled" name="dtPrivacyGoogleMapsDisabled" class="dtPrivacyGoogleMapsDisabled"><span>Click to enable/disable google maps.</span></label></div>

			Vimeo and Youtube video embeds:
			<div class="dt-toggle-switch"><label><input type="checkbox"  checked="checked" id="dtPrivacyVideoEmbedsDisabled" name="dtPrivacyVideoEmbedsDisabled" class="dtPrivacyVideoEmbedsDisabled"><span>Click to enable/disable video embeds.</span></label></div></div><div class='dt-sc-tabs-vertical-content'>You can read about our cookies and privacy settings in detail on our Privacy Policy Page. <br><br> <a href='https://kanni.wpengine.com/privacy-policy/'>Privacy Policy</a></div>
								</div>
							</div>		<script>
			jQuery(".wpcf7-submit").click(function(event) {
				jQuery( document ).ajaxComplete(function() {
					var responseType = jQuery(".wpcf7-response-output").hasClass("wpcf7-validation-errors") ? "red" : "green";
					var responseHtml = "";
					
					// Iterate all error tips on elements and show that errors in the popup
					jQuery(".wpcf7-not-valid-tip").each(function(index) {
						jQuery(this).hide();
						responseHtml += "<li>*" + jQuery(this).html() + "</li>"; 
					});

					if (responseHtml.length == 0) {
						responseHtml = "<li>" + jQuery(".wpcf7-response-output").html() + "</li>";
					}
					
					jQuery.colorbox({
						html: '<div style="color:' + responseType + '; padding:30px; background:#fff;"><ol>' + responseHtml + '</ol></div>',
						onClosed: function() {
							if (responseType == "green") {
								window.location = "https://kanni.wpengine.com/";
							}
						}
					});
					jQuery(".wpcf7-response-output").css( "display", "none" );
				});
			});
		</script>
	<!-- Instagram Feed JS -->
<script type="text/javascript">
var sbiajaxurl = "https://kanni.wpengine.com/wp-admin/admin-ajax.php";
</script>
<script type="text/html" id="wpb-modifications"></script>	<script type="text/javascript">
		(function () {
			var c = document.body.className;
			c = c.replace(/woocommerce-no-js/, 'woocommerce-js');
			document.body.className = c;
		})()
	</script>
	
<link rel='stylesheet' id='vc_font_awesome_5_shims-css'  href='https://kanni.wpengine.com/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/v4-shims.min.css?ver=6.5.0' type='text/css' media='all' />
<link rel='stylesheet' id='vc_font_awesome_5-css'  href='https://kanni.wpengine.com/wp-content/plugins/js_composer/assets/lib/bower/font-awesome/css/all.min.css?ver=6.5.0' type='text/css' media='all' />
<script type='text/javascript' id='contact-form-7-js-extra'>
/* <![CDATA[ */
var wpcf7 = {"apiSettings":{"root":"https:\/\/kanni.wpengine.com\/wp-json\/contact-form-7\/v1","namespace":"contact-form-7\/v1"},"cached":"1"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/contact-form-7/includes/js/scripts.js?ver=5.3.2' id='contact-form-7-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/jquery.tabs.min.js?ver=5.7.5' id='dt-sc-tabs-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/jquery.tipTip.minified.js?ver=5.7.5' id='dt-sc-tiptip-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/jquery.inview.js?ver=5.7.5' id='dt-sc-inview-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/jquery.animateNumber.min.js?ver=5.7.5' id='dt-sc-animatenum-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/jquery.donutchart.js?ver=5.7.5' id='dt-sc-donutchart-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/slick.min.js?ver=5.7.5' id='dt-sc-slick-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/jquery.toggle.click.js?ver=5.7.5' id='dt-sc-toggle-click-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/shortcodes.js?ver=5.7.5' id='dt-sc-script-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/custom-post-types/js/protfolio-custom.js?ver=5.7.5' id='dt-sc-portfolio-custom-script-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-fb-pixel/script.js?ver=5.7.5' id='dt-fbpixel-script-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/woocommerce/assets/js/js-cookie/js.cookie.min.js?ver=2.1.4' id='js-cookie-js'></script>
<script type='text/javascript' id='woocommerce-js-extra'>
/* <![CDATA[ */
var woocommerce_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/woocommerce/assets/js/frontend/woocommerce.min.js?ver=4.8.1' id='woocommerce-js'></script>
<script type='text/javascript' id='wc-cart-fragments-js-extra'>
/* <![CDATA[ */
var wc_cart_fragments_params = {"ajax_url":"\/wp-admin\/admin-ajax.php","wc_ajax_url":"\/?wc-ajax=%%endpoint%%","cart_hash_key":"wc_cart_hash_cf2178435b107dd6e53cad41772bed21","fragment_name":"wc_fragments_cf2178435b107dd6e53cad41772bed21","request_timeout":"5000"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/woocommerce/assets/js/frontend/cart-fragments.min.js?ver=4.8.1' id='wc-cart-fragments-js'></script>
<script type='text/javascript' src='../../www.google.com/recaptcha/api394a.js?render=6LeKW-8ZAAAAAFCLCnV0QoL6ZpqXJ3LQwXSA9X2r&amp;ver=3.0' id='google-recaptcha-js'></script>
<script type='text/javascript' id='wpcf7-recaptcha-js-extra'>
/* <![CDATA[ */
var wpcf7_recaptcha = {"sitekey":"6LeKW-8ZAAAAAFCLCnV0QoL6ZpqXJ3LQwXSA9X2r","actions":{"homepage":"homepage","contactform":"contactform"}};
/* ]]> */
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/contact-form-7/modules/recaptcha/script.js?ver=5.3.2' id='wpcf7-recaptcha-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.ui.totop.min.js?ver=5.7.5' id='jquery-ui-totop-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.easing.js?ver=5.7.5' id='jquery-easing-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.caroufredsel.js?ver=5.7.5' id='jquery-caroufredsel-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.debouncedresize.js?ver=5.7.5' id='jquery-debouncedresize-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.prettyphoto.js?ver=5.7.5' id='jquery-prettyphoto-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.touchswipe.js?ver=5.7.5' id='jquery-touchswipe-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.parallax.js?ver=5.7.5' id='jquery-parallax-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.downcount.js?ver=5.7.5' id='jquery-downcount-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.nicescroll.js?ver=5.7.5' id='jquery-nicescroll-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.bxslider.js?ver=5.7.5' id='jquery-bxslider-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.fitvids.js?ver=5.7.5' id='jquery-fitvids-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.sticky.js?ver=5.7.5' id='jquery-sticky-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.simple-sidebar.js?ver=5.7.5' id='jquery-simple-sidebar-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.classie.js?ver=5.7.5' id='jquery-classie-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.placeholder.js?ver=5.7.5' id='jquery-placeholder-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.visualNav.min.js?ver=5.7.5' id='jquery-visualnav-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/ResizeSensor.min.js?ver=5.7.5' id='resizesensor-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/theia-sticky-sidebar.min.js?ver=5.7.5' id='theia-sticky-sidebar-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/jquery.mCustomScrollbar.concat.min.js?ver=5.7.5' id='jquery-mcustomscrollbar-concat-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/isotope.pkgd.min.js?ver=5.7.5' id='isotope-pkgd-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/cookieconsent.js?ver=5.7.5' id='kanni-cookie-js-js'></script>
<script type='text/javascript' id='kanni-cookie-js-js-after'>
function dt_privacy_cookie_setter( cookie_name ) {
				
			var toggle = jQuery('.' + cookie_name);
			toggle.each(function()
			{
				if(document.cookie.match(cookie_name)) this.checked = false;
			});

			jQuery('.' + 'dt-switch-' + cookie_name).each(function()
			{
				this.className += ' active ';
			});

			toggle.on('click', function() {
				if(this.checked) {
					document.cookie = cookie_name + '=; Path=/; Expires=Thu, 01 Jan 1970 00:00:01 GMT;';
				}
				else {
					var theDate = new Date();
					var oneYearLater = new Date( theDate.getTime() + 31536000000 );
					document.cookie = cookie_name + '=true; Path=/; Expires='+oneYearLater.toGMTString()+';';
				}
			});
			};
			dt_privacy_cookie_setter('dtPrivacyGoogleTrackingDisabled');
			dt_privacy_cookie_setter('dtPrivacyGoogleWebfontsDisabled');
			dt_privacy_cookie_setter('dtPrivacyGoogleMapsDisabled');
			dt_privacy_cookie_setter('dtPrivacyVideoEmbedsDisabled'); 
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/magnific/jquery.magnific-popup.min.js?ver=5.7.5' id='kanni-popup-js-js'></script>
<script type='text/javascript' id='kanni-jqcustom-js-extra'>
/* <![CDATA[ */
var dttheme_urls = {"theme_base_url":"https:\/\/kanni.wpengine.com\/wp-content\/themes\/kanni","framework_base_url":"https:\/\/kanni.wpengine.com\/wp-content\/themes\/kanni\/framework\/","ajaxurl":"https:\/\/kanni.wpengine.com\/wp-admin\/admin-ajax.php","url":"https:\/\/kanni.wpengine.com","isRTL":"","loadingbar":"disable","advOptions":"Show Advanced Options","wpnonce":"a4e6e1bff2"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/themes/kanni/framework/js/custom.js?ver=5.7.5' id='kanni-jqcustom-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/contact-form-7-popup-response//colorbox/jquery.colorbox-min.js?ver=5.7.5' id='popupScript-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-includes/js/wp-embed.min.js?ver=5.7.5' id='wp-embed-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/js_composer/assets/js/dist/js_composer_front.min.js?ver=6.5.0' id='wpb_composer_front_js-js'></script>
<script type='text/javascript' src='https://maps-api-ssl.google.com/maps/api/js?key=AIzaSyCBEAoMjpxgfiNSG9shm9PiO7lijV-w19c' id='google-map-js'></script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/designthemes-core-features/shortcodes/js/jquery.gmap.js' id='jquery.gmap-js'></script>
<script type='text/javascript' id='sb_instagram_scripts-js-extra'>
/* <![CDATA[ */
var sb_instagram_js_options = {"font_method":"svg","resized_url":"https:\/\/kanni.wpengine.com\/wp-content\/uploads\/sb-instagram-feed-images\/","placeholder":"https:\/\/kanni.wpengine.com\/wp-content\/plugins\/instagram-feed\/img\/placeholder.png"};
/* ]]> */
</script>
<script type='text/javascript' src='https://kanni.wpengine.com/wp-content/plugins/instagram-feed/js/sbi-scripts.min.js?ver=2.6.2' id='sb_instagram_scripts-js'></script>
<!-- Global site tag (gtag.js) - Google Analytics -->
			<script async src='https://www.googletagmanager.com/gtag/js?id=UA-XXXXX-X'></script>
			<script>
			window.dataLayer = window.dataLayer || [];
			function gtag(){dataLayer.push(arguments);}
			gtag('js', new Date());
			gtag('config', 'UA-XXXXX-X', { 'anonymize_ip': true });
			</script></body>

<!-- Mirrored from kanni.wpengine.com/contact/ by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 09 Feb 2022 07:41:46 GMT -->
</html>