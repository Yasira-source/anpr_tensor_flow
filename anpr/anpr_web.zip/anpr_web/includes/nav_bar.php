<!-- **Header** -->
<header id="header">

    <div class="container">
        <div id="header-8" class="dt-header-tpl header-8">
            <p>
            <div data-vc-full-width="true" data-vc-full-width-init="false"
                class="vc_row wpb_row vc_row-fluid vc_custom_1534753653700">
                <div class="rs_col-sm-12 wpb_column vc_column_container vc_col-sm-4">
                    <div class="vc_column-inner " style=" text-align:left; ">
                        <div class="wpb_wrapper">
                            <div id="dt-1517831922735-f950d3e0-4c81"
                                class="dt-logo-container logo-align-left vc_custom_1533628387528"> <a href="index.html"
                                    rel="home"><img src="wp-content/uploads/2018/08/logo_2.jpg"
                                        alt="Kanni Security Systems WordPress Theme" /></a></div>
                        </div>
                    </div>
                </div>
                <div class="rs_col-sm-12 wpb_column vc_column_container vc_col-sm-8">
                    <div class="vc_column-inner vc_custom_1517989922419" style=" text-align:left; ">
                        <div class="wpb_wrapper">
                            <div class="vc_row wpb_row vc_inner vc_row-fluid header-right-content">
                                <div class="wpb_column vc_column_container vc_col-sm-4">
                                    <div class="vc_column-inner ">
                                        <div class="wpb_wrapper">
                                            <div class='dt-sc-contact-info  type1'><span class='fa fa-map-signs'>
                                                </span>
                                                <h6>Address</h6>Old Kampala,<br>
                                                National Mosque ,<br>
                                                Nile Avenue, Uganda
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-4">
                                    <div class="vc_column-inner ">
                                        <div class="wpb_wrapper">
                                            <div class='dt-sc-contact-info  type1'><span class='fa fa-envelope'> </span>
                                                <h6>Mail Contact</h6><a href="#">support@icucanpr.com</a>
                                                <!-- <a href="#">support@icucanpr.com</a> -->
                                                <a href="#">yasira@icucanpr.com</a>
                                                <a href="#">isma@icucanpr.com</a>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="wpb_column vc_column_container vc_col-sm-4">
                                    <div class="vc_column-inner ">
                                        <div class="wpb_wrapper">
                                            <div class='dt-sc-contact-info  type1'><span class='fa fa-phone'> </span>
                                                <h3 class="dt-skin-primary-color">+256 707 251 554</h3>
                                                <h3 class="dt-skin-primary-color">+256 701 565 268</h3>
                                            </div><a href='#' target='_self' title=''
                                                class='dt-sc-button   xlarge   filled  '> Give Us a Call
                                            </a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vc_row-full-width vc_clearfix"></div>
            <div data-vc-full-width="true" data-vc-full-width-init="false"
                class="vc_row wpb_row vc_row-fluid vc_custom_1530682401432 vc_row-has-fill vc_row-o-equal-height vc_row-o-content-middle vc_row-flex">
                <div class="rs_col-sm-6 wpb_column vc_column_container vc_col-sm-11 vc_col-lg-11 vc_col-md-6">
                    <div class="vc_column-inner vc_custom_1539150841469">
                        <div class="wpb_wrapper">
                            <div data-menu="main-menu" id="dt-1517895345652-1665f512-1e96"
                                class="dt-header-menu mega-menu-page-equal left light-hover-effect"
                                data-nav-item-divider="none" data-nav-item-highlight="underline"
                                data-nav-item-display="simple">
                                <div class="menu-container">
                                    <ul id="menu-main-menu" class="dt-primary-nav " data-menu="main-menu">
                                        <li class="close-nav"></li>
                                        <li id="menu-item-18"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-home current-menu-item page_item page-item-6 current_page_item menu-item-18 dt-menu-item-18 ">
                                            <a href="index.php"
                                                class="item-has-icon icon-position-left"><span>Home</span></a>
                                        </li>
                                        <li id="menu-item-396"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-396 dt-menu-item-396 ">
                                            <a href="about/"
                                                class="item-has-icon icon-position-left"><span>About</span></a>
                                            <ul class="sub-menu is-hidden ">
                                                <li class="go-back"><a href="javascript:void(0);"></a>
                                                </li>
                                                <li class="see-all"></li>
                                                <li id="menu-item-397"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-397 dt-menu-item-397 ">
                                                    <a href="about/"
                                                        class="item-has-icon icon-position-left"><span>About</span></a>
                                                </li>
                                                <li id="menu-item-397"
                                                    class="menu-item menu-item-type-post_type menu-item-object-page menu-item-397 dt-menu-item-397 ">
                                                    <a href="about/careers/"
                                                        class="item-has-icon icon-position-left"><span>Careers</span></a>
                                                </li>
                                            </ul>
                                        </li>
                                        
                                        <li id="menu-item-399"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-399 dt-menu-item-399 ">
                                            <a href="history/"
                                                class="item-has-icon icon-position-left"><span>History</span></a>
                                        </li>
                                        <!-- <li id="menu-item-400"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-400 dt-menu-item-400 ">
                                            <a href="https://kanni.wpengine.com/packages/"
                                                class="item-has-icon icon-position-left"><span>Packages</span></a>
                                        </li> -->
                                        <li id="menu-item-401"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-401 dt-menu-item-401 ">
                                            <a href="dashboard/dashboard/login.php"
                                                class="item-has-icon icon-position-left"><span>Payments
                                                    </span></a>
                                        </li>
                                        <li id="menu-item-402"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-402 dt-menu-item-402 ">
                                            <a href="services/"
                                                class="item-has-icon icon-position-left"><span>Services</span></a>
                                            <ul class="sub-menu is-hidden ">
                                                <li class="go-back"><a href="javascript:void(0);"></a>
                                                </li>
                                                <li class="see-all"></li>
                                                <li id="menu-item-10459"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10459 dt-menu-item-10459 ">
                                                    <a href="dashboard/dashboard/login.php"
                                                        class="item-has-icon icon-position-left"><span>Report Vehicle / Mortocycle</span></a>
                                                </li>
                                                <li id="menu-item-10460"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10460 dt-menu-item-10460 ">
                                                    <a href="dashboard/dashboard/login.php"
                                                        class="item-has-icon icon-position-left"><span>Check Individual Status</span></a>
                                                </li>
                                                <li id="menu-item-10461"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10461 dt-menu-item-10461 ">
                                                    <a href="dashboard/dashboard/login.php"
                                                        class="item-has-icon icon-position-left"><span>Check Vehicle Status
                                                            </span></a>
                                                </li>
                                                <li id="menu-item-10462"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10462 dt-menu-item-10462 ">
                                                    <a href="dashboard/dashboard/login.php"
                                                        class="item-has-icon icon-position-left"><span>Make Payments
                                                            </span></a>
                                                </li>
                                                <!-- <li id="menu-item-10463"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10463 dt-menu-item-10463 ">
                                                    <a href="https://kanni.wpengine.com/side-navigation/burgular-intruder-alarm/"
                                                        class="item-has-icon icon-position-left"><span>Traffic Officer</span></a>
                                                </li> -->
                                                <li id="menu-item-10464"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10464 dt-menu-item-10464 ">
                                                    <a href="dashboard/dashboard/login.php"
                                                        class="item-has-icon icon-position-left"><span>Login / Register
                                                            </span></a>
                                                </li>
                                                <!-- <li id="menu-item-10465"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10465 dt-menu-item-10465 ">
                                                    <a href="https://kanni.wpengine.com/side-navigation/cctv-equipments/"
                                                        class="item-has-icon icon-position-left"><span>Register
                                                            </span></a>
                                                </li> -->
                                                <li id="menu-item-10466"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10466 dt-menu-item-10466 ">
                                                    <a href="https://kanni.wpengine.com/side-navigation/access-control-system/"
                                                        class="item-has-icon icon-position-left"><span>Countries Supported
                                                            </span></a>
                                                </li>
                                                <li id="menu-item-10467"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-10467 dt-menu-item-10467 ">
                                                    <a href="https://dashboard.flutterwave.com/donate/gpjurqwpfevo"
                                                        class="item-has-icon icon-position-left"><span>Donate to Us
                                                            </span></a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li id="menu-item-9624"
                                          class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-9624 dt-menu-item-9624 ">
                                          <a href="#" class="item-has-icon icon-position-left"><span><?php 
                                          if(isset($_SESSION['citizen']) || isset($_SESSION['admin']) || isset($_SESSION['officer'])){
                                              echo $admin['_fullnames'];
                                          }else{
                                              echo 'Account';
                                          }
                                          ?></span></a>
                                          <ul class="sub-menu is-hidden ">
                                              <li class="go-back"><a href="javascript:void(0);"></a>
                                              </li>
                                              <li class="see-all"></li>
                                              <li id="menu-item-9625"
                                                  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9625 dt-menu-item-9625 ">
                                                  
                                                      <?php 
                                          if(isset($_SESSION['citizen']) || isset($_SESSION['admin']) || isset($_SESSION['officer'])){
                                              echo '<a href="dashboard/dashboard/logout.php"
                                              class="item-has-icon icon-position-left"><span>Logout </span></a>';
                                          }else{
                                            echo '<a href="dashboard/dashboard/login.php"
                                            class="item-has-icon icon-position-left"><span>Login </span></a>';
                                          }
                                          ?>
                                                     
                                                  
                                              </li>
                                              <?php 
                                          if(isset($_SESSION['citizen']) || isset($_SESSION['admin']) || isset($_SESSION['officer'])){
                                              echo '
                                              <li id="menu-item-9668"
                                                  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9668 dt-menu-item-9668 ">
                                                  <a href="dashboard/dashboard/index.php"
                                                      class="item-has-icon icon-position-left"><span>My Dashboard</span></a>
                                                  
                                              </li>
                                             
                                              ';
                                          }else{
                                            echo '
                                            <li id="menu-item-9668"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-has-children menu-item-9668 dt-menu-item-9668 ">
                                            <a href="dashboard/dashboard/register.php"
                                                class="item-has-icon icon-position-left"><span>Create Account</span></a>
                                            
                                        </li>
                                            ';
                                          }?>
                                              
                                              <li id="menu-item-9628"
                                                  class="menu-item menu-item-type-post_type menu-item-object-page menu-item-9628 dt-menu-item-9628 ">
                                                  <a href="dashboard/dashboard/forgot_password.php"
                                                      class="item-has-icon icon-position-left"><span>Forgot Password</span></a>
                                              </li>
                                          </ul>
                                      </li>
                                        <li id="menu-item-398"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-398 dt-menu-item-398 ">
                                            <a href="faq/"
                                                class="item-has-icon icon-position-left"><span>Faqs</span></a>
                                        </li>
                                        <li id="menu-item-427"
                                            class="menu-item menu-item-type-post_type menu-item-object-page menu-item-427 dt-menu-item-427 ">
                                            <a href="contact/"><span>Contact - Us</span></a>
                                        </li>
                                        <li id="menu-item-10276"
                                            class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10276 dt-menu-item-10276 ">
                                            <a href="#"
                                                class="item-has-icon icon-position-left"><span>Pages</span></a>
                                            <ul class="sub-menu is-hidden ">
                                                <li class="go-back"><a href="javascript:void(0);"></a>
                                                </li>
                                                <li class="see-all"></li>
                                                <li id="menu-item-10278"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10278 dt-menu-item-10278 ">
                                                    <a href="team/team/" class="item-has-icon icon-position-left"><span>Our Team
                                                            </span></a>
                                                    
                                                </li>
                                                <li id="menu-item-10278"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10278 dt-menu-item-10278 ">
                                                    <a href="blog/" class="item-has-icon icon-position-left"><span>Blogs
                                                            </span></a>
                                                    
                                                </li>
                                                <li id="menu-item-10283"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10283 dt-menu-item-10283 ">
                                                    <a href="#" class="item-has-icon icon-position-left"><span>Traffic Rules
                                                            </span></a>
                                                    
                                                </li>
                                                <li id="menu-item-10289"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10289 dt-menu-item-10289 ">
                                                    <a href="#" class="item-has-icon icon-position-left"><span>Traffic Status
                                                            </span></a>
                                                    
                                                </li>
                                                <li id="menu-item-10295"
                                                    class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-10295 dt-menu-item-10295 ">
                                                    <a href="#"><span>Reports</span></a>
                                                    
                                                </li>
                                            </ul>
                                        </li>
                                       
                                    </ul>
                                    <div class="sub-menu-overlay"></div>
                                </div>
                            </div>
                            <div id="dt-1517895345652-1665f512-1e96-mobile"
                                class="mobile-nav-container mobile-nav-offcanvas-right" data-menu="main-menu">
                                <div class="menu-trigger menu-trigger-icon" data-menu="main-menu"><i
                                        class="fa fa-bars"></i><span>Menu</span> </div>
                                <div class="mobile-menu" data-menu="main-menu"></div>
                                <div class="overlay"></div>
                            </div>
                        </div>
                    </div>
                </div>
                <div
                    class="header-search-icon rs_col-sm-6 wpb_column vc_column_container vc_col-sm-1 vc_col-lg-1 vc_col-md-6">
                    <div class="vc_column-inner vc_custom_1539150851503" style=" text-align:right; ">
                        <div class="wpb_wrapper">
                            <div id="dt-1517833845542-f830b07d-9a3e" class=" search-module overlay-header-search">
                                <div class="menu-icons-wrapper">
                                    <div class="search"> <a href="javascript:void(0)"
                                            class="overlay-search-type2 dt-search-icon type2"> <span
                                                class="fa fa-search"> </span> </a>
                                        <div class="overlay overlay-search">
                                            <div class="overlay-close"></div><!-- **Searchform** -->
                                            <form method="get" id="searchform" action="https://kanni.wpengine.com/">
                                                <input id="s" name="s" type="text" value="Enter Keyword"
                                                    class="text_input"
                                                    onblur="if(this.value==''){this.value='Enter Keyword';}"
                                                    onfocus="if(this.value =='Enter Keyword') {this.value=''; }" />
                                                <a href="javascript:void(0)" class="dt-search-icon">
                                                    <span class="fa fa-close"> </span> </a>
                                                <input name="submit" type="submit" value="Go" />
                                            </form><!-- **Searchform - End** -->
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="vc_row-full-width vc_clearfix"></div>
            </p>
        </div>
    </div>
</header><!-- **Header - End ** -->